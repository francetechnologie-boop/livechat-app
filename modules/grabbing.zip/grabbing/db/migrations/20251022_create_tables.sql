CREATE TABLE IF NOT EXISTS mod_grabbing_config (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  target TEXT,
  options JSONB,
  enabled BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

