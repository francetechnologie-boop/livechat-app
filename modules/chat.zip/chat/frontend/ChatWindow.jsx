// src/components/ChatWindow.jsx
import { useEffect, useMemo, useRef, useState } from "react";
import { socket } from "@app-lib/socket";
import { loadUIState, loadModuleState, saveModuleState } from "@app-lib/uiState";

/* -------------------- Helpers -------------------- */

// Format FR compact : "03 sept., 14:12"
function formatTs(ts) {
  if (!ts) return '';
  try {
    return new Intl.DateTimeFormat('fr-FR', {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(ts));
  } catch {
    return '';
  }
}




// Escape plain text (visitor) for safety
function escapeHtml(s = "") {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

// Autolink plain text (after escaping)
function escapeHtmlWithAutolink(s = "") {
  const esc = escapeHtml(s);
  return esc.replace(/((https?:\/\/|www\.)[^\s<]+)/gi, (m) => {
    const href = m.startsWith("http") ? m : `https://${m}`;
    return `<a href="${href}" target="_blank" rel="noreferrer">${m}</a>`;
  });
}

// Very light HTML sanitizer for agent messages (allow only basic tags)
function sanitizeAgentHtml(html = "") {
  let s = html.replace(
    /<\s*(script|iframe|object|embed|style)[^>]*>[\s\S]*?<\s*\/\s*\1\s*>/gi,
    ""
  );
  s = s.replace(/\son\w+="[^"]*"/gi, "").replace(/\son\w+='[^']*'/gi, "");
  s = s.replace(/<\/?([a-z0-9-]+)([^>]*)>/gi, (m, tag, attrs) => {
    const ALLOWED = [
      "a",
      "br",
      "strong",
      "em",
      "ul",
      "ol",
      "li",
      "p",
      "b",
      "i",
      "u",
      "s",
      "code",
      "pre",
      "blockquote",
      "span",
    ];
    const t = tag.toLowerCase();
    if (!ALLOWED.includes(t)) return "";
    const isClose = /^<\//.test(m);
    if (t === "a") {
      if (isClose) return `</a>`;
      const hrefMatch = attrs.match(/\shref\s*=\s*(".*?"|'[^']*'|[^\s>]+)/i);
      const href = hrefMatch ? hrefMatch[0] : "";
      return `<a ${href} target="_blank" rel="noopener noreferrer">`;
    }
    return isClose ? `</${t}>` : `<${t}>`;
  });
  return s;
}

function decodeEscapedHtml(s = "") {
  return String(s)
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'");
}

// Smarter plaintext/Markdown-ish -> HTML for AI responses
function mdToHtmlLite(md = "") {
  const text = String(md || "");
  const esc = escapeHtml(text);
  const lines = esc.split(/\r?\n/);

  const blocks = [];
  let ul = [];
  let ol = [];
  const flushUl = () => { if (ul.length) { blocks.push(`<ul>${ul.join("")}</ul>`); ul = []; } };
  const flushOl = () => { if (ol.length) { blocks.push(`<ol>${ol.join("")}</ol>`); ol = []; } };

  const linkify = (s) => s.replace(/\b(https?:\/\/[^\s<>()]+)([)\]\.,!?;:]?)/g, (m, u, trail) => {
    const clean = u.replace(/[,.;:!?]+$/,'');
    return `<a href="${clean}" target="_blank" rel="noopener noreferrer">${clean}</a>${trail||''}`;
  });

  for (const raw of lines) {
    const l = raw.trim();
    if (!l) { flushUl(); flushOl(); continue; }
    // Headings
    const hMatch = l.match(/^#{1,6}\s+(.+)/);
    if (hMatch) { flushUl(); flushOl(); blocks.push(`<p><strong>${hMatch[1]}</strong></p>`); continue; }
    // Bullets: -, *, •
    const bMatch = l.match(/^([\-*•])\s+(.+)/);
    if (bMatch) { flushOl(); ul.push(`<li>${linkify(bMatch[2])}</li>`); continue; }
    // Ordered: 1) 1. etc.
    const oMatch = l.match(/^(\d+)[\.)]\s+(.+)/);
    if (oMatch) { flushUl(); ol.push(`<li>${linkify(oMatch[2])}</li>`); continue; }
    // Label : URL → turn URL into link; lines with URL become bullets
    const lu = l.replace(/([^:]+):\s*(https?:\/\/[^\s<>()]+)/g, (m, label, url) => `${escapeHtml(label)}: <a href="${url}" target="_blank" rel="noopener noreferrer">${url}</a>`);
    if (/https?:\/\//.test(l)) {
      flushOl(); ul.push(`<li>${linkify(lu)}</li>`);
    } else {
      flushUl(); flushOl();
      blocks.push(`<p>${linkify(lu)}</p>`);
    }
  }
  flushUl(); flushOl();
  // lightweight bold/italic
  let html = blocks.join("");
  html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
             .replace(/\*([^*]+)\*/g, "<em>$1</em>");
  return html;
}

function normalizeDraft(data) {
  const draftRaw = (data?.draft || "").trim();
  const format = (data?.format || "").toLowerCase();
  if (!draftRaw) return { html: "", text: "" };
  if (format === "html" || /<\/?[a-z][\s\S]*>/i.test(draftRaw)) {
    return { html: sanitizeAgentHtml(draftRaw), text: draftRaw };
  }
  return { html: sanitizeAgentHtml(mdToHtmlLite(draftRaw)), text: draftRaw };
}

/* -------------------- Inline Rich Editor (TipTap) -------------------- */
import { EditorContent, useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Link from "@tiptap/extension-link";
import Placeholder from "@tiptap/extension-placeholder";
import Picker from "@emoji-mart/react";
import data from "@emoji-mart/data";

function ToolbarButton({ active, onClick, children, title }) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      className={`text-xs px-2 py-1 rounded border bg-white hover:bg-gray-50 ${
        active ? "ring-2 ring-indigo-400" : ""
      }`}
    >
      {children}
    </button>
  );
}

/**
 * Simple inline TipTap editor used as message composer
 * Props:
 *  - valueHtml
 *  - onChange(html, plainText)
 *  - disabled
 *  - minRows
 */
function InlineRichEditor({
  valueHtml = "",
  onChange,
  disabled = false,
  minRows = 5,
}) {
  const [showEmoji, setShowEmoji] = useState(false);
  const pickerRef = useRef(null);

  const editor = useEditor({
    editable: !disabled,
    content: valueHtml || "",
    extensions: [
      StarterKit.configure({
        bulletList: { keepMarks: true, keepAttributes: true },
        orderedList: { keepMarks: true, keepAttributes: true },
      }),
      Link.configure({
        autolink: true,
        openOnClick: false,
        HTMLAttributes: { target: "_blank", rel: "noreferrer" },
      }),
      Placeholder.configure({
        placeholder:
          "Écrivez votre message (vous pouvez éditer le brouillon proposé)…",
      }),
    ],
    onUpdate({ editor }) {
      const html = editor.getHTML();
      const text = editor.getText();
      onChange?.(html, text);
    },
  });

  // 🔧 IMPORTANT: TipTap only reads `editable` at creation → toggle when prop changes
  useEffect(() => {
    if (editor) editor.setEditable(!disabled);
  }, [disabled, editor]);

  // Keep external value in sync
  useEffect(() => {
    if (!editor) return;
    const current = editor.getHTML();
    if (valueHtml !== current) {
      editor.commands.setContent(valueHtml || "", false);
    }
  }, [valueHtml, editor]);

  useEffect(() => {
    const onDocClick = (e) => {
      if (!pickerRef.current) return;
      if (!pickerRef.current.contains(e.target)) setShowEmoji(false);
    };
    document.addEventListener("click", onDocClick);
    return () => document.removeEventListener("click", onDocClick);
  }, []);

  const insertLink = () => {
    const url = window.prompt("Entrez l’URL du lien :", "https://");
    if (!url) return;
    editor?.chain().focus().extendMarkRange("link").setLink({ href: url }).run();
  };
  const clearLink = () => editor?.chain().focus().unsetLink().run();
  const insertEmoji = (emoji) => {
    editor?.chain().focus().insertContent(emoji.native).run();
    setShowEmoji(false);
  };

  const minHeight = Math.max(52, minRows * 22 + 16);

  return (
    <div className="w-full">
      {/* Toolbar */}
      <div className="flex items-center gap-1 mb-2">
        <ToolbarButton
          title="Gras"
          active={editor?.isActive("bold")}
          onClick={() => editor?.chain().focus().toggleBold().run()}
        >
          G
        </ToolbarButton>
        <ToolbarButton
          title="Italique"
          active={editor?.isActive("italic")}
          onClick={() => editor?.chain().focus().toggleItalic().run()}
        >
          I
        </ToolbarButton>
        <ToolbarButton
          title="Puces"
          active={editor?.isActive("bulletList")}
          onClick={() => editor?.chain().focus().toggleBulletList().run()}
        >
          ••
        </ToolbarButton>
        <ToolbarButton
          title="Numérotée"
          active={editor?.isActive("orderedList")}
          onClick={() => editor?.chain().focus().toggleOrderedList().run()}
        >
          1.
        </ToolbarButton>

        <div className="mx-2 h-5 w-px bg-gray-300" />

        <ToolbarButton title="Lien" onClick={insertLink}>
          Lien
        </ToolbarButton>
        <ToolbarButton title="Retirer lien" onClick={clearLink}>
          ✕Lien
        </ToolbarButton>

        <div className="mx-2 h-5 w-px bg-gray-300" />

        <ToolbarButton
          title="Annuler"
          onClick={() => editor?.chain().focus().undo().run()}
        >
          ⟲
        </ToolbarButton>
        <ToolbarButton
          title="Rétablir"
          onClick={() => editor?.chain().focus().redo().run()}
        >
          ⟳
        </ToolbarButton>

        <div className="ml-auto relative" ref={pickerRef}>
          <ToolbarButton title="Emoji" onClick={() => setShowEmoji((s) => !s)}>
            😊
          </ToolbarButton>
          {showEmoji && (
            <div className="absolute right-0 top-8 z-50 shadow-xl border bg-white rounded">
              <Picker data={data} onEmojiSelect={insertEmoji} theme="light" />
            </div>
          )}
        </div>
      </div>

      {/* Editor area */}
      <div
        className={`border rounded bg-white max-h-60 overflow-y-auto scroll-area ${disabled ? "opacity-60" : ""}`}
        style={{ minHeight }}
      >
        <EditorContent
          editor={editor}
          className="prose prose-sm max-w-none p-2 outline-none"
        />
      </div>
    </div>
  );
}

/* -------------------- Main Component -------------------- */
/**
 * Props:
 *  - messages: Array<{ visitorId, from: 'visitor'|'agent', message, timestamp }>
 *  - visitor: { visitorId: string } | string | null
 *  - onSend: (html: string) => void    <-- we Envoyer HTML now
*/
export default function ChatWindow({ messages, visitor, onSend }) {
  const currentVisitorId = (typeof visitor === 'string') ? visitor : (visitor && visitor.visitorId) || null;
  const [composerHtml, setComposerHtml] = useState("");
  const [composerText, setComposerText] = useState("");
  const [genLoading, setGenLoading] = useState(false);
  const [genReq, setGenReq] = useState("");
  const [genError, setGenError] = useState("");
  // Bot behavior: 'manual' | 'auto_draft' | 'auto_reply'
  const [botBehavior, setBotBehavior] = useState('manual');
  // Optional extra context (UI removed per request; kept for API compatibility if needed later)
  const [extraCtx] = useState("");
  const [draft, setDraft] = useState({ html: "", text: "" });

  const listRef = useRef(null);
  const restorePendingRef = useRef(false);

  const msgs = useMemo(
    () => messages.filter((m) => m.visitorId === currentVisitorId),
    [messages, currentVisitorId]
  );

  // Expose for manual debugging from console
  useEffect(() => {
    try { window.__lastMsgs = msgs; } catch {}
  }, [msgs]);

  // Debug helper: enable with `window.DEBUG_CHAT = true` in the browser console.
  useEffect(() => {
    try {
      if (!window.DEBUG_CHAT) return;
      const sample = msgs.slice(-5).map((m) => ({
        from: m.from,
        sender: m.sender,
        author: m.author,
        role: m.role,
        agentId: m.agentId,
        type: m.type,
        action: m.action,
        has_html: !!(m.html || m.content_html),
        html_len: (m.html || m.content_html || '').length || 0,
        message_preview: typeof m.message === 'string' ? m.message.slice(0, 120) : m.message,
      }));
      console.log('[DEBUG_CHAT] last messages for visitor', currentVisitorId, sample);
    } catch {}
  }, [msgs, currentVisitorId]);

  // Index of the last visitor message (for placing the IA button)
  const lastVisitorIndex = useMemo(() => {
    for (let k = msgs.length - 1; k >= 0; k--) {
      if (msgs[k]?.from !== 'agent') return k;
    }
    return -1;
  }, [msgs]);

  // Scroll behavior: default to bottom unless we're restoring a saved position
  useEffect(() => {
    if (!listRef.current) return;
    if (restorePendingRef.current) return;
    listRef.current.scrollTop = listRef.current.scrollHeight + 999;
  }, [messages, currentVisitorId, draft]);

  // Save/restore composer drafts and scroll positions per visitor (optional)
  useEffect(() => {
    // Restore draft and scroll when visitor changes
    const flags = (loadUIState() && loadUIState().flags) || {};
    const st = loadModuleState('chat') || {};
    if (!currentVisitorId) return;
    // Drafts
    if (flags.persist_drafts && st.draftByVisitor && st.draftByVisitor[currentVisitorId]) {
      const d = st.draftByVisitor[currentVisitorId];
      if (typeof d.html === 'string') setComposerHtml(d.html);
      if (typeof d.text === 'string') setComposerText(d.text);
    }
    // Scroll
    if (flags.restore_scroll && st.scrollByVisitor && st.scrollByVisitor[currentVisitorId] != null) {
      try {
        restorePendingRef.current = true;
        const top = Number(st.scrollByVisitor[currentVisitorId] || 0);
        setTimeout(() => {
          if (listRef.current) listRef.current.scrollTop = top;
          restorePendingRef.current = false;
        }, 0);
      } catch { restorePendingRef.current = false; }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentVisitorId]);

  // Persist composer drafts on change
  useEffect(() => {
    const flags = (loadUIState() && loadUIState().flags) || {};
    if (!flags.persist_drafts || !currentVisitorId) return;
    try {
      const st = loadModuleState('chat') || {};
      const drafts = { ...(st.draftByVisitor || {}) };
      drafts[currentVisitorId] = { html: composerHtml, text: composerText };
      saveModuleState('chat', { draftByVisitor: drafts });
    } catch {}
  }, [composerHtml, composerText, currentVisitorId]);

  // Persist scroll on scroll
  useEffect(() => {
    const onScroll = () => {
      const flags = (loadUIState() && loadUIState().flags) || {};
      if (!flags.restore_scroll || !currentVisitorId) return;
      try {
        const st = loadModuleState('chat') || {};
        const map = { ...(st.scrollByVisitor || {}) };
        map[currentVisitorId] = (listRef.current && listRef.current.scrollTop) || 0;
        saveModuleState('chat', { scrollByVisitor: map });
      } catch {}
    };
    const el = listRef.current;
    if (!el) return;
    el.addEventListener('scroll', onScroll);
    return () => el.removeEventListener('scroll', onScroll);
  }, [currentVisitorId]);

  const handleSend = () => {
    const htmlCandidate = (composerHtml || "").trim();
    const textCandidate = (composerText || "").trim();
    if (!currentVisitorId || (!htmlCandidate && !textCandidate)) return;

    // If only plain text, wrap & autolink
    const finalHtml =
      htmlCandidate ||
      `<p>${escapeHtmlWithAutolink(textCandidate).replace(/\n/g, "<br>")}</p>`;

    onSend(finalHtml);

    // reset
    setComposerHtml("");
    setComposerText("");
    setDraft({ html: "", text: "" });
  };

  const handleKey = (e) => {
    // Send on Ctrl+Enter (TipTap handles plain Enter as newline)
    if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      handleSend();
    }
  };

  // Load chatbot behavior for this visitor (to know when to show the button)
  useEffect(() => {
    let abort = false;
    async function loadBehavior() {
      try {
        if (!currentVisitorId) return;
        const r = await fetch(`/api/assistant/config?visitorId=${encodeURIComponent(currentVisitorId)}`);
        const j = await r.json().catch(() => ({}));
        if (!abort && j && (j.bot_behavior || j.bot_behavior === '')) {
          setBotBehavior(j.bot_behavior || 'manual');
        } else if (!abort) {
          setBotBehavior('manual');
        }
      } catch {
        if (!abort) setBotBehavior('manual');
      }
    }
    loadBehavior();
    return () => {
      abort = true;
    };
  }, [currentVisitorId]);

  // Listen for automatic drafts pushed by the server when bot_behavior = 'auto_draft'
  useEffect(() => {
    const onAssistantDraft = (payload) => {
      try {
        const vid = payload && (payload.visitorId || payload.visitor_id);
        const text = payload && (payload.draft || payload.text || "");
        if (!vid || vid !== currentVisitorId || !text) return;
        const html = mdToHtmlLite(String(text));
        setDraft({ html, text: String(text) });
        // Preload into composer for quick edit
        setComposerHtml(html);
        setComposerText("");
      } catch {}
    };
    socket.on('assistant_draft', onAssistantDraft);
    return () => { socket.off('assistant_draft', onAssistantDraft); };
  }, [currentVisitorId]);

  // Ask draft
  const askAssistantDraft = async () => {
    if (!currentVisitorId || genLoading) return;
    setGenError("");
    setGenReq("");
    setGenReq("");
    setGenLoading(true);
    try {
      const r = await fetch("/api/assistant/draft", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          visitorId: currentVisitorId,
          extraContext: extraCtx || undefined,
          prefer: "html",
        }),
      });
      const data = await r.json();
      if (!r.ok || data.ok === false)
        throw new Error(data?.error || data?.draft || "Erreur Assistant");
      const norm = normalizeDraft(data);
      if (norm.html) {
        setDraft(norm);
        try { setGenReq(JSON.stringify(data.request_body || data.request || {}, null, 2)); } catch { setGenReq(""); }
        // also preload into composer for quick edit/Envoyer
        setComposerHtml(norm.html);
        setComposerText("");
      } else {
        setGenError("L'assistant n'a pas renvoyé de brouillon.");
      }
    } catch (e) {
      setGenError(e.message || "Impossible de générer un brouillon");
    } finally {
      setGenLoading(false);
    }
  };

  // Draft actions
  const insertDraftAtCursor = () => {
    if (!draft.html) return;
    setComposerHtml((prev) =>
      prev ? `${prev}<p><br/></p>${draft.html}` : draft.html
    );
  };
  const replaceWithDraft = () => {
    if (!draft.html) return;
    setComposerHtml(draft.html);
    setComposerText("");
  };
  const copyDraft = async () => {
    try {
      await navigator.clipboard.writeText(draft.text || draft.html || "");
    } catch {}
  };

  return (
    <div className="chat-window" onKeyDown={handleKey}>
      {/* Header */}
      <div className="px-4 py-3 border-b flex items-center justify-between">
        <div className="font-semibold">
          {currentVisitorId
            ? `Conversation - ${currentVisitorId.slice(0, 8)}…`
            : "Aucune conversation"}
        </div>
        {/* Top AI controls removed per request */}
      </div>

      {/* Draft block */}
      {false && draft.html && (
        <section className="chat-window__draft">
          <div className="chat-window__draft-head">
            <span className="chat-window__draft-title">Assistant draft</span>
            <span className="chat-window__draft-hint">Review and tweak before Envoyering.</span>
          </div>
          <div
            className="chat-window__draft-content"
            dangerouslySetInnerHTML={{ __html: draft.html }}
          />
          <div className="chat-window__draft-actions">
            <button type="button" className="chip chip--outline" onClick={insertDraftAtCursor}>
              Insert into editor
            </button>
            <button type="button" className="chip chip--outline" onClick={replaceWithDraft}>
              Replace my text
            </button>
            <button type="button" className="chip chip--outline" onClick={copyDraft}>
              Copy
            </button>
            <button
              type="button"
              className="chip chip--outline"
              onClick={() => setDraft({ html: "", text: "" })}
            >
              Dismiss
            </button>
          </div>
        </section>
      )}

      {/* (Contexte additionnel UI supprimé) */}

      {/* Quick debug button */}
      <div className="flex justify-end px-4">
        <button
          type="button"
          className="chip chip--outline"
          onClick={() => {
            try {
              window.__lastMsgs = msgs;
              console.log('[DEBUG_CHAT] last 5 messages', (msgs || []).slice(-5));
            } catch {}
          }}
          title="Dump last 5 messages to console"
        >
          Debug
        </button>
      </div>

      {/* Messages — scrollable */}
      <div
        ref={listRef}
        className="flex-1 overflow-y-scroll overscroll-contain p-4 space-y-2 scroll-area"
        style={{ minHeight: 0 }}
      >
        {!currentVisitorId && (
          <div className="text-sm text-gray-500">
            Sélectionnez une conversation.
          </div>
        )}
        {currentVisitorId && msgs.length === 0 && (
          <div className="text-sm text-gray-500">
            Aucun message pour ce visiteur.
          </div>
        )}
{  msgs.map((m, i) => {
    const fromVal = String(m.from || m.sender || m.author || '').toLowerCase();
    const isVisitor = ["visitor", "client", "user", "customer"].includes(fromVal);
    const hasHtml = (
      (typeof m.html === 'string' && m.html.trim().length > 0) ||
      (typeof m.content_html === 'string' && m.content_html.trim().length > 0) ||
      /<\s*\w+[^>]*>/.test(String(m.message || m.content || ''))
    );
    const mine = (
      String(m.role || '').toLowerCase() === 'agent' ||
      String(m.sender || '').toLowerCase() === 'agent' ||
      fromVal === 'agent' ||
      (m.agentId != null) ||
      String(m.action || '').toLowerCase().includes('agent') ||
      String(m.type || '').toLowerCase().includes('agent') ||
      (!isVisitor && hasHtml)
    );
    const ts = m.timestamp ? new Date(m.timestamp).toLocaleString() : "";
    const showIA = !mine && i === lastVisitorIndex && botBehavior === 'manual' && !!currentVisitorId;
    return (
      <div
        key={i}
        className={`w-full flex ${mine ? "pr-3" : "pl-3"}`}
        style={{ justifyContent: mine ? 'flex-end' : 'flex-start' }}
      >
        <div
          className={`chat-row ${mine ? "mine text-right" : "theirs"}`}
          style={mine ? { marginLeft: 'auto', alignItems: 'flex-end', textAlign: 'right' } : { alignItems: 'flex-start' }}
        >
          <div
            className={`chat-bubble ${mine ? "agent self-end" : "visitor"}`}
            title={ts}
          >
          {mine ? (
            <div
              className="prose prose-invert prose-sm max-w-none chat-html"
              dangerouslySetInnerHTML={{ __html: sanitizeAgentHtml((() => {
                const raw = m.html || m.content_html || m.message || '';
                // If backend sent escaped tags (e.g., &lt;p&gt;), decode first
                return /&lt;\s*\w+[^>]*>/i.test(raw) ? decodeEscapedHtml(raw) : raw;
              })()) }}
            />
          ) : (
            <div
              className="chat-html"
              dangerouslySetInnerHTML={{ __html: (m.html || m.content_html || escapeHtmlWithAutolink(m.message || m.content || '')) }}
            />
          )}
          </div>

          <div className={`msg-ts ${mine ? "text-right" : "text-left"}`}>
            {formatTs(m.timestamp)}
          </div>

          {showIA && (
            <div className="mt-1">
              <button
                onClick={askAssistantDraft}
                className="text-[11px] px-2 py-0.5 rounded bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50"
                disabled={genLoading}
                title="Demander à l’IA de proposer une réponse"
              >
                {genLoading ? "Génération…" : "Proposer une réponse (IA)"}
              </button>
              {genError && (
                <div className="mt-1 text-[11px] text-red-600">{genError}</div>
              )}
              {!!genReq && (
                <div className="mt-1">
                  <div className="text-[11px] text-gray-600">OpenAI Request (effective)</div>
                  <pre className="text-[11px] bg-gray-50 border rounded p-2 whitespace-pre-wrap max-h-48 overflow-auto">{genReq}</pre>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }) }



      </div>

      {/* Composer — rich editor with emoji/links */}
      <footer className="chat-window__composer">
        <InlineRichEditor
          valueHtml={composerHtml}
          onChange={(html, text) => {
            setComposerHtml(html);
            setComposerText(text);
          }}
          disabled={!currentVisitorId}
          minRows={5}
        />
        <div className="mt-2 flex justify-end">
          <button
            onClick={handleSend}
            className="chat-window__send"
            disabled={
              !currentVisitorId ||
              (!composerText.trim() && !composerHtml.trim())
            }
            title="Ctrl/Cmd + Enter to Envoyer"
          >
            Envoyer
          </button>
        </div>
      </footer>
    </div>
  );
}











