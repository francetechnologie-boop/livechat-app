export { default } from "../../../automation-suite/frontend/components/TransferConfigMaker.jsx";

