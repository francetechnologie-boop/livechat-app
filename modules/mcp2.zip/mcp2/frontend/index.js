export { default as Main } from "./pages/Admin.jsx";
export { default } from "./pages/Admin.jsx";

