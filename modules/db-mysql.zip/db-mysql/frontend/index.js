export { default as Main } from './pages/Profiles.jsx';
export { default as Profiles } from './pages/Profiles.jsx';
