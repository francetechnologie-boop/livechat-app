import fs from 'fs';
import path from 'path';

function backendDirFromModule() {
  const here = path.resolve(path.dirname(new URL(import.meta.url).pathname));
  const repoRootGuess = path.resolve(here, '../../../../');
  const candidate = path.join(repoRootGuess, 'backend');
  try { if (fs.existsSync(candidate)) return candidate; } catch {}
  try { const cwd = process.cwd(); if (fs.existsSync(path.join(cwd, 'package.json'))) return cwd; } catch {}
  return candidate;
}

export function registerPrestaImportRoutes(app, ctx = {}) {
  const pool = ctx.pool;
  const getSetting = ctx.getSetting || (async () => null);
  const log = (m) => { try { ctx.logToFile?.(`[tmp_presta:import] ${m}`); } catch {} };
  const extras = ctx.extras || {};
  const backendDir = backendDirFromModule();
  const jeromeDir = path.join(backendDir, 'uploads', 'grabbing-jerome');
  try { fs.mkdirSync(jeromeDir, { recursive: true }); } catch {}
  const transfersFile = path.join(jeromeDir, 'transfers.json');
  const loadPrestaTransfers = () => { try { const t = fs.readFileSync(transfersFile, 'utf8'); const arr = JSON.parse(t||'[]'); return Array.isArray(arr)? arr: []; } catch { return []; } };
  const savePrestaTransfers = (items) => { try { fs.writeFileSync(transfersFile, JSON.stringify(Array.isArray(items)? items: [], null, 2), 'utf8'); } catch {} };
  const publicBaseFromReq = (req) => { try { if (typeof extras.publicBaseFromReq === 'function') return extras.publicBaseFromReq(req); const proto = (req.headers['x-forwarded-proto'] || req.protocol || 'http').toString(); const host = (req.headers['x-forwarded-host'] || req.headers['host'] || '').toString(); if (!host) return ''; return `${proto}://${host}`.replace(/\/$/, ''); } catch { return ''; } };

  // Port of server.js: POST /api/presta/products/import (lightly adapted)
  app.post('/api/presta/products/import', async (req, res) => {
    let conn = null;
    try {
      const body = req.body || {};
      const data = body.data || {};
      const source_file = String(body.source_file||'');
      const wantDebug = true;
      const debugLog = { tables: [], data: {}, queries: [] };
      const normalizeMoney = (n) => { const x = Number(n); if (!Number.isFinite(x)) return 0; if ((Number.isInteger(x) && x >= 100) || x >= 1000) return Math.round((x / 100) * 100) / 100; return x; };
      const toAbsUrl = (u) => { try { const s = String(u||'').trim(); if (!s) return ''; if (/^https?:\/\//i.test(s)) return s; const base = publicBaseFromReq(req) || ''; if (base) return new URL(s, base).toString(); return s; } catch { return String(u||''); } };

      // Resolve Presta DB config
      let cfg = null;
      try { const active = await getSetting('PRESTA_DB_ACTIVE'); if (active) { const profilesRaw = await getSetting('PRESTA_DB_PROFILES'); const profiles = profilesRaw ? JSON.parse(profilesRaw) : []; const prof = Array.isArray(profiles) ? profiles.find(x => x && x.name === active) : null; if (prof) cfg = { ...prof }; } } catch {}
      if (!cfg) { try { const raw = await getSetting('PRESTA_DB_JSON'); cfg = raw ? JSON.parse(raw) : null; } catch {} }
      if (!cfg || !cfg.host || !cfg.user || !cfg.database) {
        // Fallback: just record transfer
        const id_product = Math.abs([...String(data?.product?.sku||data?.meta?.title||Date.now())].reduce((a,c)=>((a<<5)-a+c.charCodeAt(0))|0,0)) || Math.floor(100000+Math.random()*900000);
        const rec = { when: new Date().toISOString(), id_product, product_url: String(data?.page?.url || data?.meta?.url || ''), image: (Array.isArray(data?.product?.images) && data.product.images.length ? data.product.images[0] : (data?.meta?.image || '')), price: normalizeMoney(data?.product?.price || 0) || '', currency: String(data?.product?.currency || ''), declinaison: (data?.product?.sku ? `SKU: ${data.product.sku}` : '-'), file: source_file || '', name: String(data?.product?.name || data?.meta?.title || '') };
        try { if (pool) await pool.query('insert into grabbing_jerome_transfers(when_at,id_product,product_url,image,price,currency,declinaison,file,name) values($1,$2,$3,$4,$5,$6,$7,$8,$9)', [new Date(rec.when), rec.id_product, rec.product_url, rec.image, rec.price||null, rec.currency||null, rec.declinaison||null, rec.file||'', rec.name||'']); } catch {}
        const items = loadPrestaTransfers(); items.unshift(rec); savePrestaTransfers(items);
        return res.json({ ok:true, id_product, transfer: rec, note:'no_presta_db_configured' });
      }

      const mysql2 = await import('mysql2/promise');
      conn = await mysql2.createConnection({ host: cfg.host, port: Number(cfg.port||3306), user: cfg.user, password: cfg.password, database: cfg.database, multipleStatements: true });
      try { if (conn && typeof conn.execute === 'function' && !conn.__dbgWrap) { const orig = conn.execute.bind(conn); conn.__dbgWrap = true; conn.execute = async (sql, params=[]) => { const entry = { sql: String(sql||''), params: Array.isArray(params)? params: [] }; try { (debugLog.queries||(debugLog.queries=[])).push(entry); } catch {} try { const r = await orig(sql, params); try { entry.ok = true; } catch {} return r; } catch (e) { try { entry.ok = false; entry.error = e?.message || String(e); } catch {} throw e; } }; } } catch {}

      // Extract incoming data
      const product = data?.product || {};
      const sku = String(product?.sku || '').trim();
      const currency = String(product?.currency || '').trim() || 'EUR';
      const priceRaw = normalizeMoney(product?.price || 0);
      const name = String(product?.name || data?.meta?.title || 'imported-product').trim();
      const description = String(product?.description || '').trim();
      const idCategory = Number(product?.category_id || 2);
      const idManufacturer = Number(product?.manufacturer_id || 0);
      const idSupplier = Number(product?.supplier_id || 0);
      const idLang = Number(product?.lang_id || 1);
      const idShops = Array.isArray(product?.shops) && product.shops.length ? product.shops.map(Number) : [1];
      const idShopDefault = idShops[0] || 1;
      const visibility = 'both';
      const taxGroupId = Number(product?.tax_rules_group || 0) || 0;
      const activeFlag = product?.active === false ? 0 : 1;
      let price = priceRaw;

      const pfx = String(cfg.prefix || cfg.table_prefix || '').trim() || 'ps_';

      // Ensure manufacturer & supplier rows exist
      const ensureRef = async (table, nameCol, idCol, nameVal) => {
        if (!nameVal) return null;
        let id = null;
        try { const [r] = await conn.execute(`SELECT ${idCol} AS id FROM \`${pfx}${table}\` WHERE ${nameCol}=? LIMIT 1`, [nameVal]); if (Array.isArray(r) && r.length) id = r[0].id; } catch {}
        if (!id) { const [ins] = await conn.execute(`INSERT INTO \`${pfx}${table}\` (${nameCol}) VALUES (?)`, [nameVal]); id = ins.insertId || null; }
        return id;
      };
      const supplierName = String(product?.supplier || '').trim();
      const manufacturerName = String(product?.manufacturer || '').trim();
      const supplierId = await ensureRef('supplier', 'name', 'id_supplier', supplierName) || idSupplier;
      const manufacturerId = await ensureRef('manufacturer', 'name', 'id_manufacturer', manufacturerName) || idManufacturer;

      // Create product
      let idProduct = 0;
      if (sku) {
        try { const [r] = await conn.execute(`SELECT id_product FROM \`${pfx}product\` WHERE reference=? LIMIT 1`, [sku]); if (Array.isArray(r) && r.length && r[0].id_product) idProduct = Number(r[0].id_product)||0; } catch {}
      }
      if (!idProduct) {
        const tryInsert = async (id) => { return await conn.execute(`INSERT INTO \`${pfx}product\` (id_product,id_manufacturer,id_supplier,id_category_default,id_shop_default,reference,price,id_tax_rules_group,active,date_add,date_upd,isbn,upc,ean13,mpn) VALUES (?,?,?,?,?,?,?,?,?,NOW(),NOW(),?,?,?,?)`, [id, manufacturerId||0, supplierId||0, idCategory, idShopDefault, sku||null, price, taxGroupId, activeFlag, '', '', '', '']); };
        let next = 1; try { const [r] = await conn.execute(`SELECT IFNULL(MAX(id_product),0)+1 AS next FROM \`${pfx}product\``); next = Number((Array.isArray(r)&&r[0]?.next)||1)||1; } catch {}
        for (let i=0;i<5;i++) { try { const [ins] = await tryInsert(next); idProduct = ins.insertId || next; break; } catch (e) { const code = e && (e.code || e.errno); if (String(code)==='ER_DUP_ENTRY' || Number(code)===1062) { next++; continue; } throw e; } }
        if (!idProduct) { const [ins] = await tryInsert(next); idProduct = ins.insertId || next; }
      } else {
        const [insProd] = await conn.execute(`INSERT INTO \`${pfx}product\` (id_manufacturer,id_supplier,id_category_default,id_shop_default,reference,price,id_tax_rules_group,active,date_add,date_upd,isbn,upc,ean13,mpn) VALUES (?,?,?,?,?,?,?,?,NOW(),NOW(),?,?,?,?)`, [manufacturerId||0, supplierId||0, idCategory, idShopDefault, sku||null, price, taxGroupId, activeFlag, '', '', '', '']);
        idProduct = insProd.insertId;
      }

      for (const s of idShops) {
        await conn.execute(`INSERT INTO \`${pfx}product_shop\` (id_product,id_shop,id_category_default,price,active,visibility,id_tax_rules_group,date_upd,date_add) VALUES (?,?,?,?,?,?,?,NOW(),NOW())`, [idProduct, s, idCategory, price, activeFlag, visibility, taxGroupId]);
      }
      try { const [chkPs] = await conn.execute(`SELECT COUNT(*) AS c FROM \`${pfx}product_shop\` WHERE id_product=?`, [idProduct]); const countPs = Array.isArray(chkPs) && chkPs.length ? Number(chkPs[0].c||0) : 0; if (!countPs) { const [activeShops] = await conn.execute(`SELECT id_shop FROM \`${pfx}shop\` WHERE active=1`); const fallbacks = (Array.isArray(activeShops)? activeShops: []).map(r=>Number(r.id_shop||0)).filter(n=>n>0); for (const s of fallbacks) { await conn.execute(`INSERT INTO \`${pfx}product_shop\` (id_product,id_shop,id_category_default,price,active,visibility,id_tax_rules_group,date_upd,date_add) VALUES (?,?,?,?,?,?,?,NOW(),NOW())`, [idProduct, s, idCategory, price, activeFlag, visibility, taxGroupId]); } } } catch {}
      let hasIdShop = false; try { const [cols] = await conn.execute(`SHOW COLUMNS FROM \`${pfx}product_lang\``); hasIdShop = Array.isArray(cols) && cols.some(c => (c.Field||c.COLUMN_NAME) === 'id_shop'); } catch {}
      if (hasIdShop) { for (const s of idShops) { await conn.execute(`INSERT INTO \`${pfx}product_lang\` (id_product,id_shop,id_lang,name,description,description_short,link_rewrite) VALUES (?,?,?,?,?,?,?)`, [idProduct, s, idLang, name, description, '', name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'').slice(0,128)||'imported-product']); try { await conn.execute(`UPDATE \`${pfx}product_lang\` SET meta_title=?, meta_description=? WHERE id_product=? AND id_shop=? AND id_lang=?`, [name.slice(0,128), (data?.meta?.description||'').slice(0,512), idProduct, s, idLang]); } catch {} } } else { await conn.execute(`INSERT INTO \`${pfx}product_lang\` (id_product,id_lang,name,description,description_short,link_rewrite) VALUES (?,?,?,?,?,?)`, [idProduct, idLang, name, description, '', name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'').slice(0,128)||'imported-product']); try { await conn.execute(`UPDATE \`${pfx}product_lang\` SET meta_title=?, meta_description=? WHERE id_product=? AND id_lang=?`, [name.slice(0,128), (data?.meta?.description||'').slice(0,512), idProduct, idLang]); } catch {} }

      // TODO: Add images upload and associations if needed (out of scope for now)

      // Log transfer
      const record = { when: new Date().toISOString(), id_product: idProduct, product_url: String(data?.page?.url || data?.meta?.url || ''), image: (Array.isArray(data?.product?.images) && data.product.images.length ? data.product.images[0] : (data?.meta?.image || '')), price, currency, declinaison: (sku ? `SKU: ${sku}` : '-'), file: source_file || '', name };
      try { if (pool) await pool.query('insert into grabbing_jerome_transfers(when_at,id_product,product_url,image,price,currency,declinaison,file,name) values($1,$2,$3,$4,$5,$6,$7,$8,$9)', [new Date(record.when), record.id_product, record.product_url, record.image, record.price||null, record.currency||null, record.declinaison||null, record.file||'', record.name||'']); } catch {}
      const items = loadPrestaTransfers(); items.unshift(record); savePrestaTransfers(items);
      const out = { ok:true, id_product: idProduct, transfer: record, debug: wantDebug ? debugLog : undefined };
      return res.status(201).json(out);
    } catch (e) { log(`import_failed ${e?.message||e}`); return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
    finally { try { await conn?.end?.(); } catch {} }
  });
}

