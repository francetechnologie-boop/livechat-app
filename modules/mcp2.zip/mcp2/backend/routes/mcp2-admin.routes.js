// Use local admin routes (no tmp bridge)
export { registerMcp2Routes } from './admin.routes.js';
