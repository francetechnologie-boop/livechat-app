export async function onModuleLoaded({ module }) { try { console.log(`[visitor-list] Loaded: ${module?.name||'visitor-list'}`); } catch {} }
export async function onModuleDisabled({ module }) { try { console.log(`[visitor-list] Disabled: ${module?.name||'visitor-list'}`); } catch {} }

