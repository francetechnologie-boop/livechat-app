export async function onModuleLoaded({ module }) {
  try { console.log(`[tmp_mcp_admin] Loaded: ${module?.name || 'tmp_mcp_admin'}`); } catch {}
}
export async function onModuleDisabled({ module }) {
  try { console.log(`[tmp_mcp_admin] Disabled: ${module?.name || 'tmp_mcp_admin'}`); } catch {}
}

