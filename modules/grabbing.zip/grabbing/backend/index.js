import { registerGrabbingRoutes } from './routes/grabbing.routes.js';
import { registerPacketaRoutes } from './routes/packeta.routes.js';
import { registerJeromeRoutes } from './routes/jerome.routes.js';
import { onModuleLoaded } from './hooks.js';
import { installModule } from './installer.js';

export function register(app, ctx) {
  try {
    const key = '/api/grabbing';
    const mounted = (globalThis.__moduleJsonMounted ||= new Set());
    const json = ctx?.expressJson;
    if (typeof json === 'function' && !mounted.has(key)) { app.use(key, json({ limit: String(process.env.API_JSON_LIMIT || '50mb'), strict: false })); mounted.add(key); }
  } catch {}
  // Run module migrations (non-blocking) then hooks
  installModule().catch(() => {});
  onModuleLoaded(ctx).catch(() => {});
  registerGrabbingRoutes(app, ctx);
  registerPacketaRoutes(app, ctx);
  registerJeromeRoutes(app, ctx);
}

// Auto-added ping for compliance
try { app.get('/api/grabbing/ping', (_req, res) => res.json({ ok: true, module: 'grabbing' })); } catch {}
