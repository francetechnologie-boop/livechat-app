export { default as Main } from "./pages/ExamplePage";
export { default as Settings } from "./pages/Settings";

