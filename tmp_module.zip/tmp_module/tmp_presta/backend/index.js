import { registerTmpPrestaRoutes } from './routes/presta.routes.js';
import { registerPrestaTransfersRoutes } from './routes/transfers.routes.js';
import { registerPrestaImportRoutes } from './routes/import.routes.js';

export function register(app, ctx) {
  registerTmpPrestaRoutes(app, ctx);
  registerPrestaTransfersRoutes(app, ctx);
  registerPrestaImportRoutes(app, ctx);
}
