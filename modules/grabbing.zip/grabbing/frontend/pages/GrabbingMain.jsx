import React, { useEffect, useState } from 'react';
import DomainUrls from '../components/DomainUrls.jsx';
import TransferConfigMaker from '../components/TransferConfigMaker.jsx';
import PrestaDbConnection from '../components/PrestaDbConnection.jsx';
import SitemapsTree from '../components/SitemapsTree.jsx';
import PrestaReadyTransfers from '../components/PrestaReadyTransfers.jsx';

export default function GrabbingMain() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  // Domains / config maker
  const [domains, setDomains] = useState([]);
  const [domainQ, setDomainQ] = useState('');
  const [activeDomain, setActiveDomain] = useState('');
  const [cfgText, setCfgText] = useState('');
  const [cfgMsg, setCfgMsg] = useState('');
  const [cfgBusy, setCfgBusy] = useState(false);
  // Latest files
  const [latest, setLatest] = useState([]);
  // Domain management
  const [newDomain, setNewDomain] = useState('');
  const [domMsg, setDomMsg] = useState('');

  const load = async () => {
    setLoading(true); setError('');
    try {
      const r = await fetch('/api/grabbings', { credentials:'include' });
      const j = await r.json();
      if (!r.ok || j?.ok === false) throw new Error(j?.message || j?.error || `http_${r.status}`);
      setItems(Array.isArray(j.items) ? j.items : []);
    } catch (e) { setError(String(e?.message || e)); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);
  useEffect(() => {
    try { window.dispatchEvent(new CustomEvent('app-breadcrumb', { detail: ['Grabbing'] })); } catch {}
  }, []);

  const refreshDomains = async () => {
    try {
      const r = await fetch(`/api/grabbings/jerome/domains?q=${encodeURIComponent(domainQ||'')}&limit=200`, { credentials:'include' });
      const j = await r.json();
      if (r.ok && j?.ok) setDomains(Array.isArray(j.items)? j.items: []);
    } catch {}
  };
  useEffect(() => { refreshDomains(); }, [domainQ]);

  const loadDomainCfg = async (dom) => {
    if (!dom) return; setCfgMsg(''); setCfgBusy(true);
    try {
      const r = await fetch(`/api/grabbings/jerome/domains/config?domain=${encodeURIComponent(dom)}`, { credentials:'include' });
      const j = await r.json();
      if (!r.ok || j?.ok===false) setCfgMsg(j?.message||j?.error||'load_failed');
      else setCfgText(JSON.stringify(j.config||{}, null, 2));
    } catch (e) { setCfgMsg(String(e?.message||e)); }
    finally { setCfgBusy(false); }
  };
  useEffect(() => { if (activeDomain) loadDomainCfg(activeDomain); }, [activeDomain]);

  const saveDomainCfg = async () => {
    if (!activeDomain) { setCfgMsg('Select a domain'); return; }
    setCfgMsg(''); setCfgBusy(true);
    try {
      let parsed = {};
      try { parsed = JSON.parse(cfgText); } catch (e) { setCfgMsg('Invalid JSON: '+(e?.message||e)); setCfgBusy(false); return; }
      const r = await fetch('/api/grabbings/jerome/domains/config', { method:'POST', headers:{'Content-Type':'application/json'}, credentials:'include', body: JSON.stringify({ domain: activeDomain, config: parsed }) });
      const j = await r.json();
      if (!r.ok || j?.ok===false) setCfgMsg(j?.message||j?.error||'save_failed');
      else setCfgMsg('Saved.');
    } catch (e) { setCfgMsg(String(e?.message||e)); }
    finally { setCfgBusy(false); }
  };

  const refreshLatest = async () => {
    try {
      const r = await fetch('/api/grabbings/jerome/latest', { credentials:'include' });
      const j = await r.json();
      if (r.ok && j?.ok) setLatest(Array.isArray(j.items)? j.items: []);
    } catch {}
  };
  useEffect(() => { refreshLatest(); }, []);

  const addDomain = async () => {
    const d = String(newDomain||'').trim();
    if (!d) { setDomMsg('Enter a domain'); return; }
    setDomMsg('');
    try {
      const r = await fetch('/api/grabbing/jerome/domains', { method:'POST', headers:{ 'Content-Type':'application/json' }, credentials:'include', body: JSON.stringify({ domain: d }) });
      const j = await r.json();
      if (!r.ok || j?.ok===false) { setDomMsg(j?.message||j?.error||'add_failed'); return; }
      setNewDomain('');
      await refreshDomains();
      setActiveDomain(j?.item?.domain || d);
    } catch (e) { setDomMsg(String(e?.message||e)); }
  };

  const deleteDomain = async () => {
    if (!activeDomain) { setDomMsg('Select a domain'); return; }
    setDomMsg('');
    try {
      const r = await fetch(`/api/grabbings/jerome/domains/${encodeURIComponent(activeDomain)}`, { method:'DELETE', credentials:'include' });
      const j = await r.json();
      if (!r.ok || j?.ok===false) { setDomMsg(j?.message||j?.error||'delete_failed'); return; }
      setActiveDomain('');
      await refreshDomains();
    } catch (e) { setDomMsg(String(e?.message||e)); }
  };

  return (
    <div className="h-full w-full flex flex-col min-h-0">
      <div className="flex items-center justify-between p-4 border-b bg-white gap-4">
        <div className="flex items-center gap-3">
          <div className="font-semibold">Grabbing</div>
          <div className="text-xs text-gray-500">Jerome Domains</div>
        </div>
        <div className="flex-1 flex items-center gap-2 justify-end">
          {domMsg && <div className="text-xs text-red-600 mr-2">{domMsg}</div>}
          <select value={activeDomain} onChange={(e)=>setActiveDomain(e.target.value)} className="border rounded px-2 py-1 text-sm min-w-[16rem]">
            <option value="">Select domain…</option>
            {(domains||[]).map(d => (
              <option key={d.domain} value={d.domain}>{d.domain}</option>
            ))}
          </select>
          <button onClick={deleteDomain} disabled={!activeDomain} className="px-3 py-1.5 rounded border text-sm disabled:opacity-60">Delete</button>
          <input value={newDomain} onChange={(e)=>setNewDomain(e.target.value)} placeholder="add domain" className="border rounded px-2 py-1 text-sm w-48" />
          <button onClick={addDomain} className="px-3 py-1.5 rounded border bg-white hover:bg-gray-50 text-sm">Add</button>
          <button onClick={()=>{ load(); refreshDomains(); }} className="px-3 py-1.5 rounded border bg-white hover:bg-gray-50 text-sm">Refresh</button>
        </div>
      </div>
      <div className="p-4 overflow-auto space-y-6">
        {loading && <div className="text-sm text-gray-500">Loading…</div>}
        {error && <div className="text-sm text-red-600 mb-2">{error}</div>}
        <table className="min-w-full text-sm">
          <thead className="bg-gray-50 border-b sticky top-0">
            <tr>
              <th className="px-3 py-2 text-left">ID</th>
              <th className="px-3 py-2 text-left">Name</th>
              <th className="px-3 py-2 text-left">Target</th>
              <th className="px-3 py-2 text-left">Enabled</th>
              <th className="px-3 py-2 text-left">Updated</th>
            </tr>
          </thead>
          <tbody>
            {(items||[]).map(it => (
              <tr key={it.id} className="border-b hover:bg-gray-50">
                <td className="px-3 py-2 font-mono">{it.id}</td>
                <td className="px-3 py-2">{it.name}</td>
                <td className="px-3 py-2 truncate max-w-[20rem]" title={it.target||''}>{it.target||'-'}</td>
                <td className="px-3 py-2">{String(!!it.enabled)}</td>
                <td className="px-3 py-2">{it.updated_at || it.created_at || ''}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="panel">
            <div className="panel__header flex items-center justify-between">
              <span>Domains</span>
              <input value={domainQ} onChange={(e)=>setDomainQ(e.target.value)} placeholder="Search domain…" className="border rounded px-2 py-1 text-sm" />
            </div>
            <div className="panel__body space-y-2">
              <select className="w-full border rounded px-2 py-1 text-sm" size={10} value={activeDomain} onChange={(e)=>setActiveDomain(e.target.value)}>
                {(domains||[]).map(d => (
                  <option key={d.domain} value={d.domain}>{d.domain}</option>
                ))}
              </select>
              <button onClick={()=>activeDomain && loadDomainCfg(activeDomain)} className="px-3 py-1.5 rounded border text-sm">Reload config</button>
            </div>
          </div>

          <div className="panel">
            <div className="panel__header flex items-center justify-between">
              <span>Domain Config Maker</span>
              <div className="text-xs text-gray-500">{activeDomain || 'Select a domain'}</div>
            </div>
            <div className="panel__body space-y-2">
              {cfgMsg && <div className="text-xs text-red-600">{cfgMsg}</div>}
              <textarea
                value={cfgText}
                onChange={(e)=>setCfgText(e.target.value)}
                className="w-full h-64 border rounded p-2 font-mono text-xs"
                placeholder={'{\n  "example": true\n}'}
              />
              <div className="flex gap-2">
                <button onClick={saveDomainCfg} disabled={cfgBusy || !activeDomain} className="px-3 py-1.5 rounded bg-indigo-600 text-white text-sm disabled:opacity-60">{cfgBusy?'Saving…':'Save'}</button>
              </div>
            </div>
          </div>
        </div>

        <div className="panel">
          <div className="panel__header">Sitemaps Tree</div>
          <div className="panel__body">
            <SitemapsTree />
          </div>
        </div>

        <div className="panel">
          <div className="panel__header flex items-center justify-between">
            <span>Latest files</span>
            <button onClick={refreshLatest} className="px-3 py-1.5 rounded border text-sm">Refresh</button>
          </div>
          <div className="panel__body">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50 border-b sticky top-0">
                <tr>
                  <th className="px-3 py-2 text-left">Name</th>
                  <th className="px-3 py-2 text-left">Size</th>
                  <th className="px-3 py-2 text-left">When</th>
                </tr>
              </thead>
              <tbody>
                {(latest||[]).map(f => (
                  <tr key={f.name} className="border-b">
                    <td className="px-3 py-2"><a href={f.download_url} target="_blank" rel="noreferrer" className="text-indigo-600 hover:underline">{f.name}</a></td>
                    <td className="px-3 py-2">{f.size}</td>
                    <td className="px-3 py-2">{String(f.mtime)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="panel">
            <div className="panel__header">Domain URLs</div>
            <div className="panel__body">
              <DomainUrls activeDomain={activeDomain} onChangeDomain={setActiveDomain} />
            </div>
          </div>
          <div className="panel">
            <div className="panel__header">Transfer Config</div>
            <div className="panel__body">
              <TransferConfigMaker activeDomain={activeDomain} onChangeDomain={setActiveDomain} />
            </div>
          </div>
        </div>

        <div className="panel">
          <div className="panel__header">Presta Ready Transfers</div>
          <div className="panel__body">
            <PrestaReadyTransfers />
          </div>
        </div>

        <div className="panel">
          <div className="panel__header">Presta DB Connection</div>
          <div className="panel__body">
            <PrestaDbConnection />
          </div>
        </div>
      </div>
    </div>
  );
}
