export function registerVisitorListRoutes(app, ctx = {}) {
  const pool = ctx.pool;
  const requireAuth = ctx.requireAuth || ((_req, res) => { res.status(401).json({ error: 'unauthorized' }); return null; });

  app.get('/api/visitor-list/ping', (_req, res) => res.json({ ok: true, module: 'visitor-list' }));

  // List recent visitors (best-effort, uses messages or visits when present)
  app.get('/api/visitor-list/visitors', async (req, res) => {
    const me = requireAuth(req, res); if (!me || !pool) return;
    try {
      const limit = Math.max(1, Math.min(200, Number(req.query.limit || 50)));
      const tables = await pool.query(`SELECT to_regclass('public.messages') AS m, to_regclass('public.visits') AS v`);
      const hasMessages = !!(tables.rows?.[0]?.m);
      const hasVisits = !!(tables.rows?.[0]?.v);
      if (!hasMessages && !hasVisits) return res.json({ ok:true, items: [] });
      if (hasMessages) {
        const r = await pool.query(`
          SELECT visitor_id::text AS visitor_id, MAX(created_at) AS last_seen,
                 COUNT(*)::int AS message_count
          FROM public.messages
          WHERE visitor_id IS NOT NULL
          GROUP BY visitor_id
          ORDER BY last_seen DESC
          LIMIT $1
        `, [limit]);
        return res.json({ ok:true, items: r.rows || [] });
      }
      if (hasVisits) {
        const r = await pool.query(`
          SELECT visitor_id::text AS visitor_id, MAX(occurred_at) AS last_seen,
                 COUNT(*)::int AS visit_count
          FROM public.visits
          WHERE visitor_id IS NOT NULL
          GROUP BY visitor_id
          ORDER BY last_seen DESC
          LIMIT $1
        `, [limit]);
        return res.json({ ok:true, items: r.rows || [] });
      }
      res.json({ ok:true, items: [] });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error' }); }
  });

  // Visitor detail (recent messages)
  app.get('/api/visitor-list/visitors/:id/messages', async (req, res) => {
    const me = requireAuth(req, res); if (!me || !pool) return;
    try {
      const vid = String(req.params.id || '').trim();
      const limit = Math.max(1, Math.min(200, Number(req.query.limit || 50)));
      const hasMessages = !!(await pool.query(`SELECT to_regclass('public.messages') AS o`)).rows?.[0]?.o;
      if (!hasMessages) return res.json({ ok:true, items: [] });
      const r = await pool.query(`
        SELECT id, visitor_id::text AS visitor_id, from_user, content, created_at
        FROM public.messages
        WHERE visitor_id = $1
        ORDER BY created_at DESC
        LIMIT $2
      `, [vid, limit]);
      res.json({ ok:true, items: r.rows || [] });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error' }); }
  });

  // Notes (module-owned storage)
  app.get('/api/visitor-list/notes', async (req, res) => {
    const me = requireAuth(req, res); if (!me || !pool) return;
    try {
      const vid = String(req.query.visitor_id || '').trim();
      if (!vid) return res.json({ ok:true, items: [] });
      const r = await pool.query(`SELECT id, org_id, visitor_id, note, created_at, updated_at
                                  FROM public.mod_visitor_list_notes
                                  WHERE visitor_id = $1
                                  ORDER BY created_at DESC
                                  LIMIT 200`, [vid]);
      res.json({ ok:true, items: r.rows || [] });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error' }); }
  });
  app.post('/api/visitor-list/notes', async (req, res) => {
    const me = requireAuth(req, res); if (!me || !pool) return;
    try {
      const b = req.body || {};
      const vid = String(b.visitor_id || '').trim();
      const note = (b.note != null) ? String(b.note) : '';
      if (!vid || !note) return res.status(400).json({ ok:false, error:'invalid_payload' });
      const org = me.org_id || null;
      const r = await pool.query(`INSERT INTO public.mod_visitor_list_notes(org_id, visitor_id, note)
                                  VALUES ($1,$2,$3)
                                  RETURNING id, org_id, visitor_id, note, created_at, updated_at`, [org, vid, note]);
      res.json({ ok:true, item: r.rows?.[0] });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error' }); }
  });
}
