export async function onModuleLoaded({ module }) {
  try { console.log(`[tmp_gateway] Loaded: ${module?.name || 'tmp_gateway'}`); } catch {}
}
export async function onModuleDisabled({ module }) {
  try { console.log(`[tmp_gateway] Disabled: ${module?.name || 'tmp_gateway'}`); } catch {}
}

