-- Chat module minimal config table (idempotent)
-- Prefix: mod_chat_*

CREATE TABLE IF NOT EXISTS mod_chat_config (
  id SERIAL PRIMARY KEY,
  org_id INT NULL,
  key TEXT NOT NULL,
  value JSONB NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  CONSTRAINT uq_mod_chat_config UNIQUE (org_id, key)
);

-- Optional FK to organizations(id) when type matches; adaptive to TEXT/INT schemas
DO $$
DECLARE
  org_id_type TEXT;
  has_text_col BOOLEAN := FALSE;
BEGIN
  SELECT data_type INTO org_id_type
    FROM information_schema.columns
   WHERE table_name='organizations' AND column_name='id'
   LIMIT 1;

  IF org_id_type ILIKE 'integer' OR org_id_type ILIKE 'bigint' THEN
    BEGIN
      ALTER TABLE mod_chat_config
        ADD CONSTRAINT fk_mod_chat_config_org
        FOREIGN KEY (org_id) REFERENCES organizations(id)
        ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED;
    EXCEPTION WHEN duplicate_object THEN NULL; WHEN undefined_table THEN NULL; WHEN others THEN NULL; END;
  ELSIF org_id_type ILIKE 'text' OR org_id_type ILIKE 'character varying' THEN
    -- Add a TEXT companion column and attach a TEXT FK for mixed environments
    IF NOT EXISTS (
      SELECT 1 FROM information_schema.columns
       WHERE table_name='mod_chat_config' AND column_name='org_id_text'
    ) THEN
      BEGIN
        ALTER TABLE mod_chat_config ADD COLUMN org_id_text TEXT NULL;
      EXCEPTION WHEN duplicate_column THEN NULL; WHEN others THEN NULL; END;
    END IF;
    BEGIN
      ALTER TABLE mod_chat_config
        ADD CONSTRAINT fk_mod_chat_config_org_text
        FOREIGN KEY (org_id_text) REFERENCES organizations(id)
        ON DELETE SET NULL DEFERRABLE INITIALLY DEFERRED;
    EXCEPTION WHEN duplicate_object THEN NULL; WHEN undefined_table THEN NULL; WHEN others THEN NULL; END;
  END IF;
END $$;
