import React, { useEffect, useState, useCallback } from "react";
import { socket } from "@app-lib/socket";
import ChatWindow from "./ChatWindow.jsx";

function normalizeVisitor(v) {
  if (!v) return null;
  const visitorId = v.visitorId ?? v.visitor_id ?? v.id ?? v.visitor ?? "";
  if (!visitorId) return null;
  return { ...v, visitorId };
}

function ChatPanel() {
  const [visitors, setVisitors] = useState([]);
  const [selectedVisitor, setSelectedVisitor] = useState(null);
  const [messagesByVisitor, setMessagesByVisitor] = useState({});

  // Initial visitors (optional; your backend doesn’t have this yet)
  useEffect(() => {
    fetch("/api/visitors/recent")
      .then((res) => res.json())
      .then((rows) => {
        const list = (rows || []).map(normalizeVisitor).filter(Boolean);
        setVisitors(list);
      })
      .catch(() => {});
  }, []);

  const onVisitorUpdate = useCallback((v) => {
    const nv = normalizeVisitor(v);
    if (!nv) return;
    setVisitors((prev) => {
      const filtered = (prev || []).filter((x) => x && x.visitorId !== nv.visitorId);
      return [nv, ...filtered];
    });
  }, []);

  const onDashboardMessage = useCallback((msg) => {
    if (!msg) return;
    const vid = msg.visitorId ?? msg.visitor_id ?? "";
    if (!vid) return;
    setMessagesByVisitor((prev) => {
      const current = prev[vid] || [];
      if (msg.id && current.some((m) => m && m.id === msg.id)) return prev;
      return { ...prev, [vid]: [...current, { ...msg, visitorId: vid }] };
    });
  }, []);

  useEffect(() => {
    socket.off("visitor_update", onVisitorUpdate);
    socket.off("dashboard_message", onDashboardMessage);
    socket.on("visitor_update", onVisitorUpdate);
    socket.on("dashboard_message", onDashboardMessage);
    return () => {
      socket.off("visitor_update", onVisitorUpdate);
      socket.off("dashboard_message", onDashboardMessage);
    };
  }, [onVisitorUpdate, onDashboardMessage]); // previously set correctly here. :contentReference[oaicite:3]{index=3}

  useEffect(() => {
    if (!selectedVisitor?.visitorId) return;
    const vid = selectedVisitor.visitorId;
    fetch(`/api/conversations/${vid}/messages`)
      .then((res) => res.json())
      .then((rows) => {
        const msgs = (rows || []).map((m) => ({
          ...m,
          id: m.id || m.msg_id,
          visitorId: vid,
          from: m.from || m.sender,
          html: m.html || m.content_html,
          message: m.message || m.content,
        }));
        setMessagesByVisitor((prev) => ({ ...prev, [vid]: msgs }));
      })
      .catch(() => {});
  }, [selectedVisitor]);

  return (
    <div className="chat-panel">
      <div className="visitor-list">
        <h3>Visiteurs en ligne</h3>
        {(visitors || []).filter(Boolean).map((v) => {
          const vid = v.visitorId;
          if (!vid) return null;
          return (
            <div
              key={vid}
              onClick={() => setSelectedVisitor({ ...v, visitorId: vid })}
              className={selectedVisitor?.visitorId === vid ? "selected" : ""}
            >
              {vid} — {v.shop_name || "Shop"}
            </div>
          );
        })}
      </div>

      <div className="chat-window">
        {selectedVisitor?.visitorId ? (
          <ChatWindow
            visitor={selectedVisitor}
            messages={messagesByVisitor[selectedVisitor.visitorId] || []}
            onSend={(text) => {
              const vid = selectedVisitor.visitorId;
              if (!vid) return;
              socket.emit("chat_message", {
                from: "agent",
                visitorId: vid,
                message: text,
                timestamp: Date.now(),
              });
            }}
          />
        ) : (
          <p>Sélectionnez un visiteur</p>
        )}
      </div>
    </div>
  );
}

export default ChatPanel;
