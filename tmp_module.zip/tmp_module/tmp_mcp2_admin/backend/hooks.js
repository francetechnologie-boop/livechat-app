export async function onModuleLoaded({ module }) {
  try { console.log(`[tmp_mcp2_admin] Loaded: ${module?.name || 'tmp_mcp2_admin'}`); } catch {}
}
export async function onModuleDisabled({ module }) {
  try { console.log(`[tmp_mcp2_admin] Disabled: ${module?.name || 'tmp_mcp2_admin'}`); } catch {}
}

