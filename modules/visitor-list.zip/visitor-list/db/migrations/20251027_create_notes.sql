-- Visitor List: module-owned notes table
CREATE TABLE IF NOT EXISTS public.mod_visitor_list_notes (
  id SERIAL PRIMARY KEY,
  org_id TEXT NULL,
  visitor_id TEXT NOT NULL,
  note TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_mod_visitor_list_notes_org ON public.mod_visitor_list_notes(org_id);
CREATE INDEX IF NOT EXISTS idx_mod_visitor_list_notes_vid ON public.mod_visitor_list_notes(visitor_id);

