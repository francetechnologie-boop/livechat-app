import React, { useEffect, useState } from "react";
import { Icons } from "./icons.jsx";

export default function SidebarTree({ parent, level = 1, className = "", onSelect }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = async () => {
    setLoading(true); setError(null);
    try {
      const params = new URLSearchParams();
      params.set('level', String(level||1));
      if (parent) params.set('parent_entry_id', parent);
      const res = await fetch('/api/sidebar/tree?' + params.toString());
      if (!res.ok) throw new Error('fetch_failed');
      const j = await res.json();
      setItems(Array.isArray(j.items) ? j.items : []);
    } catch (e) {
      setError(e?.message || 'Erreur');
    } finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [parent, level]);

  if (loading) return <div className={className + " text-xs text-gray-500"}>Chargement…</div>;
  if (error) return <div className={className + " text-xs text-red-600"}>{String(error)}</div>;
  if (!items.length) return null;

  return (
    <ul className={["space-y-2", className].filter(Boolean).join(" ")}> 
      {items.map((it) => (
        <li key={it.entry_id}>
          <button
            className="w-full text-left rounded border border-gray-200 bg-white px-3 py-2 text-sm hover:bg-gray-50 flex items-center gap-2"
            onClick={() => {
              if (typeof onSelect === 'function') onSelect(it);
              else if (it.hash) {
                const next = '#' + String(it.hash).replace(/^#?\/?/, '');
                if (window.location.hash !== next) window.history.replaceState(null, '', next);
              }
            }}
          >
            {it.logo ? (
              <img src={it.logo} alt="logo" className="h-5 w-5 object-contain border rounded" />
            ) : (
              <span className="inline-flex items-center justify-center w-5 h-5 text-gray-600">
                {(() => {
                  const v = it.icon || "";
                  const isUrl = /^\/?[\w\-\/%.]+\.(svg|png|jpg|jpeg)$/.test(v) || /^https?:/i.test(v) || /^data:/i.test(v);
                  if (isUrl) return <img src={v} alt="icon" className="h-4 w-4 object-contain border rounded" />;
                  if (Icons && v && Icons[v]) { const C = Icons[v]; return <C className="h-4 w-4" />; }
                  return <span className="inline-block h-4 w-4 rounded border border-gray-300 opacity-60"></span>;
                })()}
              </span>
            )}
            <span className="truncate">{it.label}</span>
          </button>
        </li>
      ))}
    </ul>
  );
}
