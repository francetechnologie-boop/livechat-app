function shouldForceExit1(modId) {
  try {
    const v1 = String(process.env.CHAT_INSTALLER_EXIT_1 || '').trim();
    if (/^(1|true|yes|exit|fail)$/i.test(v1)) return true;
  } catch {}
  try {
    const v2 = String(process.env.MODULE_INSTALLER_EXIT_1 || '').trim();
    if (/^(1|true|yes|all|any)$/i.test(v2)) return true;
    if (v2 && modId && v2.split(',').map(s=>s.trim().toLowerCase()).includes(String(modId).toLowerCase())) return true;
  } catch {}
  try {
    const v3 = String(process.env.INSTALLER_EXIT_1 || '').trim();
    if (/^(1|true|yes)$/i.test(v3)) return true;
  } catch {}
  return false;
}

export async function onModuleLoaded(ctx = {}) {
  try { console.log(`[chat] Loaded: ${ctx?.module?.name||'chat'}`); } catch {}
  // If test flag is set, upsert status into module manager table with install_error
  try {
    const pool = ctx?.pool;
    const modId = ctx?.module?.name || 'chat';
    if (pool && shouldForceExit1(modId)) {
      await pool.query(`CREATE TABLE IF NOT EXISTS mod_module_manager_modules (
        id_module SERIAL PRIMARY KEY,
        module_name TEXT UNIQUE,
        version VARCHAR(16),
        active SMALLINT NOT NULL DEFAULT 1,
        install SMALLINT NOT NULL DEFAULT 1,
        installed_at TIMESTAMP NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
        has_mcp_tool SMALLINT NOT NULL DEFAULT 0,
        has_profil SMALLINT NOT NULL DEFAULT 0,
        mcp_tools JSONB NULL,
        schema_ok BOOLEAN NULL,
        install_error TEXT NULL
      )`);
      await pool.query(
        `INSERT INTO mod_module_manager_modules (module_name, version, active, install, installed_at, updated_at)
         VALUES ($1,$2,1,1,NOW(),NOW())
         ON CONFLICT (module_name) DO UPDATE SET updated_at=NOW()`,
        [modId, '1.0.0']
      );
      await pool.query(
        `UPDATE mod_module_manager_modules SET install_error=$1, schema_ok=$2, updated_at=NOW() WHERE module_name=$3`,
        ['installer_exit_1', false, modId]
      );
    }
  } catch {}
  // Run installer (may throw if flags set; swallowed to avoid crashing server)
  try {
    const m = await import('./installer.js');
    if (typeof m.installModule === 'function') await m.installModule(ctx);
  } catch {}
}
export async function onModuleDisabled({ module }) { try { console.log(`[chat] Disabled: ${module?.name||'chat'}`); } catch {} }
