import fs from 'fs';
import path from 'path';
import mysql from 'mysql2/promise';

export function registerTmpDbmAiRoutes(app, ctx = {}) {
  const requireAdmin = ctx.requireAdmin || ((_req, res) => { res.status(401).json({ error: 'unauthorized' }); return null; });
  const getSetting = ctx.getSetting || (async () => null);
  const dbSummaryDir = ctx.dbSummaryDir || path.join(process.cwd(), 'uploads', 'db-summaries');
  const log = (m) => { try { ctx.logToFile?.(`[tmp_db_manager] ${m}`); } catch {} };

  function sanitizeFilename(name = '') {
    return String(name).replace(/[^a-zA-Z0-9_.-]+/g, '-').replace(/-+/g, '-').replace(/^-+|-+$/g, '') || 'file';
  }

  async function generateDbSummary(cfg, opts = {}) {
    const dialect = String(cfg?.dialect || 'mysql').toLowerCase();
    if (!['mysql', 'mariadb'].includes(dialect)) throw new Error('Only MySQL/MariaDB supported');
    const host = String(cfg.host || 'localhost');
    const port = Number(cfg.port || 3306);
    const dbName = String(cfg.database || '').trim();
    const user = String(cfg.user || '');
    const password = String(cfg.password || '');
    const ssl = cfg.ssl ? { rejectUnauthorized: false } : undefined;
    if (!dbName) throw new Error('database_not_set');

    const allData = !!(opts.allData || opts.includeAllData);
    const include = {
      tables: opts.tables !== false,
      columns: opts.columns !== false,
      foreignKeys: opts.foreignKeys !== false,
      views: !!opts.views,
      data: !!(opts.data || opts.includeData || allData),
    };
    const sampleRows = (() => { const n = Number(opts.sampleRows || (allData ? 1000000 : 5)); const max = allData ? 1_000_000 : 50; return Number.isFinite(n) ? Math.max(1, Math.min(max, Math.trunc(n))) : (allData ? 1_000_000 : 5); })();
    const sampleTables = (() => { const n = Number(opts.sampleTables || (allData ? 100000 : 10)); const max = allData ? 100_000 : 200; return Number.isFinite(n) ? Math.max(1, Math.min(max, Math.trunc(n))) : (allData ? 100_000 : 10); })();
    const MAX_DATA_TOTAL = (() => { const def = allData ? 2_000_000 : 120_000; const n = Number(opts.maxDataBytes || def); return Number.isFinite(n) ? Math.max(1000, Math.min(20_000_000, Math.trunc(n))) : def; })();
    const MAX_CELL_LEN = (() => { const n = Number(opts.maxCellLen || 160); return Number.isFinite(n) ? Math.max(20, Math.min(2000, Math.trunc(n))) : 160; })();

    const conn = await mysql.createConnection({ host, port, user, password, database: dbName, ssl });
    try {
      const [tables] = include.tables ? await conn.execute(`
        SELECT TABLE_NAME, TABLE_TYPE, ENGINE, TABLE_ROWS, CREATE_TIME, TABLE_COMMENT
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = ?
        ORDER BY TABLE_NAME
      `, [dbName]) : [[]];
      const [cols] = include.columns ? await conn.execute(`
        SELECT TABLE_NAME, COLUMN_NAME, COLUMN_TYPE, DATA_TYPE, IS_NULLABLE, COLUMN_DEFAULT, COLUMN_KEY, EXTRA, COLUMN_COMMENT,
               CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE, ORDINAL_POSITION
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = ?
        ORDER BY TABLE_NAME, ORDINAL_POSITION
      `, [dbName]) : [[]];
      const [fks] = include.foreignKeys ? await conn.execute(`
        SELECT CONSTRAINT_NAME, TABLE_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME
        FROM information_schema.KEY_COLUMN_USAGE
        WHERE TABLE_SCHEMA = ? AND REFERENCED_TABLE_NAME IS NOT NULL
        ORDER BY TABLE_NAME, COLUMN_NAME
      `, [dbName]) : [[]];
      const [views] = include.views ? await conn.execute(`
        SELECT TABLE_SCHEMA AS schema_name, TABLE_NAME AS name, VIEW_DEFINITION AS definition
        FROM information_schema.VIEWS
        WHERE TABLE_SCHEMA = ?
        ORDER BY TABLE_NAME
      `, [dbName]) : [[]];

      const colByTable = new Map();
      for (const c of Array.isArray(cols) ? cols : []) { const t = c.TABLE_NAME; if (!colByTable.has(t)) colByTable.set(t, []); colByTable.get(t).push(c); }
      const fkByTable = new Map();
      for (const fk of Array.isArray(fks) ? fks : []) { const t = fk.TABLE_NAME; if (!fkByTable.has(t)) fkByTable.set(t, []); fkByTable.get(t).push(fk); }

      const nowIso = new Date().toISOString();
      let md = '';
      md += `# Database Overview: ${dbName}\n\n`;
      md += `- Dialect: ${dialect}\n`;
      md += `- Host: ${host}:${port}\n`;
      md += `- Generated at: ${nowIso}\n`;
      const dataNote = include.data ? 'with sample data rows (limited)' : 'no row data';
      md += `\n> This file summarizes the schema (${dataNote}). Use it to answer questions about table meanings, relationships, and where to query.\n`;

      if (Array.isArray(tables) && tables.length) {
        md += `\n## Tables\n`;
        for (const t of tables) {
          const tname = t.TABLE_NAME;
          const type = String(t.TABLE_TYPE || '').toUpperCase();
          md += `\n### ${tname}\n`;
          md += `Type: ${type}\n`;
          if (t.ENGINE) md += `Engine: ${t.ENGINE}\n`;
          if (t.TABLE_ROWS != null) md += `Rows (approx): ${t.TABLE_ROWS}\n`;
          if (t.CREATE_TIME) md += `Created: ${t.CREATE_TIME}\n`;
          if (t.TABLE_COMMENT) md += `Comment: ${t.TABLE_COMMENT}\n`;
          if (include.columns) {
            const colList = (colByTable.get(tname) || []).map((c) => {
              const parts = [];
              parts.push(`${c.COLUMN_NAME}: ${c.COLUMN_TYPE || c.DATA_TYPE}`);
              if (c.IS_NULLABLE === 'NO') parts.push('NOT NULL');
              if (c.COLUMN_DEFAULT != null) parts.push(`DEFAULT ${c.COLUMN_DEFAULT}`);
              if (c.COLUMN_KEY) parts.push(`KEY ${c.COLUMN_KEY}`);
              if (c.EXTRA) parts.push(c.EXTRA);
              if (c.COLUMN_COMMENT) parts.push(`-- ${c.COLUMN_COMMENT}`);
              return `- ${parts.join(' | ')}`;
            });
            if (colList.length) md += `\nColumns:\n` + colList.join('\n') + '\n';
          }
          if (include.foreignKeys) {
            const f = fkByTable.get(tname) || [];
            if (f.length) {
              md += `\nForeign Keys:\n`;
              for (const x of f) md += `- ${x.COLUMN_NAME} → ${x.REFERENCED_TABLE_NAME}.${x.REFERENCED_COLUMN_NAME} (constraint ${x.CONSTRAINT_NAME})\n`;
            }
          }
        }
      }

      if (include.views && Array.isArray(views) && views.length) {
        md += `\n## Views\n`;
        for (const v of views) {
          const vname = v.name || v.TABLE_NAME || '';
          let def = String(v.definition || '').trim();
          const MAX_DEF = 6000;
          if (def.length > MAX_DEF) def = def.slice(0, MAX_DEF) + `\n-- [truncated: ${def.length - MAX_DEF} chars omitted]`;
          md += `\n### ${vname}\n`;
          md += "```sql\n" + def + "\n```\n";
        }
      }

      if (include.data && Array.isArray(tables) && tables.length) {
        const toJsonSafe = (v) => { try { if (v == null) return null; if (Buffer.isBuffer(v)) return `[BLOB ${v.length}b]`; if (v instanceof Date) return v.toISOString(); if (typeof v === 'bigint') return v.toString(); if (typeof v === 'object') return v; let s = String(v); if (s.length > MAX_CELL_LEN) s = s.slice(0, MAX_CELL_LEN) + '.'; return s; } catch { return String(v); } };
        const clipRow = (row) => { const out = {}; for (const [k, v] of Object.entries(row || {})) out[k] = toJsonSafe(v); return out; };
        const isBaseTable = (t) => String(t.TABLE_TYPE || '').toUpperCase() !== 'VIEW';
        const baseTables = tables.filter(isBaseTable).slice().sort((a,b)=> String(a.TABLE_NAME||'').localeCompare(String(b.TABLE_NAME||'')));
        const pick = baseTables.slice(0, sampleTables);
        if (pick.length) {
          md += `\n## Sample Data\n`;
          md += `\n> Up to ${sampleRows} rows per table; limited to ${sampleTables} table(s) to keep the file compact.\n`;
          let used = 0;
          for (const t of pick) {
            const tname = t.TABLE_NAME;
            let section = `\n### ${tname}\n`;
            try {
              const lim = sampleRows;
              const [rows] = await conn.query(`SELECT * FROM \`${dbName}\`.\`${tname}\` LIMIT ${lim}`);
              const arr = Array.isArray(rows) ? rows : [];
              if (!arr.length) section += `No rows.\n`;
              else {
                const clipped = arr.map(clipRow);
                let js = '';
                try { js = JSON.stringify(clipped, null, 2); } catch { js = String(clipped); }
                if (js.length > MAX_DATA_TOTAL) js = js.slice(0, MAX_DATA_TOTAL) + `\n/* truncated */`;
                section += "```json\n" + js + "\n```\n";
              }
            } catch (e) { section += `Error: ${e?.message || String(e)}\n`; }
            if (used + section.length > MAX_DATA_TOTAL) { md += `\n-- [sample data truncated due to size limit]\n`; break; }
            md += section; used += section.length;
          }
        }
      }

      const ts = new Date();
      const pad = (n)=> String(n).padStart(2,'0');
      const stamp = `${ts.getFullYear()}${pad(ts.getMonth()+1)}${pad(ts.getDate())}-${pad(ts.getHours())}${pad(ts.getMinutes())}${pad(ts.getSeconds())}`;
      const fname = sanitizeFilename(`mydb-summary-${dbName}-${stamp}.md`);
      const fpath = path.join(dbSummaryDir, fname);
      await fs.promises.writeFile(fpath, md, 'utf8');
      const stats = await fs.promises.stat(fpath).catch(()=>null);
      return { filename: fname, path: fpath, size: stats?.size || md.length, content: md };
    } finally {
      try { await conn.end(); } catch {}
    }
  }

  const DBM_CFG_KEY = 'DBM_CONFIG_JSON';

  app.post('/api/db-manager/ai/summary', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const raw = await getSetting(DBM_CFG_KEY);
      const cfg = raw ? JSON.parse(raw) : null;
      if (!cfg) return res.status(400).json({ ok:false, error:'no_config', message:'Configure DB Manager first.' });
      const opts = req.body || {};
      const out = await generateDbSummary(cfg, opts);
      return res.status(201).json({ ok:true, ...out });
    } catch (e) {
      return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) });
    }
  });

  app.get('/api/db-manager/ai/summary/:filename', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const fname = sanitizeFilename(String(req.params.filename||''));
      const fpath = path.join(dbSummaryDir, fname);
      if (!fs.existsSync(fpath)) return res.status(404).json({ ok:false, error:'not_found' });
      res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${fname}"`);
      fs.createReadStream(fpath).pipe(res);
    } catch (e) {
      return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) });
    }
  });
}

