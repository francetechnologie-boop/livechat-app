// Minimal MCP2 transport endpoints to validate connectivity with Inspector
// - GET /mcp2/:name/events  -> SSE test stream
// - GET /mcp2/:name/stream  -> NDJSON streaming test

export function registerMcp2TransportRoutes(app, ctx = {}) {
  const pool = ctx.pool;
  // In-memory stream sessions: name -> sessionId -> { res, createdAt }
  const sessions = new Map();

  async function getServerByName(nameIn) {
    try { return await findServerByName(nameIn); } catch { return null; }
  }

  function parseOptions(opt) {
    try { return typeof opt === 'string' ? JSON.parse(opt) : (opt || {}); } catch { return {}; }
  }

  function resolveUpstreamUrl(server) {
    try {
      if (!server) return '';
      const opt = parseOptions(server.options || server.opts || {});
      const u = opt.upstream_mcp_url || opt.upstreamUrl || '';
      if (u && typeof u === 'string') return u;
      // Fallback: if http_base already points to an MCP path
      const base = String(server.http_base || '').trim();
      if (base && /\/mcp(\/?$)/i.test(base)) return base;
    } catch {}
    return '';
  }

  async function findServerByName(nameIn) {
    if (!pool) return null;
    const raw = String(nameIn || '').trim();
    const decoded = (() => { try { return decodeURIComponent(raw); } catch { return raw; } })();
    const looksId = /^m2srv_/.test(decoded);
    const sanitize = (s) => s.replace(/[^A-Za-z0-9_-]+/g, '_').replace(/_+/g, '_').replace(/^_+|_+$/g, '');
    const candidates = [decoded, sanitize(decoded)];
    try {
      if (looksId) {
        const r = await pool.query(`SELECT id, name, token, http_base, stream_url, sse_url, options FROM mod_mcp2_server WHERE id = $1 LIMIT 1`, [decoded]);
        if (r.rowCount) return r.rows[0];
      }
      // Exact or case-insensitive match on name
      for (const n of candidates) {
        const r1 = await pool.query(`SELECT id, name, token, http_base, stream_url, sse_url, options FROM mod_mcp2_server WHERE name = $1 LIMIT 1`, [n]);
        if (r1.rowCount) return r1.rows[0];
        const r2 = await pool.query(`SELECT id, name, token, http_base, stream_url, sse_url, options FROM mod_mcp2_server WHERE lower(name) = lower($1) LIMIT 1`, [n]);
        if (r2.rowCount) return r2.rows[0];
      }
      // Fallback: match by URL tail
      for (const n of candidates) {
        const r3 = await pool.query(
          `SELECT id, name, token, http_base, stream_url, sse_url, options
             FROM mod_mcp2_server
            WHERE (stream_url ILIKE '%'||$1||'/stream') OR (sse_url ILIKE '%'||$1||'/events')
            ORDER BY updated_at DESC LIMIT 1`, [decoded]
        );
        if (r3.rowCount) return r3.rows[0];
      }
      return null;
    } catch { return null; }
  }

  function pickToken(req) {
    // Accept a variety of common header names used by different MCP clients
    // Never log header values here (avoid leaking secrets)
    try {
      const h = String((req.headers && (req.headers['authorization'] || req.headers['Authorization'])) || '').trim();
      if (/^bearer\s+/i.test(h)) return h.replace(/^bearer\s+/i, '').trim();
    } catch (e) {}
    try {
      const x = String((req.headers && (req.headers['x-api-key'] || req.headers['X-Api-Key'] || req.headers['x-authorization'] || req.headers['x-access-token'] || req.headers['mcp-token'] || req.headers['x-mcp-token'])) || '').trim();
      if (x) return x;
    } catch (e) {}
    try {
      const q = (req.query && (req.query.token || req.query.mcp_token)) ? String(req.query.token || req.query.mcp_token).trim() : '';
      if (q) return q;
    } catch (e) {}
    return '';
  }

  function isAuthorizedToken(server, provided) {
    try {
      const required = String(server?.token || '');
      if (!required) return true; // no per-server token set
      const t = String(provided || '').trim();
      if (t && t === required) return true;
      const globalTok = String(process?.env?.MCP_TOKEN || '').trim();
      if (globalTok && t && t === globalTok) return true;
      return false;
    } catch { return false; }
  }

  // SSE endpoint
  app.get('/mcp2/:name/events', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      const server = await findServerByName(name);
      if (!server) return res.status(404).json({ ok:false, error:'not_found' });
      const t = pickToken(req);
      if (server && String(server.token || '')) {
        if (!isAuthorizedToken(server, t)) return res.status(401).json({ ok:false, error:'unauthorized' });
      }
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      try { if (typeof res.flushHeaders === 'function') res.flushHeaders(); } catch (e) {}

      const send = (event, data) => {
        if (event) res.write(`event: ${event}\n`);
        res.write(`data: ${JSON.stringify(data)}\n\n`);
      };
      send('hello', { ok:true, name, transport:'sse', ts: Date.now() });
      const iv = setInterval(() => send('ping', { ts: Date.now() }), 10000);
      req.on('close', () => { clearInterval(iv); try { res.end(); } catch {} });
    } catch (e) {
      try { res.status(500).json({ ok:false, error:'server_error', message: (e && e.message) || String(e) }); } catch {}
    }
  });

  // Streamable-HTTP style: send newline-delimited JSON chunks and keep connection open
  app.get('/mcp2/:name/stream', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      const server = await findServerByName(name);
      if (!server) return res.status(404).json({ ok:false, error:'not_found' });
      const t = pickToken(req);
      if (server && String(server.token || '')) {
        if (!isAuthorizedToken(server, t)) return res.status(401).json({ ok:false, error:'unauthorized' });
      }
      res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      try { if (typeof res.flushHeaders === 'function') res.flushHeaders(); } catch (e) {}
      const write = (obj) => { try { res.write(JSON.stringify(obj) + "\n"); } catch {} };
      // Register session
      const sessionId = Math.random().toString(16).slice(2) + Date.now().toString(36);
      const byName = sessions.get(server.name) || new Map();
      byName.set(sessionId, { res, createdAt: Date.now() });
      sessions.set(server.name, byName);

      // Minimal MCP-like hello and tools list
      write({ type: 'server_hello', protocol: 'mcp-stream/0.1', sessionId, caps: { tools: true } });
      write({ type: 'tools', items: [
        { name: 'ping', description: 'Responds with ok:true', input_schema: { type: 'object', additionalProperties: false, properties: {} } },
        { name: 'time.now', description: 'Returns ISO timestamp', input_schema: { type: 'object', additionalProperties: false, properties: {} } },
      ]});

      const iv = setInterval(function(){ write({ type:'ping', ts: Date.now(), sessionId: sessionId }); }, 10000);
      req.on('close', () => {
        clearInterval(iv);
        try { res.end(); } catch {}
        try { const map = sessions.get(server.name); if (map) { map.delete(sessionId); if (!map.size) sessions.delete(server.name); } } catch {}
      });
    } catch (e) {
      try { res.status(500).json({ ok:false, error:'server_error', message: (e && e.message) || String(e) }); } catch {}
    }
  });

  // API-scoped aliases implement the same logic inline (no app._router recursion)
  app.get('/api/mcp2/transport/:name/events', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      const server = await findServerByName(name);
      if (!server) return res.status(404).json({ ok:false, error:'not_found' });
      const t = pickToken(req);
      if (String(server.token || '') && t !== String(server.token)) return res.status(401).json({ ok:false, error:'unauthorized' });
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      try { if (typeof res.flushHeaders === 'function') res.flushHeaders(); } catch (e) {}
      const send = function(event, data) { if (event) res.write(`event: ${event}\n`); res.write(`data: ${JSON.stringify(data)}\n\n`); };
      send('hello', { ok:true, name, transport:'sse', ts: Date.now() });
      const iv = setInterval(function(){ send('ping', { ts: Date.now() }); }, 10000);
      req.on('close', function(){ clearInterval(iv); try { res.end(); } catch (e) {} });
    } catch (e) { try { res.status(500).json({ ok:false, error:'server_error', message: (e && e.message) || String(e) }); } catch (e2) {} }
  });
  app.get('/api/mcp2/transport/:name/stream', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      const server = await findServerByName(name);
      if (!server) return res.status(404).json({ ok:false, error:'not_found' });
      const t = pickToken(req);
      if (String(server.token || '') && t !== String(server.token)) return res.status(401).json({ ok:false, error:'unauthorized' });
      res.setHeader('Content-Type', 'application/x-ndjson; charset=utf-8');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      try { if (typeof res.flushHeaders === 'function') res.flushHeaders(); } catch (e) {}
      const write = function(obj){ try { res.write(JSON.stringify(obj) + "\n"); } catch (e) {} };
      const sessionId = Math.random().toString(16).slice(2) + Date.now().toString(36);
      const byName = sessions.get(server.name) || new Map();
      byName.set(sessionId, { res, createdAt: Date.now() });
      sessions.set(server.name, byName);
      write({ type: 'server_hello', protocol: 'mcp-stream/0.1', sessionId, caps: { tools: true } });
      write({ type: 'tools', items: [
        { name: 'ping', description: 'Responds with ok:true', input_schema: { type: 'object', additionalProperties: false, properties: {} } },
        { name: 'time.now', description: 'Returns ISO timestamp', input_schema: { type: 'object', additionalProperties: false, properties: {} } },
      ]});
      const iv = setInterval(function(){ write({ type:'ping', ts: Date.now(), sessionId: sessionId }); }, 10000);
      req.on('close', function(){ clearInterval(iv); try { res.end(); } catch (e) {} try { const map = sessions.get(server.name); if (map) { map.delete(sessionId); if (!map.size) sessions.delete(server.name); } } catch (e) {} });
    } catch (e) { try { res.status(500).json({ ok:false, error:'server_error', message: (e && e.message) || String(e) }); } catch (e2) {} }
  });

  // ================= Streamable HTTP (SSE + JSON-RPC) =================
  // Inspector/OpenAI-friendly endpoints under /api/mcp2/stream/:name
  app.get('/api/mcp2/stream/:name', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      // Optional: check token only if a server with a token is configured
      let server = null;
      try { server = await findServerByName(name); } catch {}
      const t = pickToken(req);
      if (server && String(server.token || '')) { if (!isAuthorizedToken(server, t)) return res.status(401).json({ ok:false, error:'unauthorized' }); }

      const sessionId = Math.random().toString(16).slice(2) + Date.now().toString(36);
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      try { res.setHeader('mcp-session-id', sessionId); } catch {}
      try { if (typeof res.flushHeaders === 'function') res.flushHeaders(); } catch {}

      const byName = sessions.get(name) || new Map();
      byName.set(sessionId, { res, createdAt: Date.now() });
      sessions.set(name, byName);

      const iv = setInterval(() => { try { res.write(`: ping ${Date.now()}\n\n`); } catch {} }, 10000);
      req.on('close', () => {
        clearInterval(iv);
        try { res.end(); } catch {}
        try { const map = sessions.get(name); if (map) { map.delete(sessionId); if (!map.size) sessions.delete(name); } } catch {}
      });
    } catch (e) {
      try { res.status(500).json({ ok:false, error:'server_error', message: (e && e.message) || String(e) }); } catch {}
    }
  });

  app.post('/api/mcp2/stream/:name', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      // Optional: check token only if a server with a token is configured
      let server = null;
      try { server = await findServerByName(name); } catch {}
      const t = pickToken(req);
      if (server && String(server.token || '')) {
        if (!isAuthorizedToken(server, t)) return res.status(401).json({ jsonrpc:'2.0', id:null, error: { code: -32001, message: 'unauthorized' } });
      }

      const body = (req.body && typeof req.body === 'object') ? req.body : {};
      if (!(body && typeof body === 'object' && body.jsonrpc === '2.0')) {
        return res.status(400).json({ jsonrpc: '2.0', id: null, error: { code: -32600, message: 'Invalid Request' } });
      }

      const id = body.id ?? null;
      const method = String(body.method || '').trim();
      const params = body.params || {};

      let result;
      if (method === 'initialize') {
        const requestedVersion = String((params && params.protocolVersion) || '2025-06-18');
        result = {
          protocolVersion: requestedVersion,
          serverInfo: { name: `mcp2:${name}`, version: '1.0.0' },
          capabilities: {
            tools: { listChanged: true },
            resources: { subscribe: false, listChanged: false },
            prompts: { listChanged: false },
            logging: {}
          },
        };
        // Echo session id header for clients that expect it
        try { const sid = Math.random().toString(16).slice(2) + Date.now().toString(36); res.setHeader('mcp-session-id', sid); } catch {}
      } else if (method === 'tools/list') {
        result = { tools: [
          { name: 'ping', description: 'Responds with ok:true', input_schema: { type:'object' }, inputSchema: { type:'object' } },
          { name: 'time.now', description: 'Returns ISO timestamp', input_schema: { type:'object' }, inputSchema: { type:'object' } },
          { name: 'db.query', description: 'Run a safe SELECT via Postgres pool', input_schema: { type:'object', properties: { sql: { type:'string' } }, required: ['sql'] }, inputSchema: { type:'object', properties: { sql: { type:'string' } }, required: ['sql'] } },
        ] };
      } else if (method === 'tools/call') {
        const tool = String(params?.name || '').trim();
        const args = params?.arguments || params || {};
        if (tool === 'ping') result = { ok: true };
        else if (tool === 'time.now') result = { now: new Date().toISOString() };
        else if (tool === 'db.query') {
          try {
            if (!pool || typeof pool.query !== 'function') result = { ok:false, error:'db_unavailable' };
            else {
              const sql = String(args.sql || '').trim();
              if (!/^\s*select\b/i.test(sql)) result = { ok:false, error:'only_select_allowed' };
              else {
                const r = await pool.query(sql);
                const rows = (r && Array.isArray(r.rows)) ? r.rows.slice(0, 100) : [];
                const cols = rows[0] ? Object.keys(rows[0]) : [];
                const rc = (r && typeof r.rowCount === 'number') ? r.rowCount : rows.length;
                result = { ok:true, rowCount: rc, columns: cols, rows: rows };
              }
            }
          } catch (e) { result = { ok:false, error: String((e && e.message) || e) }; }
        } else result = { ok:false, error:'unknown_tool' };
      } else if (method === 'resources/list') {
        result = { resources: [] };
      } else if (method === 'resourceTemplates/list' || method === 'resources/templates/list') {
        result = { resourceTemplates: [] };
      } else if (method === 'resources/read') {
        return res.json({ jsonrpc: '2.0', id, error: { code: -32004, message: 'Resource not found' } });
      } else if (method === 'prompts/list') {
        result = { prompts: [] };
      } else {
        return res.json({ jsonrpc: '2.0', id, error: { code: -32601, message: 'Method not found' } });
      }

      const response = { jsonrpc: '2.0', id, result };
      // Fan out JSON-RPC response to any SSE subscribers for this name
      try {
        const map = sessions.get(name);
        if (map) for (const { res: r } of map.values()) { try { r.write(`event: message\n`); r.write(`data: ${JSON.stringify(response)}\n\n`); } catch {} }
      } catch {}
      // Send initialized notification for clients expecting it
      if (method === 'initialize') {
        try {
          const notif = { jsonrpc: '2.0', method: 'initialized', params: {} };
          const map = sessions.get(name);
          if (map) for (const { res: r } of map.values()) { try { r.write(`event: message\n`); r.write(`data: ${JSON.stringify(notif)}\n\n`); } catch {} }
        } catch {}
      }

      return res.json(response);
    } catch (e) {
      return res.status(500).json({ jsonrpc:'2.0', id: null, error: { code: -32000, message: 'server_error', data: String(e?.message || e) } });
    }
  });

  // Unified single-path endpoint (/api/mcp2/:name) that supports
  // GET (SSE) and POST (JSON-RPC) on the same URL for modern MCP clients.
  // This mirrors the behavior of /api/mcp2/stream/:name for compatibility.
  app.get('/api/mcp2/:name', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      // Optional: check token only if a server with a token is configured
      let server = null;
      try { server = await findServerByName(name); } catch {}
      const t = pickToken(req);
      if (server && String(server.token || '')) { if (!isAuthorizedToken(server, t)) return res.status(401).json({ ok:false, error:'unauthorized' }); }

      // If this server is configured to proxy to an upstream MCP URL, stream it through
      const upstream = resolveUpstreamUrl(server);
      if (upstream) {
        try {
          const headers = {};
          // forward auth headers
          if (req.headers['authorization']) headers['authorization'] = String(req.headers['authorization']);
          if (req.headers['x-api-key']) headers['x-api-key'] = String(req.headers['x-api-key']);
          headers['accept'] = 'text/event-stream, application/json';
          const resp = await fetch(upstream, { method: 'GET', headers });
          // Forward status and headers
          res.status(resp.status);
          for (const [k, v] of resp.headers) {
            if (/^content-type$/i.test(k) || /^cache-control$/i.test(k)) res.setHeader(k, v);
          }
          // Default SSE content type when upstream omits
          if (!res.getHeader('Content-Type')) res.setHeader('Content-Type', 'text/event-stream');
          // Pipe body
          const reader = resp.body?.getReader?.();
          if (!reader) { const txt = await resp.text(); res.write(txt); try { return res.end(); } catch { return; } }
          const enc = new TextDecoder();
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            if (value) res.write(value);
          }
          try { return res.end(); } catch { return; }
        } catch (e) {
          return res.status(502).json({ ok:false, error:'upstream_error', message: String(e?.message || e) });
        }
      }

      const sessionId = Math.random().toString(16).slice(2) + Date.now().toString(36);
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      try { res.setHeader('mcp-session-id', sessionId); } catch {}
      try { if (typeof res.flushHeaders === 'function') res.flushHeaders(); } catch {}

      const byName = sessions.get(name) || new Map();
      byName.set(sessionId, { res, createdAt: Date.now() });
      sessions.set(name, byName);

      const iv = setInterval(() => { try { res.write(`: ping ${Date.now()}\n\n`); } catch {} }, 10000);
      req.on('close', () => {
        clearInterval(iv);
        try { res.end(); } catch {}
        try { const map = sessions.get(name); if (map) { map.delete(sessionId); if (!map.size) sessions.delete(name); } } catch {}
      });
    } catch (e) {
      try { res.status(500).json({ ok:false, error:'server_error', message: (e && e.message) || String(e) }); } catch {}
    }
  });

  app.post('/api/mcp2/:name', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      // Optional: check token only if a server with a token is configured
      let server = null; try { server = await findServerByName(name); } catch {}
      const t = pickToken(req);
      if (server && String(server.token || '')) {
        if (t !== String(server.token)) {
          return res.status(401).json({ jsonrpc:'2.0', id:null, error: { code: -32001, message: 'unauthorized' } });
        }
      }

      const body = (req.body && typeof req.body === 'object') ? req.body : {};
      if (!(body && typeof body === 'object' && body.jsonrpc === '2.0')) {
        return res.status(400).json({ jsonrpc: '2.0', id: null, error: { code: -32600, message: 'Invalid Request' } });
      }

      // Proxy to upstream if configured
      const upstream = resolveUpstreamUrl(server);
      if (upstream) {
        try {
          const headers = { 'content-type': 'application/json', 'accept': 'application/json, text/event-stream' };
          if (req.headers['authorization']) headers['authorization'] = String(req.headers['authorization']);
          if (req.headers['x-api-key']) headers['x-api-key'] = String(req.headers['x-api-key']);
          const uresp = await fetch(upstream, { method: 'POST', headers, body: JSON.stringify(body) });
          const text = await uresp.text();
          res.status(uresp.status);
          try { const parsed = JSON.parse(text); return res.json(parsed); } catch { return res.send(text); }
        } catch (e) {
          return res.status(502).json({ jsonrpc:'2.0', id: body.id ?? null, error: { code: -32002, message: 'Upstream proxy error', data: String(e?.message || e) } });
        }
      }

      const id = body.id ?? null;
      const method = String(body.method || '').trim();
      const params = body.params || {};

      let result;
      if (method === 'initialize') {
        const requestedVersion = String((params && params.protocolVersion) || '2025-06-18');
        result = {
          protocolVersion: requestedVersion,
          serverInfo: { name: `mcp2:${name}`, version: '1.0.0' },
          capabilities: {
            tools: { listChanged: true },
            resources: { subscribe: false, listChanged: false },
            prompts: { listChanged: false },
            logging: {}
          },
        };
        // Echo session id header for clients that expect it
        try { const sid = Math.random().toString(16).slice(2) + Date.now().toString(36); res.setHeader('mcp-session-id', sid); } catch {}
      } else if (method === 'tools/list') {
        result = { tools: [
          { name: 'ping', description: 'Responds with ok:true', input_schema: { type:'object' }, inputSchema: { type:'object' } },
          { name: 'time.now', description: 'Returns ISO timestamp', input_schema: { type:'object' }, inputSchema: { type:'object' } },
          { name: 'db.query', description: 'Run a safe SELECT via Postgres pool', input_schema: { type:'object', properties: { sql: { type:'string' } }, required: ['sql'] }, inputSchema: { type:'object', properties: { sql: { type:'string' } }, required: ['sql'] } },
        ] };
      } else if (method === 'tools/call') {
        const tool = String(params?.name || '').trim();
        const args = params?.arguments || params || {};
        if (tool === 'ping') result = { ok: true };
        else if (tool === 'time.now') result = { now: new Date().toISOString() };
        else if (tool === 'db.query') {
          try {
            if (!pool || typeof pool.query !== 'function') result = { ok:false, error:'db_unavailable' };
            else {
              const sql = String(args.sql || '').trim();
              if (!/^\s*select\b/i.test(sql)) result = { ok:false, error:'only_select_allowed' };
              else {
                const r = await pool.query(sql);
                const rows = (r && Array.isArray(r.rows)) ? r.rows.slice(0, 100) : [];
                const cols = rows[0] ? Object.keys(rows[0]) : [];
                const rc = (r && typeof r.rowCount === 'number') ? r.rowCount : rows.length;
                result = { ok:true, rowCount: rc, columns: cols, rows: rows };
              }
            }
          } catch (e) { result = { ok:false, error: String((e && e.message) || e) }; }
        } else {
          return res.json({ jsonrpc: '2.0', id, error: { code: -32601, message: 'Method not found' } });
        }
      } else if (method === 'resources/list') {
        result = { resources: [] };
      } else if (method === 'resourceTemplates/list' || method === 'resources/templates/list') {
        result = { resourceTemplates: [] };
      } else if (method === 'resources/read') {
        return res.json({ jsonrpc: '2.0', id, error: { code: -32004, message: 'Resource not found' } });
      } else if (method === 'prompts/list') {
        result = { prompts: [] };
      } else {
        return res.json({ jsonrpc: '2.0', id, error: { code: -32601, message: 'Method not found' } });
      }

      const response = { jsonrpc: '2.0', id, result };
      // Fan out JSON-RPC response to any SSE subscribers for this name
      try {
        const map = sessions.get(name);
        if (map) for (const { res: r } of map.values()) { try { r.write(`event: message\n`); r.write(`data: ${JSON.stringify(response)}\n\n`); } catch {} }
      } catch {}
      // Send initialized notification for clients expecting it
      if (method === 'initialize') {
        try {
          const notif = { jsonrpc: '2.0', method: 'initialized', params: {} };
          const map = sessions.get(name);
          if (map) for (const { res: r } of map.values()) { try { r.write(`event: message\n`); r.write(`data: ${JSON.stringify(notif)}\n\n`); } catch {} }
        } catch {}
      }

      return res.json(response);
    } catch (e) {
      return res.status(500).json({ jsonrpc:'2.0', id: null, error: { code: -32000, message: 'server_error', data: String(e?.message || e) } });
    }
  });

  // Also support canonical shape /api/mcp2/:name/stream (GET SSE + POST JSON-RPC)
  app.get('/api/mcp2/:name/stream', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      let server = null; try { server = await findServerByName(name); } catch {}
      const t = pickToken(req);
      if (server && String(server.token || '')) { if (!isAuthorizedToken(server, t)) return res.status(401).json({ ok:false, error:'unauthorized' }); }
      const sessionId = Math.random().toString(16).slice(2) + Date.now().toString(36);
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      try { res.setHeader('mcp-session-id', sessionId); } catch {}
      try { if (typeof res.flushHeaders === 'function') res.flushHeaders(); } catch {}
      const byName = sessions.get(name) || new Map();
      byName.set(sessionId, { res, createdAt: Date.now() });
      sessions.set(name, byName);
      const iv = setInterval(() => { try { res.write(`: ping ${Date.now()}\n\n`); } catch {} }, 10000);
      req.on('close', () => { clearInterval(iv); try { res.end(); } catch {} try { const map = sessions.get(name); if (map) { map.delete(sessionId); if (!map.size) sessions.delete(name); } } catch {} });
    } catch (e) { try { res.status(500).json({ ok:false, error:'server_error', message: (e && e.message) || String(e) }); } catch {} }
  });
  app.post('/api/mcp2/:name/stream', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      let server = null; try { server = await findServerByName(name); } catch {}
      const t = pickToken(req);
      if (server && String(server.token || '')) { if (!isAuthorizedToken(server, t)) return res.status(401).json({ jsonrpc:'2.0', id:null, error: { code: -32001, message: 'unauthorized' } }); }
      const body = (req.body && typeof req.body === 'object') ? req.body : {};
      if (!(body && typeof body === 'object' && body.jsonrpc === '2.0')) return res.status(400).json({ jsonrpc: '2.0', id: null, error: { code: -32600, message: 'Invalid Request' } });
      const id = body.id ?? null; const method = String(body.method || '').trim(); const params = body.params || {};
      let result;
      if (method === 'initialize') {
        const requestedVersion = String((params && params.protocolVersion) || '2025-06-18');
        result = { protocolVersion: requestedVersion, serverInfo: { name: `mcp2:${name}`, version: '1.0.0' }, capabilities: { tools: { listChanged: true }, resources: { subscribe: false, listChanged: false }, prompts: { listChanged: false }, logging: {} } };
        try { const sid = Math.random().toString(16).slice(2) + Date.now().toString(36); res.setHeader('mcp-session-id', sid); } catch {}
      } else if (method === 'tools/list') {
        result = { tools: [
          { name: 'ping', description: 'Responds with ok:true', input_schema: { type:'object' }, inputSchema: { type:'object' } },
          { name: 'time.now', description: 'Returns ISO timestamp', input_schema: { type:'object' }, inputSchema: { type:'object' } },
          { name: 'db.query', description: 'Run a safe SELECT via Postgres pool', input_schema: { type:'object', properties: { sql: { type:'string' } }, required: ['sql'] }, inputSchema: { type:'object', properties: { sql: { type:'string' } }, required: ['sql'] } },
        ] };
      } else if (method === 'tools/call') {
        const tool = String(params?.name || '').trim();
        const args = params?.arguments || params || {};
        if (tool === 'ping') result = { ok: true };
        else if (tool === 'time.now') result = { now: new Date().toISOString() };
        else if (tool === 'db.query') {
          try { if (!pool || typeof pool.query !== 'function') result = { ok:false, error:'db_unavailable' }; else { const sql = String(args.sql || '').trim(); if (!/^\s*select\b/i.test(sql)) result = { ok:false, error:'only_select_allowed' }; else { const r = await pool.query(sql); const rows = (r && Array.isArray(r.rows)) ? r.rows.slice(0, 100) : []; const cols = rows[0] ? Object.keys(rows[0]) : []; const rc = (r && typeof r.rowCount === 'number') ? r.rowCount : rows.length; result = { ok:true, rowCount: rc, columns: cols, rows: rows }; } } } catch (e) { result = { ok:false, error: String((e && e.message) || e) }; }
        } else result = { ok:false, error:'unknown_tool' };
      } else if (method === 'resources/list') { result = { resources: [] }; }
      else if (method === 'resourceTemplates/list' || method === 'resources/templates/list') { result = { resourceTemplates: [] }; }
      else if (method === 'resources/read') { return res.json({ jsonrpc: '2.0', id, error: { code: -32004, message: 'Resource not found' } }); }
      else if (method === 'prompts/list') { result = { prompts: [] }; }
      else { return res.json({ jsonrpc: '2.0', id, error: { code: -32601, message: 'Method not found' } }); }
      const response = { jsonrpc: '2.0', id, result };
      try { const map = sessions.get(name); if (map) for (const { res: r } of map.values()) { try { r.write(`event: message\n`); r.write(`data: ${JSON.stringify(response)}\n\n`); } catch {} } } catch {}
      if (method === 'initialize') { try { const notif = { jsonrpc: '2.0', method: 'initialized', params: {} }; const map = sessions.get(name); if (map) for (const { res: r } of map.values()) { try { r.write(`event: message\n`); r.write(`data: ${JSON.stringify(notif)}\n\n`); } catch {} } } catch {} }
      return res.json(response);
    } catch (e) { return res.status(500).json({ jsonrpc:'2.0', id: null, error: { code: -32000, message: 'server_error', data: String(e?.message || e) } }); }
  });

  // Also provide /api/mcp2/:name/events SSE alias
  app.get('/api/mcp2/:name/events', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      let server = null; try { server = await findServerByName(name); } catch {}
      const t = pickToken(req);
      if (server && String(server.token || '')) { if (!isAuthorizedToken(server, t)) return res.status(401).json({ ok:false, error:'unauthorized' }); }
      const sessionId = Math.random().toString(16).slice(2) + Date.now().toString(36);
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache, no-transform');
      res.setHeader('Connection', 'keep-alive');
      try { res.setHeader('mcp-session-id', sessionId); } catch {}
      try { if (typeof res.flushHeaders === 'function') res.flushHeaders(); } catch {}
      const byName = sessions.get(name) || new Map();
      byName.set(sessionId, { res, createdAt: Date.now() });
      sessions.set(name, byName);
      const iv = setInterval(() => { try { res.write(`: ping ${Date.now()}\n\n`); } catch {} }, 10000);
      req.on('close', () => { clearInterval(iv); try { res.end(); } catch {} try { const map = sessions.get(name); if (map) { map.delete(sessionId); if (!map.size) sessions.delete(name); } } catch {} });
    } catch (e) { try { res.status(500).json({ ok:false, error:'server_error', message: (e && e.message) || String(e) }); } catch {} }
  });

  // Client->Server messages (simple tools protocol) — manual JSON body parse (no express import)
  app.post('/mcp2/:name/message', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      const server = await findServerByName(name);
      if (!server) return res.status(404).json({ ok:false, error:'not_found' });
      const t = pickToken(req);
      if (server && String(server.token || '')) { if (!isAuthorizedToken(server, t)) return res.status(401).json({ ok:false, error:'unauthorized' }); }
      // Collect body
      const chunks = [];
      await new Promise((resolve) => { req.on('data', (c)=>chunks.push(c)); req.on('end', resolve); req.on('error', resolve); });
      let body = {};
      try { const buf = Buffer.concat(chunks); if (buf.length) body = JSON.parse(buf.toString('utf8')); } catch {}
      const id = body.id || null;
      const method = String(body.method || '').trim();
      const params = body.params || {};

      let result;
      if (method === 'tools/list') {
        result = { tools: [
          { name: 'ping', description: 'Responds with ok:true', input_schema: { type:'object' } },
          { name: 'time.now', description: 'Returns ISO timestamp', input_schema: { type:'object' } },
          { name: 'db.query', description: 'Run a safe SELECT via Postgres pool', input_schema: { type:'object', properties: { sql: { type:'string' } }, required: ['sql'] } },
        ]};
      } else if (method === 'tools/call') {
        const tool = String((params && params.name) || '').trim();
        if (tool === 'ping') result = { ok: true };
        else if (tool === 'time.now') result = { now: new Date().toISOString() };
        else if (tool === 'db.query') {
          try {
            if (!pool || typeof pool.query !== 'function') result = { ok:false, error:'db_unavailable' };
            else {
              const sql = String((params && params.sql) || '').trim();
              if (!/^\s*select\b/i.test(sql)) result = { ok:false, error:'only_select_allowed' };
              else {
                const r = await pool.query(sql);
                const rows = (r && Array.isArray(r.rows)) ? r.rows.slice(0, 100) : [];
                const cols = rows[0] ? Object.keys(rows[0]) : [];
                const rc = (r && typeof r.rowCount === 'number') ? r.rowCount : rows.length;
                result = { ok:true, rowCount: rc, columns: cols, rows: rows };
              }
            }
          } catch (e) { result = { ok:false, error: String((e && e.message) || e) }; }
        } else {
          result = { ok:false, error:'unknown_tool' };
        }
      } else {
        result = { ok:false, error:'unknown_method' };
      }

      // Fan out result to all sessions for this server (as NDJSON events)
      const out = { type: 'result', id, method, result };
      try {
        const map = sessions.get(server.name);
        if (map) for (const { res: r } of map.values()) { try { r.write(JSON.stringify(out) + '\n'); } catch {} }
      } catch {}
      return res.json({ ok:true, id, method, result });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: (e && e.message) || String(e) }); }
  });

  // API alias for message — handle directly (benefits from server-level JSON parser too)
  app.post('/api/mcp2/transport/:name/message', async (req, res) => {
    try {
      const name = String(req.params.name || '').trim();
      const server = await findServerByName(name);
      if (!server) return res.status(404).json({ ok:false, error:'not_found' });
      const t = pickToken(req);
      if (server && String(server.token || '')) { if (!isAuthorizedToken(server, t)) return res.status(401).json({ ok:false, error:'unauthorized' }); }
      const body = (req.body && typeof req.body === 'object') ? req.body : {};
      const id = body.id || null;
      const method = String(body.method || '').trim();
      const params = body.params || {};

      let result;
      if (method === 'tools/list') {
        result = { tools: [
          { name: 'ping', description: 'Responds with ok:true', input_schema: { type:'object' } },
          { name: 'time.now', description: 'Returns ISO timestamp', input_schema: { type:'object' } },
          { name: 'db.query', description: 'Run a safe SELECT via Postgres pool', input_schema: { type:'object', properties: { sql: { type:'string' } }, required: ['sql'] } },
        ]};
      } else if (method === 'tools/call') {
        const tool = String((params && params.name) || '').trim();
        if (tool === 'ping') result = { ok: true };
        else if (tool === 'time.now') result = { now: new Date().toISOString() };
        else if (tool === 'db.query') {
          try {
            if (!pool || typeof pool.query !== 'function') result = { ok:false, error:'db_unavailable' };
            else {
              const sql = String((params && params.sql) || '').trim();
              if (!/^\s*select\b/i.test(sql)) result = { ok:false, error:'only_select_allowed' };
              else {
                const r = await pool.query(sql);
                const rows = (r && Array.isArray(r.rows)) ? r.rows.slice(0, 100) : [];
                const cols = rows[0] ? Object.keys(rows[0]) : [];
                const rc = (r && typeof r.rowCount === 'number') ? r.rowCount : rows.length;
                result = { ok:true, rowCount: rc, columns: cols, rows: rows };
              }
            }
          } catch (e) { result = { ok:false, error: String((e && e.message) || e) }; }
        } else result = { ok:false, error:'unknown_tool' };
      } else {
        result = { ok:false, error:'unknown_method' };
      }

      const out = { type: 'result', id, method, result };
      try { const map = sessions.get(server.name); if (map) for (const { res: r } of map.values()) { try { r.write(JSON.stringify(out) + '\n'); } catch {} } } catch {}
      return res.json({ ok:true, id, method, result });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: (e && e.message) || String(e) }); }
  });
}
