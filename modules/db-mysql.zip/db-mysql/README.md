# DB Manager MySQL

Module providing MySQL/MariaDB profile management.

- Backend routes under `/api/db-mysql/*` (self-mounted JSON parser)
- Table: `mod_db_mysql_profiles`
- Frontend page exported as `Main` from `frontend/index.js`
- MCP flags: hasMcpTool + hasProfil (see `module.config.json`)

