export function registerTmpGeoRoutes(app, ctx = {}) {
  // Minimal geo lookup using geoip-lite only (module-local; optional dependency)
  async function geoLookup(ip) {
    if (!ip) return { country_code: null, city: null, postcode: null };
    try {
      const mod = await import('geoip-lite');
      const geoip = (mod && (mod.default || mod)) || null;
      const g = geoip && geoip.lookup ? geoip.lookup(ip) : null;
      const cc = (g && g.country) || null;
      const city = (g && g.city) || null;
      const postcode = (g && (g.zip || g.postalCode)) || null;
      return { country_code: cc, city, postcode };
    } catch {
      return { country_code: null, city: null, postcode: null };
    }
  }

  // Public geo endpoint for frontend fallbacks
  // Example: GET /api/geo?ip=109.164.51.45 -> { ip, country_code, city, postal }
  app.get('/api/geo', async (req, res) => {
    try {
      const ip = String(req.query.ip || '').trim();
      if (!ip) return res.status(400).json({ error: 'bad_request', message: 'ip required' });
      const g = await geoLookup(ip);
      return res.json({ ip, country_code: g.country_code, city: g.city, postal: g.postcode });
    } catch (e) {
      res.status(500).json({ error: 'server_error', message: e?.message || String(e) });
    }
  });
}
