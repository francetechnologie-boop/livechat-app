import { registerTmpVisitorsRoutes } from './routes/visitors.routes.js';

export function register(app, ctx) {
  try {
    const key = '/api/visitors';
    const mounted = (globalThis.__moduleJsonMounted ||= new Set());
    const json = ctx?.expressJson;
    if (typeof json === 'function' && !mounted.has(key)) { app.use(key, json({ limit: String(process.env.API_JSON_LIMIT || '50mb'), strict: false })); mounted.add(key); }
  } catch {}
  registerTmpVisitorsRoutes(app, ctx);
}
