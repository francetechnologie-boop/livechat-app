-- Idempotent renames of legacy grabbing_jerome_* tables to module-prefixed names
-- Disabled by default unless RENAME_GRABBING_TO_MOD is truthy
DO $$
DECLARE do_rename boolean;
BEGIN
  BEGIN
    do_rename := lower(coalesce(current_setting('RENAME_GRABBING_TO_MOD', true), '0')) IN ('1','true','yes');
  EXCEPTION WHEN others THEN
    do_rename := false;
  END;
  IF NOT do_rename THEN
    RETURN;
  END IF;
  IF to_regclass('public.grabbing_jerome_queue') IS NOT NULL AND to_regclass('public.mod_grabbing_jerome_queue') IS NULL THEN
    EXECUTE 'ALTER TABLE grabbing_jerome_queue RENAME TO mod_grabbing_jerome_queue';
  END IF;
  IF to_regclass('public.grabbing_jerome_extracts') IS NOT NULL AND to_regclass('public.mod_grabbing_jerome_extracts') IS NULL THEN
    EXECUTE 'ALTER TABLE grabbing_jerome_extracts RENAME TO mod_grabbing_jerome_extracts';
  END IF;
  IF to_regclass('public.grabbing_jerome_transfers') IS NOT NULL AND to_regclass('public.mod_grabbing_jerome_transfers') IS NULL THEN
    EXECUTE 'ALTER TABLE grabbing_jerome_transfers RENAME TO mod_grabbing_jerome_transfers';
  END IF;
  IF to_regclass('public.grabbing_jerome_domains') IS NOT NULL AND to_regclass('public.mod_grabbing_jerome_domains') IS NULL THEN
    EXECUTE 'ALTER TABLE grabbing_jerome_domains RENAME TO mod_grabbing_jerome_domains';
  END IF;
  IF to_regclass('public.grabbing_jerome_domain_config_history') IS NOT NULL AND to_regclass('public.mod_grabbing_jerome_domain_config_history') IS NULL THEN
    EXECUTE 'ALTER TABLE grabbing_jerome_domain_config_history RENAME TO mod_grabbing_jerome_domain_config_history';
  END IF;
  IF to_regclass('public.grabbing_jerome_domain_config_transfert_history') IS NOT NULL AND to_regclass('public.mod_grabbing_jerome_domain_config_transfert_history') IS NULL THEN
    EXECUTE 'ALTER TABLE grabbing_jerome_domain_config_transfert_history RENAME TO mod_grabbing_jerome_domain_config_transfert_history';
  END IF;
  IF to_regclass('public.grabbing_jerome_domains_url') IS NOT NULL AND to_regclass('public.mod_grabbing_jerome_domains_url') IS NULL THEN
    EXECUTE 'ALTER TABLE grabbing_jerome_domains_url RENAME TO mod_grabbing_jerome_domains_url';
  END IF;
  IF to_regclass('public.grabbing_jerome_domains_url_page_explore') IS NOT NULL AND to_regclass('public.mod_grabbing_jerome_domains_url_page_explore') IS NULL THEN
    EXECUTE 'ALTER TABLE grabbing_jerome_domains_url_page_explore RENAME TO mod_grabbing_jerome_domains_url_page_explore';
  END IF;
  IF to_regclass('public.grabbing_jerome_domains_url_ready_transfert') IS NOT NULL AND to_regclass('public.mod_grabbing_jerome_domains_url_ready_transfert') IS NULL THEN
    EXECUTE 'ALTER TABLE grabbing_jerome_domains_url_ready_transfert RENAME TO mod_grabbing_jerome_domains_url_ready_transfert';
  END IF;
END $$ LANGUAGE plpgsql;

-- Compatibility views so legacy code keeps working (safe to create if table exists and view doesn't)
DO $$ BEGIN
  IF to_regclass('public.mod_grabbing_jerome_queue') IS NOT NULL AND to_regclass('public.grabbing_jerome_queue') IS NULL THEN
    EXECUTE 'CREATE VIEW grabbing_jerome_queue AS SELECT * FROM mod_grabbing_jerome_queue';
  END IF;
  IF to_regclass('public.mod_grabbing_jerome_extracts') IS NOT NULL AND to_regclass('public.grabbing_jerome_extracts') IS NULL THEN
    EXECUTE 'CREATE VIEW grabbing_jerome_extracts AS SELECT * FROM mod_grabbing_jerome_extracts';
  END IF;
  IF to_regclass('public.mod_grabbing_jerome_transfers') IS NOT NULL AND to_regclass('public.grabbing_jerome_transfers') IS NULL THEN
    EXECUTE 'CREATE VIEW grabbing_jerome_transfers AS SELECT * FROM mod_grabbing_jerome_transfers';
  END IF;
  IF to_regclass('public.mod_grabbing_jerome_domains') IS NOT NULL AND to_regclass('public.grabbing_jerome_domains') IS NULL THEN
    EXECUTE 'CREATE VIEW grabbing_jerome_domains AS SELECT * FROM mod_grabbing_jerome_domains';
  END IF;
  IF to_regclass('public.mod_grabbing_jerome_domain_config_history') IS NOT NULL AND to_regclass('public.grabbing_jerome_domain_config_history') IS NULL THEN
    EXECUTE 'CREATE VIEW grabbing_jerome_domain_config_history AS SELECT * FROM mod_grabbing_jerome_domain_config_history';
  END IF;
  IF to_regclass('public.mod_grabbing_jerome_domain_config_transfert_history') IS NOT NULL AND to_regclass('public.grabbing_jerome_domain_config_transfert_history') IS NULL THEN
    EXECUTE 'CREATE VIEW grabbing_jerome_domain_config_transfert_history AS SELECT * FROM mod_grabbing_jerome_domain_config_transfert_history';
  END IF;
  IF to_regclass('public.mod_grabbing_jerome_domains_url') IS NOT NULL AND to_regclass('public.grabbing_jerome_domains_url') IS NULL THEN
    EXECUTE 'CREATE VIEW grabbing_jerome_domains_url AS SELECT * FROM mod_grabbing_jerome_domains_url';
  END IF;
  IF to_regclass('public.mod_grabbing_jerome_domains_url_page_explore') IS NOT NULL AND to_regclass('public.grabbing_jerome_domains_url_page_explore') IS NULL THEN
    EXECUTE 'CREATE VIEW grabbing_jerome_domains_url_page_explore AS SELECT * FROM mod_grabbing_jerome_domains_url_page_explore';
  END IF;
  IF to_regclass('public.mod_grabbing_jerome_domains_url_ready_transfert') IS NOT NULL AND to_regclass('public.grabbing_jerome_domains_url_ready_transfert') IS NULL THEN
    EXECUTE 'CREATE VIEW grabbing_jerome_domains_url_ready_transfert AS SELECT * FROM mod_grabbing_jerome_domains_url_ready_transfert';
  END IF;
END $$;
