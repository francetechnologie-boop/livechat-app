export function register(app, ctx) {
  app.get('/api/grabbings/_tmp/ping', (_req, res) => res.json({ ok:true, module: 'tmp_grabbings' }));
}

