import { useEffect, useRef, useState, forwardRef, useImperativeHandle } from "react";
import { EditorContent, useEditor } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Link from "@tiptap/extension-link";
import Placeholder from "@tiptap/extension-placeholder";
import Picker from "@emoji-mart/react";
import data from "@emoji-mart/data";

const ToolbarButton = ({ active, onClick, children, title }) => (
  <button
    type="button"
    onClick={onClick}
    title={title}
    className={`text-xs px-2 py-1 rounded border bg-white hover:bg-gray-50 ${active ? "ring-2 ring-indigo-400" : ""}`}
  >
    {children}
  </button>
);

/**
 * props:
 *  - valueHtml: string (initial/controlled HTML)
 *  - onChange(html, plainText)
 *  - disabled
 *  - minRows (visual height, default 4)
 */
const RichEditor = forwardRef(function RichEditor(
  { valueHtml = "", onChange, disabled = false, minRows = 4 },
  ref
) {
  const [showEmoji, setShowEmoji] = useState(false);
  const pickerRef = useRef(null);

  const editor = useEditor({
    editable: !disabled,
    content: valueHtml || "",
    extensions: [
      StarterKit.configure({
        bulletList: { keepMarks: true, keepAttributes: true },
        orderedList: { keepMarks: true, keepAttributes: true },
      }),
      Link.configure({
        autolink: true,
        openOnClick: false,
        HTMLAttributes: { target: "_blank", rel: "noreferrer" },
      }),
      Placeholder.configure({
        placeholder: "Écrivez votre message (vous pouvez éditer le brouillon proposé)…",
      }),
    ],
    onUpdate({ editor }) {
      const html = editor.getHTML();
      const text = editor.getText();
      onChange?.(html, text);
    },
  });

  useImperativeHandle(ref, () => ({
    setHTML: (html) => editor && editor.commands.setContent(html || "", false),
    getHTML: () => (editor ? editor.getHTML() : ""),
    focus: () => editor && editor.commands.focus(),
    clear: () => editor && editor.commands.clearContent(),
  }));

  // Keep editor in sync if parent updates valueHtml
  useEffect(() => {
    if (!editor) return;
    const current = editor.getHTML();
    if (valueHtml != null && valueHtml !== current) {
      editor.commands.setContent(valueHtml, false);
    }
  }, [valueHtml, editor]);

  useEffect(() => {
    const onDocClick = (e) => {
      if (!pickerRef.current) return;
      if (!pickerRef.current.contains(e.target)) setShowEmoji(false);
    };
    document.addEventListener("click", onDocClick);
    return () => document.removeEventListener("click", onDocClick);
  }, []);

  const insertLink = () => {
    const url = window.prompt("Entrez l’URL du lien :", "https://");
    if (!url) return;
    editor.chain().focus().extendMarkRange("link").setLink({ href: url }).run();
  };

  const clearLink = () => {
    editor.chain().focus().unsetLink().run();
  };

  const insertEmoji = (emoji) => {
    editor.chain().focus().insertContent(emoji.native).run();
    setShowEmoji(false);
  };

  const minHeight = Math.max(44, minRows * 22 + 16); // approx line-height * rows + padding

  return (
    <div className="w-full">
      {/* Toolbar */}
      <div className="flex items-center gap-1 mb-2">
        <ToolbarButton
          title="Gras"
          active={editor?.isActive("bold")}
          onClick={() => editor?.chain().focus().toggleBold().run()}
        >
          G
        </ToolbarButton>
        <ToolbarButton
          title="Italique"
          active={editor?.isActive("italic")}
          onClick={() => editor?.chain().focus().toggleItalic().run()}
        >
          I
        </ToolbarButton>
        <ToolbarButton
          title="Liste à puces"
          active={editor?.isActive("bulletList")}
          onClick={() => editor?.chain().focus().toggleBulletList().run()}
        >
          ••
        </ToolbarButton>
        <ToolbarButton
          title="Liste numérotée"
          active={editor?.isActive("orderedList")}
          onClick={() => editor?.chain().focus().toggleOrderedList().run()}
        >
          1.
        </ToolbarButton>

        <div className="mx-2 h-5 w-px bg-gray-300" />

        <ToolbarButton title="Ajouter un lien" onClick={insertLink}>
          Lien
        </ToolbarButton>
        <ToolbarButton title="Retirer le lien" onClick={clearLink}>
          ✕Lien
        </ToolbarButton>

        <div className="mx-2 h-5 w-px bg-gray-300" />

        <ToolbarButton title="Annuler" onClick={() => editor?.chain().focus().undo().run()}>
          ⟲
        </ToolbarButton>
        <ToolbarButton title="Rétablir" onClick={() => editor?.chain().focus().redo().run()}>
          ⟳
        </ToolbarButton>

        <div className="ml-auto relative" ref={pickerRef}>
          <ToolbarButton title="Emoji" onClick={() => setShowEmoji((s) => !s)}>
            😊
          </ToolbarButton>
          {showEmoji && (
            <div className="absolute right-0 top-8 z-50 shadow-xl border bg-white rounded">
              <Picker data={data} onEmojiSelect={insertEmoji} theme="light" />
            </div>
          )}
        </div>
      </div>

      {/* Editor */}
      <div
        className={`border rounded bg-white ${disabled ? "opacity-60" : ""}`}
        style={{ minHeight }}
      >
        <EditorContent
          editor={editor}
          className="prose prose-sm max-w-none p-2 outline-none"
        />
      </div>
    </div>
  );
});

export default RichEditor;
