import { registerTmpMcpAdminRoutes } from './routes/mcp-admin.routes.js';

export function register(app, ctx) {
  registerTmpMcpAdminRoutes(app, ctx);
}

