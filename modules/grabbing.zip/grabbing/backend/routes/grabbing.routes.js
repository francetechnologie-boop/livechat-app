export function registerGrabbingRoutes(app, ctx = {}) {
  const requireAdmin = ctx.requireAdmin || ((_req, res) => { res.status(401).json({ error: 'unauthorized' }); return null; });
  const pool = ctx.pool;
  const log = (m) => { try { ctx.logToFile?.(`[grabbing] ${m}`); } catch {} };

  async function ensureTables() {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS mod_grabbing_config (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        target TEXT,
        options JSONB,
        enabled BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);
  }

  app.post('/api/grabbing/config', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      await ensureTables();
      const b = req.body || {};
      const id = (String(b.id||'').trim()) || `grb_${Date.now()}`;
      const name = String(b.name || b.title || id).trim();
      const target = (typeof b.target === 'string' && b.target.trim()) || null;
      const enabled = b.enabled === undefined ? true : !!b.enabled;
      let options = null; try { if (b.options && typeof b.options==='object') options = b.options; else if (typeof b.options==='string' && b.options.trim()) options = JSON.parse(b.options); } catch {}
      const r = await pool.query(`
        INSERT INTO mod_grabbing_config (id, name, target, options, enabled, created_at, updated_at)
        VALUES ($1,$2,$3,$4::jsonb,$5,NOW(),NOW())
        ON CONFLICT (id)
        DO UPDATE SET name=EXCLUDED.name, target=EXCLUDED.target, options=EXCLUDED.options, enabled=EXCLUDED.enabled, updated_at=NOW()
        RETURNING *
      `, [id, name, target, JSON.stringify(options||{}), enabled]);
      res.json({ ok:true, item: r.rows[0] });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  app.get('/api/grabbing/config/:id', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { await ensureTables(); const id = String(req.params.id||'').trim(); const r = await pool.query(`SELECT * FROM mod_grabbing_config WHERE id=$1 LIMIT 1`, [id]); if (!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' }); return res.json({ ok:true, item: r.rows[0] }); }
    catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  app.patch('/api/grabbing/config/:id', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      await ensureTables();
      const id = String(req.params.id||'').trim();
      const b = req.body || {};
      const ent = Object.entries(b).filter(([k]) => ['name','title','target','options','enabled'].includes(k));
      if (!ent.length) return res.status(400).json({ ok:false, error:'bad_request' });
      const entries = ent.map(([k,v]) => [k==='title'?'name':k, v]);
      const sets = entries.map(([k],i)=> (k==='options'?`${k} = $${i+1}::jsonb`:`${k} = $${i+1}`));
      const vals = entries.map(([k,v]) => (k==='options' && v && typeof v==='object' ? JSON.stringify(v) : v));
      const r = await pool.query(`UPDATE mod_grabbing_config SET ${sets.join(', ')}, updated_at=NOW() WHERE id = $${vals.length+1} RETURNING *`, [...vals, id]);
      if (!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' });
      return res.json({ ok:true, item: r.rows[0] });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  app.delete('/api/grabbing/config/:id', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { await ensureTables(); const id = String(req.params.id||'').trim(); await pool.query(`DELETE FROM mod_grabbing_config WHERE id=$1`, [id]); return res.json({ ok:true }); }
    catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Aliases compatible with Automation Suite UI (server.js decoupled)
  // List grabbings
  app.get('/api/grabbings', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      await ensureTables();
      const r = await pool.query(`SELECT id, name, target, options, enabled, created_at, updated_at FROM mod_grabbing_config ORDER BY updated_at DESC`);
      return res.json({ ok:true, items: r.rows });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  // Create grabbing
  app.post('/api/grabbings', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      await ensureTables();
      const b = req.body || {};
      const id = (String(b.id||'').trim()) || `grb_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,8)}`;
      const name = String(b.name || b.title || '').trim();
      if (!name) return res.status(400).json({ ok:false, error:'bad_request', message:'name required' });
      const target = (typeof b.target==='string' && b.target.trim()) || null;
      let options = null; try { if (b.options && typeof b.options==='object' && !Array.isArray(b.options)) options = b.options; else if (typeof b.options==='string' && b.options.trim()) options = JSON.parse(b.options); } catch {}
      const enabled = b.enabled === undefined ? true : !!b.enabled;
      try {
        const r = await pool.query(`INSERT INTO mod_grabbing_config (id, name, target, options, enabled, created_at, updated_at) VALUES ($1,$2,$3,$4::jsonb,$5,NOW(),NOW()) RETURNING id, name, target, options, enabled, created_at, updated_at`, [id, name, target, JSON.stringify(options||{}), enabled]);
        return res.json({ ok:true, item: r.rows[0] });
      } catch (e) {
        if (e && (e.code === '23505' || /duplicate key value/i.test(String(e.message||'')))) {
          try {
            const r2 = await pool.query(`SELECT id, name, target, options, enabled, created_at, updated_at FROM mod_grabbing_config WHERE name = $1 LIMIT 1`, [name]);
            if (r2.rowCount) return res.json({ ok:true, item: r2.rows[0], existed: true });
          } catch {}
        }
        return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) });
      }
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  // Get one
  app.get('/api/grabbings/:id', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      await ensureTables();
      const id = String(req.params.id||'').trim();
      const r = await pool.query(`SELECT id, name, target, options, enabled, created_at, updated_at FROM mod_grabbing_config WHERE id=$1 LIMIT 1`, [id]);
      if (!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' });
      return res.json({ ok:true, item: r.rows[0] });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  // Update
  app.patch('/api/grabbings/:id', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      await ensureTables();
      const id = String(req.params.id||'').trim();
      const b = req.body || {};
      const ent = Object.entries(b).filter(([k]) => ['name','title','target','options','enabled'].includes(k));
      if (!ent.length) return res.status(400).json({ ok:false, error:'bad_request' });
      const entries = ent.map(([k,v]) => [k==='title'?'name':k, v]);
      const sets = entries.map(([k],i)=> (k==='options'?`${k} = $${i+1}::jsonb`:`${k} = $${i+1}`));
      const vals = entries.map(([k,v]) => (k==='options' && v && typeof v==='object' ? JSON.stringify(v) : v));
      const r = await pool.query(`UPDATE mod_grabbing_config SET ${sets.join(', ')}, updated_at=NOW() WHERE id = $${vals.length+1} RETURNING id, name, target, options, enabled, created_at, updated_at`, [...vals, id]);
      if (!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' });
      return res.json({ ok:true, item: r.rows[0] });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  // Delete
  app.delete('/api/grabbings/:id', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      await ensureTables();
      const id = String(req.params.id||'').trim();
      await pool.query(`DELETE FROM mod_grabbing_config WHERE id=$1`, [id]);
      return res.json({ ok:true });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
}
