# Chat Module

Purpose
- Core chat window and conversation handling on the agent side.

Directory Layout
- frontend/: React components/pages for chat UI.
- backend/: Optional services/routes if needed.
- db/migrations/: Place SQL migrations here if schema changes are required.

Frontend Access
- Default route: `#/conversations` (top-level Conversations tab). The chat module’s UI is embedded in that view.

Configuration & JSON
- Store org‑scoped JSON config in DB. Ensure valid JSON (no comments, escape backslashes, no trailing commas).

Migrations
- Timestamped files with up/down sections under `db/migrations/`.

Deployment
- Use `sync+deploy.sh`. Follow root `AGENTS.md` for safety, org support, and timezones.
This module follows the LiveChat-App module independence rules.

- Canonical rules: see `AGENTS.md` and `modules/MODULE_CHECKLIST.md`.
- API namespace: `/api/chat/*`.
