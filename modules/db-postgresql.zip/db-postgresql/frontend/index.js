export { default as Main } from './pages/DbManager.jsx';

