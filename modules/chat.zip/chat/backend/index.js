import { registerChatRoutes } from './routes/chat.routes.js';

export function register(app, ctx) {
  // Mount JSON parser for this module's API namespace
  try {
    const key = '/api/chat';
    const mounted = (globalThis.__moduleJsonMounted ||= new Set());
    const json = ctx?.expressJson;
    if (typeof json === 'function' && !mounted.has(key)) { app.use(key, json({ limit: String(process.env.API_JSON_LIMIT || '50mb'), strict: false })); mounted.add(key); }
  } catch {}
  // Register routes
  registerChatRoutes(app, ctx);
  // Auto-added ping for compliance
  try { app.get('/api/chat/ping', (_req, res) => res.json({ ok: true, module: 'chat' })); } catch {}
}
