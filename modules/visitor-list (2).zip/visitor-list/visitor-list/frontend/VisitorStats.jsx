// components/VisitorStats.jsx
export default function VisitorStats() {
  return <p className="text-sm text-gray-500">Statistiques visiteurs à venir...</p>;
}
