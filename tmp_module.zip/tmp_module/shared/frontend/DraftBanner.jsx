export default function DraftBanner({ draft, error, onInsert, onReplace, onCopy, onClose }) {
  if (!draft && !error) return null;

  return (
    <div className="border-b bg-amber-50 text-amber-900">
      <div className="px-4 py-3">
        <div className="font-semibold mb-1">PROPOSITION IA (BROUILLON)</div>
        <div className="text-sm whitespace-pre-wrap break-words">
          {error ? (
            <span>Impossible de générer un brouillon pour l’instant.</span>
          ) : (
            draft
          )}
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2">
          <button
            onClick={onInsert}
            className="text-xs px-3 py-1 rounded border bg-white hover:bg-gray-50"
          >
            Insérer dans l’éditeur
          </button>
          <button
            onClick={onReplace}
            className="text-xs px-3 py-1 rounded border bg-white hover:bg-gray-50"
          >
            Remplacer mon texte
          </button>
          <button
            onClick={onCopy}
            className="text-xs px-3 py-1 rounded border bg-white hover:bg-gray-50"
          >
            Copier
          </button>
          <button
            onClick={onClose}
            className="text-xs px-3 py-1 rounded border bg-white hover:bg-gray-50"
          >
            Fermer
          </button>
        </div>

        <div className="mt-1 text-[11px] text-gray-500">
          Vérifiez/éditez avant d’envoyer au client.
        </div>
      </div>
    </div>
  );
}
