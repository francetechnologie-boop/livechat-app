import React from "react";

function IconBase({ className = "", children, ...props }) {
  const combined = ["h-4 w-4", className].filter(Boolean).join(" ");
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" className={combined} {...props}>
      {children}
    </svg>
  );
}

export const IconFolder = (props) => (
  <IconBase {...props}>
    <path d="M3 7h5l2 2h11v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
  </IconBase>
);

export const IconLink = (props) => (
  <IconBase {...props}>
    <path d="M10 13a5 5 0 0 0 7.07 0l1.41-1.41a5 5 0 0 0-7.07-7.07L10 6" />
    <path d="M14 11a5 5 0 0 0-7.07 0L5.5 12.43a5 5 0 0 0 7.07 7.07L14 18" />
  </IconBase>
);

export const IconStar = (props) => (
  <IconBase {...props}>
    <polygon points="12 2 15 9 22 9 17 14 19 21 12 17 5 21 7 14 2 9 9 9" />
  </IconBase>
);

export const IconBolt = (props) => (
  <IconBase {...props}>
    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
  </IconBase>
);

// Extra pictograms
export const IconHome = (props) => (
  <IconBase {...props}>
    <path d="M3 10l9-7 9 7" />
    <path d="M9 22V12h6v10" />
  </IconBase>
);

export const IconCog = (props) => (
  <IconBase {...props}>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c0 .66.39 1.26 1 1.51.16.07.33.1.5.1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
  </IconBase>
);

export const IconChart = (props) => (
  <IconBase {...props}>
    <path d="M3 3v18h18" />
    <rect x="7" y="12" width="3" height="6" />
    <rect x="12" y="9" width="3" height="9" />
    <rect x="17" y="6" width="3" height="12" />
  </IconBase>
);

export const IconUsers = (props) => (
  <IconBase {...props}>
    <circle cx="9" cy="8" r="3" />
    <path d="M2 21a7 7 0 0 1 14 0" />
    <circle cx="18" cy="11" r="3" />
    <path d="M22 21a5 5 0 0 0-7-4" />
  </IconBase>
);

export const IconMessage = (props) => (
  <IconBase {...props}>
    <rect x="3" y="4" width="18" height="14" rx="2" />
    <path d="M7 8h10M7 12h6" />
  </IconBase>
);

export const IconDatabase = (props) => (
  <IconBase {...props}>
    <ellipse cx="12" cy="5" rx="7" ry="3" />
    <path d="M5 5v6c0 1.7 3.1 3 7 3s7-1.3 7-3V5" />
    <path d="M5 11v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6" />
  </IconBase>
);

export const IconShield = (props) => (
  <IconBase {...props}>
    <path d="M12 2l7 4v6c0 5-3.5 9-7 10-3.5-1-7-5-7-10V6z" />
  </IconBase>
);

export const IconBell = (props) => (
  <IconBase {...props}>
    <path d="M18 8a6 6 0 1 0-12 0c0 7-3 8-3 8h18s-3-1-3-8" />
    <path d="M13.73 21a2 2 0 0 1-3.46 0" />
  </IconBase>
);

export const IconGlobe = (props) => (
  <IconBase {...props}>
    <circle cx="12" cy="12" r="9" />
    <path d="M2.5 12h19" />
    <path d="M12 2.5a14.5 14.5 0 0 1 0 19" />
    <path d="M12 2.5a14.5 14.5 0 0 0 0 19" />
  </IconBase>
);

export const IconTool = (props) => (
  <IconBase {...props}>
    <path d="M14 7l-7 7-3-3 7-7 3 3z" />
    <path d="M14 7l3-3 3 3-3 3" />
  </IconBase>
);

export const IconPuzzle = (props) => (
  <IconBase {...props}>
    <path d="M20 13h-3a2 2 0 1 0-4 0H8v-3a2 2 0 1 0 0-4h3V3h3a2 2 0 1 1 4 0v3h2z" />
  </IconBase>
);
// Additional, commonly used pictograms to expand choices
export const IconActivity = (props) => (
  <IconBase {...props}>
    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
  </IconBase>
);

export const IconList = (props) => (
  <IconBase {...props}>
    <line x1="8" y1="6" x2="21" y2="6" />
    <line x1="8" y1="12" x2="21" y2="12" />
    <line x1="8" y1="18" x2="21" y2="18" />
    <circle cx="4" cy="6" r="1" />
    <circle cx="4" cy="12" r="1" />
    <circle cx="4" cy="18" r="1" />
  </IconBase>
);

export const IconFile = (props) => (
  <IconBase {...props}>
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
    <polyline points="14 2 14 8 20 8" />
  </IconBase>
);

export const IconTerminal = (props) => (
  <IconBase {...props}>
    <polyline points="4 17 10 11 4 5" />
    <line x1="12" y1="19" x2="20" y2="19" />
  </IconBase>
);

export const IconBug = (props) => (
  <IconBase {...props}>
    <rect x="8" y="8" width="8" height="8" rx="4" />
    <path d="M3 7l3 3M21 7l-3 3M3 17l3-3M21 17l-3-3M8 3l2 2M16 3l-2 2" />
  </IconBase>
);

export const IconAlert = (props) => (
  <IconBase {...props}>
    <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
    <line x1="12" y1="9" x2="12" y2="13" />
    <line x1="12" y1="17" x2="12.01" y2="17" />
  </IconBase>
);

// Requested: 4-square grid icon (like modules/apps)
export const IconGridFour = (props) => (
  <IconBase {...props}>
    <rect x="4" y="4" width="6.5" height="6.5" rx="1.5" />
    <rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5" />
    <rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5" />
    <rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.5" />
  </IconBase>
);

// A few extra handy glyphs to broaden choices
export const IconCalendar = (props) => (
  <IconBase {...props}>
    <rect x="3" y="5" width="18" height="16" rx="2" />
    <line x1="8" y1="3" x2="8" y2="7" />
    <line x1="16" y1="3" x2="16" y2="7" />
    <line x1="3" y1="11" x2="21" y2="11" />
  </IconBase>
);

export const IconClock = (props) => (
  <IconBase {...props}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v6l4 2" />
  </IconBase>
);

export const IconSearch = (props) => (
  <IconBase {...props}>
    <circle cx="11" cy="11" r="7" />
    <line x1="16.65" y1="16.65" x2="21" y2="21" />
  </IconBase>
);

export const IconCheckCircle = (props) => (
  <IconBase {...props}>
    <circle cx="12" cy="12" r="9" />
    <polyline points="8 12 11 15 16 9" />
  </IconBase>
);

export const IconXCircle = (props) => (
  <IconBase {...props}>
    <circle cx="12" cy="12" r="9" />
    <line x1="9" y1="9" x2="15" y2="15" />
    <line x1="15" y1="9" x2="9" y2="15" />
  </IconBase>
);

export const Icons = {
  IconFolder,
  IconLink,
  IconStar,
  IconBolt,
  IconHome,
  IconCog,
  IconChart,
  IconUsers,
  IconMessage,
  IconDatabase,
  IconShield,
  IconBell,
  IconGlobe,
  IconTool,
  IconPuzzle,
  IconActivity,
  IconList,
  IconFile,
  IconTerminal,
  IconBug,
  IconAlert,
  IconGridFour,
  IconCalendar,
  IconClock,
  IconSearch,
  IconCheckCircle,
  IconXCircle,
};
