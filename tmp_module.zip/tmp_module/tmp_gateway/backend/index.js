import { registerTmpGatewayRoutes } from './routes/gateway.routes.js';

export function register(app, ctx) {
  registerTmpGatewayRoutes(app, ctx);
}

