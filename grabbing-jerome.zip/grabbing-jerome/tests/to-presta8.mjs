#!/usr/bin/env node
// Transform an extraction JSON (from extract-product.mjs) into a PrestaShop 8-friendly payload

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function nowTs() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
}

function titleCase(s) {
  return String(s||'').split(/[_\-\s]+/).map(p=>p.charAt(0).toUpperCase()+p.slice(1)).join(' ');
}

function uniq(arr) { return Array.from(new Set((arr||[]).map(x=>String(x||'').trim()).filter(Boolean))); }

function main() {
  // Args
  const args = new Map();
  for (let i=2;i<process.argv.length;i++) {
    const a = process.argv[i];
    if (a && a.startsWith('--')) {
      const parts = a.slice(2).split('=');
      const k = parts[0];
      const v = (parts.length>1) ? parts.slice(1).join('=') : (process.argv[i+1] || '');
      if (parts.length === 1) i++;
      args.set(k, v);
    }
  }
  const inPath = args.get('in') || args.get('input') || '';
  if (!inPath) {
    console.error('Usage: node to-presta8.mjs --in <extract.json>');
    process.exit(1);
  }
  const raw = fs.readFileSync(inPath, 'utf8');
  let data;
  try { data = JSON.parse(raw); } catch (e) {
    console.error('Invalid JSON:', e && e.message ? e.message : String(e));
    process.exit(1);
  }

  const url = data && data.url || '';
  const productNode = data && data.product || {};
  const variants = (data && data.variants) ? data.variants : { skus: [], items: [] };
  const docs = data && data.documents || [];
  const images = data && data.images || [];

  // Base product
  const product = {
    name: productNode.name || data.title || '',
    description_html: productNode.description_html || data.description || '',
    short_description_html: productNode.short_description_html || '',
    reference: productNode.sku || data.sku || '',
    brand: productNode.brand || data.brand || '',
    categories: (data.categories && data.categories.length) ? data.categories : (productNode.category ? [productNode.category] : []),
    price: (typeof productNode.price === 'number') ? productNode.price : (typeof data.price === 'number' ? data.price : null),
    currency: productNode.currency || '',
    images: images
  };

  // Attribute mapping
  // From variants.items[].attributes we expect keys: junction, connector, temperature_compensation, length
  const combinations = [];
  const groupsSet = new Set();
  const valuesMap = new Map(); // group -> Set(values)

  const items = (variants && Array.isArray(variants.items)) ? variants.items : [];
  for (const v of items) {
    const attrsRaw = v && v.attributes ? v.attributes : {};
    const norm = [];
    const pairs = [
      ['junction', 'Junction'],
      ['connector', 'Connector'],
      ['temperature_compensation', 'Temperature Compensation'],
      ['length', 'Length']
    ];
    for (const [key, label] of pairs) {
      const val = attrsRaw[key];
      if (val) {
        norm.push({ group: label, value: String(val) });
        groupsSet.add(label);
        if (!valuesMap.has(label)) valuesMap.set(label, new Set());
        valuesMap.get(label).add(String(val));
      }
    }
    combinations.push({
      reference: v && v.sku ? String(v.sku) : '',
      sku: v && v.sku ? String(v.sku) : '',
      variation_id: v && v.variation_id || null,
      price: (v && typeof v.price === 'number') ? v.price : null,
      attributes: norm,
      image_url: (v && v.image_url) || ''
    });
  }

  const attribute_groups = Array.from(groupsSet);
  const attribute_values_map = {};
  for (const [g, set] of valuesMap.entries()) attribute_values_map[g] = Array.from(set);

  const out = {
    product,
    combinations,
    attachments: docs,
    attribute_groups,
    attribute_values_map,
    meta: { source_url: url }
  };

  const outDir = path.join(__dirname, 'out');
  fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, `presta-${nowTs()}.json`);
  fs.writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8');
  console.log('Presta payload written:', outPath);
  console.log('- product:', product.name);
  console.log('- combinations:', combinations.length);
  console.log('- groups:', attribute_groups.join(', '));
}

main();

