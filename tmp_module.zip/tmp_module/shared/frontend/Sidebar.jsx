import { useEffect, useRef, useState } from "react";
import { Icons } from "./icons.jsx";
import SidebarTree from "./SidebarTree.jsx";

function initials(input = "") {
  const text = String(input || "").trim();
  if (!text) return "LC";
  const parts = text.split(/\s+/).slice(0, 2);
  if (parts.length === 1 && text.includes("@")) {
    return text[0] ? text[0].toUpperCase() : "LC";
  }
  const letters = parts
    .map((part) => (part ? part[0].toUpperCase() : ""))
    .join("");
  return letters || (text[0] ? text[0].toUpperCase() : "LC");
}

// DB-only sidebar: base items are disabled. Render exactly what /api/sidebar/tree returns.
const NAV_ITEMS = [];

// Optional dynamic extensions contributed by generator (kept in same package for bundling)
// Extensions disabled in DB-only mode
const sidebarExtensions = [];
// Discover module frontends to expose direct nav links to #/<module_id>
async function fetchSidebarModules(me) {
  try {
    const params = new URLSearchParams();
    params.set('t', String(Date.now()));
    const res = await fetch(`/api/sidebar/tree?` + params.toString(), { credentials: 'include' });
    const j = await res.json();
    // Strict DB-only: if no items, return empty. No static or discovery fallback.
    if (j && j.ok && Array.isArray(j.items)) {
      return j.items.map(it => { const id = it.entry_id || it.id; const label = it.label || it.name || id; const hash = it.hash || it.path || ''; const icon = it.icon || 'IconStar'; const type = String(it.type || '').toLowerCase(); const isSubmenu = !hash || type === 'sous-menu'; return { id, label, hash, icon, dynamic: !!isSubmenu, treeParentId: isSubmenu ? id : undefined, logo: it.logo || null }; });
    }
  } catch {}
  return [];
}

function mergeSidebar(itemsBase, extensions) {
  try {
  const list = Array.isArray(itemsBase) ? itemsBase.slice() : [];
  const ext = Array.isArray(extensions) ? extensions : [];
  for (const e of ext) {
    if (!e || !e.id) continue;
    let IconComp = IconModules;
    try {
      const alias = {
        logs: 'IconActivity', log: 'IconActivity', activity: 'IconActivity', history: 'IconActivity',
        errors: 'IconBug', error: 'IconBug', bug: 'IconBug',
        security: 'IconShield', shield: 'IconShield',
        settings: 'IconCog', cog: 'IconCog', gear: 'IconCog',
        chat: 'IconMessage', message: 'IconMessage', mail: 'IconMessage',
        db: 'IconDatabase', database: 'IconDatabase',
        users: 'IconUsers', people: 'IconUsers',
        star: 'IconStar', favorite: 'IconStar', fav: 'IconStar',
        link: 'IconLink', external: 'IconLink',
        folder: 'IconFolder', dir: 'IconFolder',
        alert: 'IconAlert', warning: 'IconAlert',
        list: 'IconList', file: 'IconFile', terminal: 'IconTerminal',
      };
      const iconStr = (e && typeof e.icon === 'string') ? e.icon.trim() : '';
      const logoUrl = (e && typeof e.logo === 'string') ? e.logo.trim() : '';
      // Highest priority: explicit logo URL
      if (logoUrl) {
        IconComp = (props) => (<img src={logoUrl} alt="" className="h-5 w-5 object-contain" aria-hidden {...props} />);
      }
      const iconKey = alias[iconStr] || iconStr;
      const isUrl = !logoUrl && ( /^https?:/i.test(iconKey) || iconKey.startsWith('/') || iconKey.startsWith('data:') );
      if (isUrl) {
        const src = iconKey;
        IconComp = (props) => (<img src={src} alt="" className="h-5 w-5 object-contain" aria-hidden {...props} />);
      } else if (!logoUrl && iconKey && iconKey.startsWith('twemoji:')) {
        const hex = (iconKey.split(':')[1] || '').toLowerCase();
        const src = `https://twemoji.maxcdn.com/v/14.0.2/svg/${hex}.svg`;
        IconComp = (props) => (<img src={src} alt="" className="h-5 w-5" aria-hidden {...props} />);
      } else if (!logoUrl && iconKey && Icons && Icons[iconKey]) {
        IconComp = Icons[iconKey];
      } else if (!logoUrl && iconStr && /[\uD800-\uDBFF][\uDC00-\uDFFF]/.test(iconStr)) {
        const em = iconStr;
        IconComp = () => (<span className="text-base" aria-hidden>{em}</span>);
      }
    } catch {}
    const entry = {
      id: String(e.id),
      label: String(e.label || e.id),
      Icon: IconComp,
      dynamic: true,
      treeParentId: String(e.id),
      // navigation behavior: if hash provided, navigate via hash and force modules tab
      navigateToHash: typeof e.hash === 'string' && e.hash ? e.hash : null,
    };
      const beforeId = e.beforeId || null;
      const afterId = e.afterId || null;
      const index = (typeof e.index === 'number' && e.index >= 0) ? e.index : null;
      if (index != null && index <= list.length) {
        list.splice(index, 0, entry);
        continue;
      }
      const findIndex = (id) => list.findIndex((it) => it.id === id);
      if (beforeId) {
        const i = findIndex(String(beforeId));
        if (i >= 0) { list.splice(i, 0, entry); continue; }
      }
      if (afterId) {
        const i = findIndex(String(afterId));
        if (i >= 0) { list.splice(i + 1, 0, entry); continue; }
      }
      list.push(entry);
    }
    return list;
  } catch {
    return itemsBase;
  }
}

function IconBase({ className = "", children, ...props }) {
  const combined = ["h-5 w-5", className].filter(Boolean).join(" ");
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={combined}
      {...props}
    >
      {children}
    </svg>
  );
}

function IconConversations(props) {
  return (
    <IconBase {...props}>
      <rect x="4" y="4" width="16" height="12" rx="3" />
      <polyline points="8 16 8 20 12 16" />
    </IconBase>
  );
}

function IconVisitors(props) {
  return (
    <IconBase {...props}>
      <circle cx="9" cy="9" r="3" />
      <circle cx="16" cy="8" r="2.5" />
      <path d="M4 19c0-2.8 2.2-5 5-5s5 2.2 5 5" />
      <path d="M14 19c0-2 1.6-3.5 3.5-3.5S21 17 21 19" />
    </IconBase>
  );
}

function IconAutomations(props) {
  return (
    <IconBase {...props}>
      <rect x="3.5" y="4" width="6.5" height="6.5" rx="1.5" />
      <rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5" />
      <rect x="8.5" y="14" width="7" height="6.5" rx="1.5" />
      <path d="M10 7.25h4.5" />
      <path d="M6.25 10.5v2.75a1.75 1.75 0 0 0 1.75 1.75H11" />
      <path d="M17.75 10.5v2.25a1.75 1.75 0 0 1-1.75 1.75H14" />
    </IconBase>
  );
}

// Unique chat icon for Company Chat
function IconCompanyChat(props) {
  return (
    <IconBase {...props}>
      {/* Primary chat bubble */}
      <rect x="3" y="4" width="11" height="8" rx="2" />
      <polyline points="7 12 7 15 10 12" />
      {/* Secondary, overlapping bubble */}
      <rect x="10" y="10" width="11" height="8" rx="2" />
      <polyline points="14 18 14 21 17 18" />
    </IconBase>
  );
}

function IconModules(props) {
  return (
    <IconBase {...props}>
      <rect x="4" y="4" width="6.5" height="6.5" rx="1.5" />
      <rect x="13.5" y="4" width="6.5" height="6.5" rx="1.5" />
      <rect x="4" y="13.5" width="6.5" height="6.5" rx="1.5" />
      <rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.5" />
    </IconBase>
  );
}

function IconAgent(props) {
  return (
    <IconBase {...props}>
      <circle cx="12" cy="8.5" r="3.5" />
      <path d="M5 20c1.2-3.2 3.6-5.1 7-5.1s5.8 1.9 7 5.1" />
    </IconBase>
  );
}

function IconSettings(props) {
  return (
    <IconBase {...props}>
      <circle cx="12" cy="12" r="3" />
      <path d="M12 5V3" />
      <path d="M12 21v-2" />
      <path d="M5 12H3" />
      <path d="M21 12h-2" />
      <path d="M6.4 6.4l-1.2-1.2" />
      <path d="M18.8 18.8l-1.2-1.2" />
      <path d="M6.4 17.6l-1.2 1.2" />
      <path d="M18.8 5.2l-1.2 1.2" />
    </IconBase>
  );
}

function IconLogs(props) {
  return (
    <IconBase {...props}>
      <path d="M7 3h7l5 5v11a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z" />
      <path d="M14 3v6h6" />
      <path d="M9 13h6" />
      <path d="M9 17h6" />
    </IconBase>
  );
}

function IconDev(props) {
  return (
    <IconBase {...props}>
      <polyline points="8 7 4 12 8 17" />
      <polyline points="16 7 20 12 16 17" />
      <line x1="12" y1="7" x2="12" y2="17" />
    </IconBase>
  );
}

// Tools icon (wrench + screwdriver)
function IconTools(props) {
  return (
    <IconBase {...props}>
      {/* Wrench */}
      <path d="M9.5 4.5a3.5 3.5 0 0 0 4.9 4.9l2.4 2.4a1.6 1.6 0 0 1-2.3 2.3L12 11.7a3.5 3.5 0 0 0-4.9-4.9l2.4 2.4" />
      {/* Screwdriver */}
      <path d="M15.5 14.5l3.8 3.8" />
      <rect x="18.5" y="18.5" width="2.5" height="2.5" rx="0.5" />
    </IconBase>
  );
}

function IconDatabase(props) {
  return (
    <IconBase {...props}>
      <ellipse cx="12" cy="6" rx="7" ry="3" />
      <path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6" />
      <path d="M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6" />
    </IconBase>
  );
}

export default function Sidebar({ activeTab, setActiveTab, me, onLogout, onGoProfile }) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef(null);
  const [dbExtensions, setDbExtensions] = useState(null);
  const [moduleItems, setModuleItems] = useState([]);

  useEffect(() => {
    const handleClick = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("click", handleClick);
    return () => document.removeEventListener("click", handleClick);
  }, []);

  // Load dynamic sidebar entries from DB (admin only); fallback to static JSON
  useEffect(() => {
    const load = async () => {
      try {
        const jsonItems = await fetchSidebarModules(me);
        setModuleItems(jsonItems);
        setDbExtensions(jsonItems);
      } catch { setDbExtensions([]); setModuleItems([]); }
    };
    load();
    const onReload = () => load();
    window.addEventListener('sidebar:reload', onReload);
    return () => window.removeEventListener('sidebar:reload', onReload);
  }, [me]);

  // DB-only items: render exactly what /api/sidebar/tree returns
  let items = Array.isArray(dbExtensions)
    ? dbExtensions.map((e) => ({
        id: e.entry_id,
        label: e.label,
        hash: e.hash,
        icon: e.icon,
        logo: e.logo,
        treeParentId: e.entry_id,
        dynamic: true,
        isCategory: !e.hash || String(e.hash).trim() === ''
      }))
    : [];
  // No per-user visibility: sidebar is globally managed by Module Manager
  const [flyoutFor, setFlyoutFor] = useState(null);

  const handleSelect = async (item) => {
    const id = typeof item === 'string' ? item : (item && item.id);
    if (id === "settings") {
      // Route to Agents module which now owns Users & Organization
      try {
        const next = '#/agents';
        if (window.location.hash !== next) window.history.replaceState(null, '', next);
      } catch {}
      setActiveTab('modules');
      onGoProfile?.();
      return;
    }
    // Dynamic entries can embed a hash routing; find extension and apply (DB or static)
    try {
      const candidates = Array.isArray(dbExtensions)
        ? dbExtensions.map((e) => ({ id: e.entry_id, hash: e.hash }))
        : [];
      const ext = candidates.find((e) => e && (e.id === id || e.entry_id === id) && e.hash);
      if (ext) {
        // If this entry also has children in the tree, prefer opening the cascade menu.
        try {
          const params = new URLSearchParams();
          params.set('level', '1');
          if (item && item.treeParentId) params.set('parent_entry_id', item.treeParentId);
          // Global sidebar: do not scope by org_id; Module Manager serves a shared tree
          const res = await fetch('/api/sidebar/tree?' + params.toString());
          if (res.ok) {
            const j = await res.json();
            const hasChildren = Array.isArray(j.items) && j.items.length > 0;
            if (hasChildren) {
              setActiveTab('modules');
              setFlyoutFor(item.treeParentId);
              return;
            }
          }
        } catch {}
        // No children: navigate only if a non-empty hash is configured
        const hashStr = (typeof ext.hash === 'string') ? ext.hash.trim() : '';
        if (!hashStr) return; // nothing to navigate to
        let next = '#' + hashStr.replace(/^#?\/?/, '');
        try {
          const root0 = next.replace(/^#\/?/, '').split('/')[0];
          if (root0 === 'agent') next = '#/agents';
        } catch {}
        try {
          const parts = next.replace(/^#\/?/, '').split('/');
          const root = parts[0];
          const known = new Set([  ]);
          if (known.has(root)) setActiveTab(root);
          else setActiveTab('modules');
        } catch {}
        if (window.location.hash !== next) window.history.replaceState(null, '', next);
        setFlyoutFor(null);
        return;
      }
    } catch {}
    // If this is a dynamic entry without hash, open flyout cascade menu
    if (item && typeof item === 'object' && item.dynamic && item.treeParentId) {
      setActiveTab('modules');
      setFlyoutFor(item.treeParentId);
      return;
    }
    setFlyoutFor(null);
    setActiveTab(id);
    if (id === "agent") onGoProfile?.();
  };

  const hasItems = Array.isArray(items) && items.length > 0;
  // DB-only enforcement: render nothing at all when no items
  if (!hasItems) return null;
  return (
    <>
      <aside className="app-sidebar">
      <div className="app-sidebar__brand">
        <div className="app-sidebar__logo">LC</div>
        <span className="app-sidebar__brand-text">Livechat</span>
      </div>

      <nav className="app-sidebar__nav">
        {items.map((it) => (
          <button
            key={it.id}
            type="button"
            onClick={() => handleSelect(it)}
            className={`app-sidebar__item relative${activeTab === it.id ? " is-active" : ""}`}
            title={it.label}
            aria-label={it.label}
          >
            {it.Icon ? <it.Icon /> : <span className="inline-block h-4 w-4 rounded border border-gray-300 opacity-60" aria-hidden />}
            {/* Small chevron if this dynamic entry has children */}
            {it.dynamic && (
              <span className="pointer-events-none absolute right-1 bottom-1 text-[10px] opacity-80">›</span>
            )}
          </button>
        ))}
      </nav>

      <div className="app-sidebar__profile" ref={menuRef}>
        <button
          type="button"
          onClick={() => setOpen((value) => !value)}
          className="app-sidebar__profile-btn"
          title={me?.name || me?.email || "Profile"}
          aria-label="Profile menu"
        >
          {me ? initials(me.name || me.email) : "LC"}
        </button>
        {open && (
          <div className="app-sidebar__dropdown">
            <div>
              <div className="font-semibold leading-5">{me?.name || me?.email || "Profile"}</div>
              {me?.email && <div className="mt-1 text-xs text-slate-500 break-all">{me.email}</div>}
            </div>
            <button onClick={() => { setOpen(false); try { if (window.location.hash !== '#/agents') window.history.replaceState(null, '', '#/agents'); } catch {}; setActiveTab('modules'); onGoProfile?.(); }}>Profile</button>
            <button onClick={() => { setOpen(false); try { if (window.location.hash !== '#/agents') window.history.replaceState(null, '', '#/agents'); } catch {}; setActiveTab('modules'); }}>Notifications</button>
            <button className="danger" onClick={() => { setOpen(false); onLogout?.(); }}>Sign out</button>
          </div>
        )}
      </div>
    </aside>
      {open && <div className="app-sidebar__overlay" onClick={() => setOpen(false)} aria-hidden="true" />}
      {flyoutFor && (
        <>
        <div className="app-sidebar__flyout-overlay" onClick={()=>setFlyoutFor(null)} aria-hidden="true" />
        <div className="app-sidebar__flyout overflow-y-auto">
          <div className="px-3 py-2 text-xs text-slate-500">Menu</div>
          <SidebarTree
            parent={flyoutFor}
            level={1}
            className="px-2"
            onSelect={(node) => {
              try {
                setFlyoutFor(null);
                if (node && node.hash) {
                  let next = '#' + String(node.hash).replace(/^#?\/?/, '');
                  try {
                    const root0 = next.replace(/^#\/?/, '').split('/')[0];
                    if (root0 === 'agent') next = '#/agents';
                  } catch {}
                  try {
                    const parts = next.replace(/^#\/?/, '').split('/');
                    const root = parts[0];
                    const known = new Set([  ]);
                    if (known.has(root)) setActiveTab(root);
                    else setActiveTab('modules');
                  } catch {}
                  if (window.location.hash !== next) window.history.replaceState(null, '', next);
                }
              } catch {}
            }}
          />
        </div>
        </>
      )}
    </>
  );
}
