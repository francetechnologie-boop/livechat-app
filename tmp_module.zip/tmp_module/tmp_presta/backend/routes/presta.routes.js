export function registerTmpPrestaRoutes(app, ctx = {}) {
  const requireAdmin = ctx.requireAdmin || ((_req, res) => { res.status(401).json({ error: 'unauthorized' }); return null; });

  // Regenerate product images via Presta CLI (legacy compatibility path)
  app.post('/api/presta/images/regenerate', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    const root = String(process.env.PRESTA_ROOT || '').trim();
    if (!root) return res.status(412).json({ ok:false, error:'presta_root_missing', message:'Set PRESTA_ROOT env to your PrestaShop root path' });
    try {
      const { exec } = await import('child_process');
      const cmd = `php bin/console prestashop:image:regenerate --type=products --force`;
      exec(cmd, { cwd: root }, (err, stdout, stderr) => {
        if (err) return res.status(500).json({ ok:false, error:'regenerate_failed', message: String(stderr||err.message||err) });
        return res.json({ ok:true, stdout });
      });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
}

