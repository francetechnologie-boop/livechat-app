export function registerTmpGatewayRoutes(app, ctx = {}) {
  const pool = ctx.pool;
  const requireAdmin = ctx.requireAdmin || ((_req, res) => { res.status(401).json({ ok:false, error:'unauthorized' }); return null; });
  const getSetting = ctx.getSetting || (async () => null);
  const setSetting = ctx.setSetting || (async () => {});
  const io = (ctx.extras && ctx.extras.io) || null;

  app.get('/api/tmp_gateway/ping', (_req, res) => res.json({ ok:true, module: 'tmp_gateway' }));

  // Admin: show gateway config (urls and token presence)
  app.get('/api/admin/gateway/config', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const base = (() => {
        try { const fproto = String(req.headers['x-forwarded-proto']||'').split(',')[0]?.trim(); const fhost = String(req.headers['x-forwarded-host']||'').split(',')[0]?.trim(); const proto = (fproto || req.protocol || 'http').toLowerCase(); const host = (fhost || req.headers.host || 'localhost').trim(); return `${proto}://${host}`; } catch { return ''; }
      })();
      const tok = await getSetting('GATEWAY_TOKEN');
      res.json({ ok:true, base_url: base || null, endpoints: base ? { sms_incoming: `${base}/api/sms/incoming`, sms_status: `${base}/api/sms/status`, calls: `${base}/api/calls` } : null, has_token: !!tok });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message||String(e) }); }
  });
  app.get('/api/admin/gateway/status', (_req, res) => {
    res.json({ ok:true });
  });
  app.post('/api/admin/gateway/token/regenerate', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const tok = (globalThis.crypto?.randomUUID?.() || Math.random().toString(36).slice(2)) + '-' + Math.random().toString(16).slice(2); await setSetting('GATEWAY_TOKEN', tok); res.json({ ok:true, token: tok }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message||String(e) }); }
  });
  app.post('/api/admin/gateway/token', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const tok = String(req.body?.token||'').trim(); if (!tok) return res.status(400).json({ ok:false, error:'bad_request' }); await setSetting('GATEWAY_TOKEN', tok); res.json({ ok:true }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message||String(e) }); }
  });

  // Socket.IO namespace for Android gateway
  if (io) {
    const ns = io.of('/gateway');
    ns.use(async (socket, next) => {
      try {
        const provided = String(socket?.handshake?.query?.token || socket?.handshake?.auth?.token || (socket?.handshake?.headers?.authorization||'').replace(/^Bearer\s+/i,'') || '').trim();
        const expected = String(await getSetting('GATEWAY_TOKEN') || '');
        if (expected && provided && provided === expected) return next();
      } catch {}
      next(new Error('unauthorized'));
    });
    ns.on('connection', (socket) => {
      try { socket.on('sms:send', (payload) => {}); } catch {}
      socket.on('disconnect', () => {});
    });
  }

  // Minimal SMS endpoints (accept + 200)
  app.post('/api/sms/incoming', async (req, res) => {
    try { res.json({ ok:true }); } catch (e) { res.status(500).json({ ok:false, error:'server_error' }); }
  });
  app.post('/api/sms/status', async (req, res) => {
    try { res.json({ ok:true }); } catch (e) { res.status(500).json({ ok:false, error:'server_error' }); }
  });
  app.post('/api/calls', async (req, res) => { try { res.json({ ok:true }); } catch { res.status(500).json({ ok:false }); } });
  app.get('/api/calls', async (_req, res) => { try { res.json({ ok:true, items: [] }); } catch { res.status(500).json({ ok:false }); } });
}

