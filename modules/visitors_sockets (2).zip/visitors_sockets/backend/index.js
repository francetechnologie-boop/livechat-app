export function register(app, ctx) {
  try {
    const key = '/api/visitors_sockets';
    const mounted = (globalThis.__moduleJsonMounted ||= new Set());
    const json = ctx?.expressJson;
    if (typeof json === 'function' && !mounted.has(key)) { app.use(key, json({ limit: String(process.env.API_JSON_LIMIT || '50mb'), strict: false })); mounted.add(key); }
  } catch {}
  const io = ctx?.extras?.io;
  const ensureVisitorExists = ctx?.extras?.ensureVisitorExists || (async () => {});
  const upsertVisitorColumns = ctx?.extras?.upsertVisitorColumns || (async () => {});
  const log = (m) => { try { ctx.logToFile?.(`[visitors_sockets] ${m}`); } catch {} };
  if (!io) { log('io missing in ctx.extras; skip sockets'); return; }

  io.on('connection', (socket) => {
    try { log(`socket connected: ${socket.id}`); } catch {}
    let joinedVisitorId = null;
    socket.removeAllListeners('visitor_hello');
    socket.removeAllListeners('agent_hello');
    socket.removeAllListeners('chat_message');

    socket.on('visitor_hello', async (data = {}) => {
      try {
        const vid = typeof data.visitorId === 'string' ? data.visitorId.trim() : '';
        if (!vid) return;
        if (joinedVisitorId === vid) return;
        joinedVisitorId = vid;
        socket.join(vid);
        await ensureVisitorExists(vid);
        const patch = {
          page_url: data.page_url || null,
          page_url_last: data.page_url || null,
          title: data.title || null,
          referrer: data.referrer || null,
          last_action: data.page_url ? 'page_view' : null,
          last_action_at: data.page_url ? new Date().toISOString() : null,
          last_seen: new Date().toISOString(),
        };
        await upsertVisitorColumns(vid, patch);
        io.to('agents').emit('visitor_update', { visitorId: vid, ...patch });
      } catch {}
    });

    socket.on('agent_hello', async (data = {}) => {
      try { socket.join('agents'); log(`agent room joined: ${socket.id}`); } catch {}
    });

    socket.on('chat_message', async (msg = {}) => {
      try {
        const vid = String(msg.visitorId || '').trim();
        if (!vid) return;
        io.to(vid).emit('chat_message', { ...msg, timestamp: Date.now() });
        io.to('agents').emit('dashboard_message', { ...msg, timestamp: Date.now() });
      } catch {}
    });

    socket.on('disconnect', () => { try { log(`socket disconnected: ${socket.id}`); } catch {} });
  });
}
