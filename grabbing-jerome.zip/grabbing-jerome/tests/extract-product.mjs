#!/usr/bin/env node
// Extraction test harness: fetch a WooCommerce product page and emit a full JSON blob
// Includes variants parsed from data-product_variations

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import http from 'http';
import https from 'https';
import zlib from 'zlib';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function nowTs() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
}

function normSpace(s) { return String(s || '').replace(/\s+/g, ' ').trim(); }
function absUrl(href, base) { try { return new URL(href, base).toString(); } catch { return ''; } }
function decodeHtmlEntities(str) {
  if (!str) return '';
  return String(str)
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'");
}

function pickFirst($, specs, useHtml = false) {
  const list = Array.isArray(specs) ? specs : (specs ? [specs] : []);
  for (const spec of list) {
    const s = String(spec || '');
    const atIdx = s.lastIndexOf('@');
    const selector = atIdx >= 0 ? s.slice(0, atIdx) : s;
    const attr = atIdx >= 0 ? s.slice(atIdx + 1) : '';
    try {
      const el = $(selector).first();
      if (!el || el.length === 0) continue;
      if (attr === 'html' || useHtml) {
        const v = normSpace(el.html() || '');
        if (v) return v;
      } else if (attr) {
        const v = normSpace(el.attr(attr) || '');
        if (v) return v;
      } else {
        const v = normSpace(el.text());
        if (v) return v;
      }
    } catch {}
  }
  return '';
}

function pickAll($, specs, attrHint) {
  const list = Array.isArray(specs) ? specs : (specs ? [specs] : []);
  const out = [];
  for (const specRaw of list) {
    const s = String(specRaw || '');
    const atIdx = s.lastIndexOf('@');
    const selector = atIdx >= 0 ? s.slice(0, atIdx) : s;
    const attr = atIdx >= 0 ? s.slice(atIdx + 1) : (attrHint || '');
    try {
      $(selector).each((_, el) => {
        const v = attr ? $(el).attr(attr) : $(el).text();
        if (v) out.push(normSpace(String(v)));
      });
    } catch {}
  }
  return out;
}

function uniq(arr) {
  return Array.from(new Set((arr || []).map(x => String(x || '').trim()).filter(Boolean)));
}

async function fetchHtml(url) {
  const headers = {
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122 Safari/537.36',
    'accept-language': 'en-US,en;q=0.9',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'accept-encoding': 'gzip, deflate, br'
  };
  const maxRedirects = 5;
  function doReq(u, redirects = 0) {
    return new Promise((resolve, reject) => {
      const mod = u.startsWith('https') ? https : http;
      const req = mod.request(u, { method: 'GET', headers }, (res) => {
        const status = res.statusCode || 0;
        const loc = res.headers.location || res.headers.Location;
        if ([301,302,303,307,308].includes(status) && loc && redirects < maxRedirects) {
          const nextUrl = new URL(loc, u).toString();
          res.resume();
          return resolve(doReq(nextUrl, redirects + 1));
        }
        if (status < 200 || status >= 300) {
          res.resume();
          return reject(new Error(`HTTP ${status}`));
        }
        const chunks = [];
        res.on('data', (d) => chunks.push(d));
        res.on('end', () => {
          const buf = Buffer.concat(chunks);
          const enc = String(res.headers['content-encoding'] || '').toLowerCase();
          if (enc.includes('gzip')) {
            zlib.gunzip(buf, (err, out) => { if (err) return resolve(buf.toString('utf8')); resolve(out.toString('utf8')); });
          } else if (enc.includes('br') && zlib.brotliDecompress) {
            zlib.brotliDecompress(buf, (err, out) => { if (err) return resolve(buf.toString('utf8')); resolve(out.toString('utf8')); });
          } else if (enc.includes('deflate')) {
            zlib.inflate(buf, (err, out) => { if (err) return resolve(buf.toString('utf8')); resolve(out.toString('utf8')); });
          } else {
            resolve(buf.toString('utf8'));
          }
        });
      });
      req.on('error', reject);
      req.end();
    });
  }
  return doReq(url);
}

function extractJsonLd($) {
  const sel = "script[type='application/ld+json']";
  const blobs = [];
  $(sel).each((_, el) => { const t = $(el).text(); if (t && t.trim()) blobs.push(t.trim()); });
  const parsed = [];
  for (const t of blobs) {
    try {
      const j = JSON.parse(t);
      if (Array.isArray(j)) parsed.push(...j); else parsed.push(j);
    } catch {}
  }
  let product = null;
  for (const node of parsed) {
    const ty = Array.isArray(node['@type']) ? node['@type'] : (node['@type'] ? [node['@type']] : []);
    if (ty.includes('Product')) { product = node; break; }
  }
  const mapped = {};
  if (product) {
    try { mapped.name = product && product.name; } catch {}
    try {
      const b = product && product.brand;
      mapped.brand = (b && typeof b === 'object' && b.name) ? b.name : b;
    } catch {}
    try {
      const img = product && product.image;
      mapped.images = Array.isArray(img) ? img : (img ? [img] : []);
    } catch {}
    try { mapped.description = product && product.description; } catch {}
    try {
      const offers = product && product.offers;
      if (Array.isArray(offers)) {
        const o = offers[0] || {};
        mapped['offers.price'] = o.price || o.lowPrice || null;
        mapped['offers.priceCurrency'] = o.priceCurrency || null;
      } else if (offers && typeof offers === 'object') {
        mapped['offers.price'] = offers.price || offers.lowPrice || null;
        mapped['offers.priceCurrency'] = offers.priceCurrency || null;
      }
    } catch {}
  }
  return { raw: product, mapped };
}

function extractVariants($, baseUrl) {
  const raw = pickFirst($, "form.variations_form@data-product_variations");
  if (!raw) return { skus: [], items: [] };
  const jsonStr = decodeHtmlEntities(raw);
  let arr;
  try { arr = JSON.parse(jsonStr); } catch (e) { return { skus: [], items: [] }; }
  const items = [];
  for (const v of Array.isArray(arr) ? arr : []) {
    const attrsRaw = (v && v.attributes) ? v.attributes : {};
    const attrs = {
      junction: attrsRaw['attribute_junction'] || null,
      connector: attrsRaw['attribute_connector'] || null,
      temperature_compensation: attrsRaw['attribute_temperature-compensation'] || null,
      length: attrsRaw['attribute_length'] || null
    };
    const image = (v && v.image) ? v.image : {};
    const imageUrl = image.full_src || image.url || image.src || '';
    items.push({
      sku: (v && v.sku) || '',
      variation_id: (v && v.variation_id) || null,
      price: (v && typeof v.display_price === 'number') ? v.display_price : null,
      price_html: (v && v.price_html) || null,
      in_stock: !!(v && v.is_in_stock),
      purchasable: !!(v && v.is_purchasable),
      weight: (v && v.weight) || null,
      dimensions: (v && v.dimensions) || null,
      image_url: imageUrl ? absUrl(imageUrl, baseUrl) : '',
      attributes: attrs
    });
  }
  const skus = uniq(items.map(x => x.sku).filter(Boolean));
  return { skus, items };
}

function extractAttributes($) {
  const items = [];
  try {
    $(".woocommerce-product-attributes tr").each((_, el) => {
      const sc = $(el);
      const name = normSpace(sc.find('.woocommerce-product-attributes-item__label').first().text());
      const value = normSpace(sc.find('.woocommerce-product-attributes-item__value').first().text());
      if (name && value) items.push({ name, value });
    });
  } catch {}
  return items;
}

function extractDocuments($, baseUrl) {
  const urls = new Set();
  try {
    $('a[href],link[href]').each((_, el) => {
      const href = $(el).attr('href');
      if (href) urls.add(absUrl(href, baseUrl));
    });
  } catch {}
  const reInc = [/\.(?:pdf|docx?|xlsx?|zip)(?:[?#].*)?$/i];
  return Array.from(urls).filter(u => reInc.some(r => r.test(u)));
}

function extractImages($, baseUrl) {
  const sources = [
    ".woocommerce-product-gallery__wrapper a[href]@href",
    "figure.woocommerce-product-gallery__image a[href]@href",
    ".woocommerce-product-gallery__image img[data-large_image]@data-large_image",
    ".woocommerce-product-gallery__image img[src]@src",
    ".wp-post-image[src]@src",
    "meta[property='og:image:secure_url']@content",
    "meta[property='og:image']@content",
    "link[rel='image_src']@href"
  ];
  const imgs = pickAll($, sources, 'src').map(h => absUrl(h, baseUrl));
  const image = pickFirst($, ["meta[property='og:image']@content", 'img@src']);
  if (image) imgs.unshift(absUrl(image, baseUrl));
  const exc = [
    /^(?:data:image)/i,
    /%3Csvg/i,
    /(?:^|[\\/._-])(logo|favicon|sprite|badge|placeholder|loading)(?:[\\/._-]|$)/i
  ];
  const out = uniq(imgs).filter(u => !exc.some(r => r.test(u)));
  return { image: out[0] || '', images: out };
}

async function main() {
  // Resolve cheerio robustly across environments
  async function getCheerio() {
    try {
      const reqRoot = createRequire(path.join(process.cwd(), 'package.json'));
      const mod = reqRoot('cheerio');
      return mod;
    } catch (e2) {
      try {
        const reqBackend = createRequire(path.join(__dirname, '../../backend/package.json'));
        const mod = reqBackend('cheerio');
        return mod;
      } catch (e3) {
        try {
          const reqHere = createRequire(path.join(__dirname, 'package.json'));
          const mod = reqHere('cheerio');
          return mod;
        } catch (e4) {
          throw new Error('cheerio not found. Run `cd livechat-app/backend && npm install`');
        }
      }
    }
  }
  const args = new Map();
  for (let i = 2; i < process.argv.length; i++) {
    const a = process.argv[i];
    if (a && a.startsWith('--')) {
      const parts = a.slice(2).split('=');
      const k = parts[0];
      const v = (parts.length > 1) ? parts.slice(1).join('=') : (process.argv[i + 1] || '');
      if (parts.length === 1) i++;
      args.set(k, v);
    }
  }
  const url = args.get('url') || args.get('u') || '';
  if (!url) {
    console.error('Usage: node extract-product.mjs --url <product-url>');
    process.exit(1);
  }

  const html = await fetchHtml(url);
  const cheerio = await getCheerio();
  const $ = cheerio.load(html);

  const title = pickFirst($, ["meta[property='og:title']@content", "meta[name='twitter:title']@content", 'title']);
  const description = pickFirst($, ["meta[name='description']@content", "meta[property='og:description']@content"]);
  const { image, images } = extractImages($, url);
  const json_ld = extractJsonLd($);

  // Product top-level fields
  const product = {};
  try { product.name = title || (json_ld && json_ld.mapped && json_ld.mapped.name) || ''; } catch (e) {}
  try { product.brand = (json_ld && json_ld.mapped && json_ld.mapped.brand) || ''; } catch (e) {}
  try { product.sku = pickFirst($, ['.product_meta .sku', 'span.sku', "meta[property='product:retailer_item_id']@content", "meta[property='og:sku']@content"]) || ''; } catch {}
  try {
    const pr = pickFirst($, ["meta[property='product:price:amount']@content", '.summary .price .amount']);
    product.price = pr ? Number(String(pr).replace(/[^0-9.,-]/g, '').replace(',', '.')) : null;
  } catch (e) { product.price = null; }
  try { product.currency = pickFirst($, ["meta[property='product:price:currency']@content"]) || (json_ld && json_ld.mapped && json_ld.mapped['offers.priceCurrency']) || ''; } catch (e) {}
  try { product.description_html = pickFirst($, ['.woocommerce-product-details__short-description', '#tab-description', '.woocommerce-Tabs-panel--description', '.product .entry-content', '.et_pb_text_inner'], true) || ''; } catch {}
  try { product.category = pickFirst($, ["nav.woocommerce-breadcrumb a:nth-last-child(2)", '.product_meta .posted_in a', "a[href*='/product-category/']:last-child"]) || ''; } catch {}

  // Variants (WooCommerce variations)
  const variants = extractVariants($, url);

  // Attributes & Documents
  const attributes = extractAttributes($);
  const documents = extractDocuments($, url);

  const result = {
    url,
    page_type: 'product',
    title,
    description,
    price: (typeof product.price === 'number') ? product.price : null,
    image,
    images,
    brand: product.brand || '',
    sku: product.sku || '',
    categories: product.category ? [product.category] : [],
    json_ld,
    colors: { codes: [], labels: [], swatches: [] },
    product,
    attributes,
    documents,
    variants
  };

  const outDir = path.join(__dirname, 'out');
  fs.mkdirSync(outDir, { recursive: true });
  const outPath = path.join(outDir, `extract-${nowTs()}.json`);
  fs.writeFileSync(outPath, JSON.stringify(result, null, 2), 'utf8');

  console.log('OK');
  console.log(`- url: ${url}`);
  console.log(`- title: ${title}`);
  console.log(`- images: ${images.length}`);
  console.log(`- variants: ${variants.skus.length} SKUs`);
  console.log(`- out: ${outPath}`);
}

main().catch((e) => {
  console.error('Extraction failed:', (e && e.message) || String(e));
  process.exit(1);
});
