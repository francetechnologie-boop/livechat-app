import { registerTmpGeoRoutes } from './routes/geo.routes.js';

export function register(app, ctx) {
  registerTmpGeoRoutes(app, ctx);
}

