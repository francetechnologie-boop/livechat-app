import fs from 'fs';
import path from 'path';

function backendDirFromModule() {
  const here = path.resolve(path.dirname(new URL(import.meta.url).pathname));
  const repoRootGuess = path.resolve(here, '../../../../');
  const candidate = path.join(repoRootGuess, 'backend');
  try { if (fs.existsSync(candidate)) return candidate; } catch {}
  try { const cwd = process.cwd(); if (fs.existsSync(path.join(cwd, 'package.json'))) return cwd; } catch {}
  return candidate;
}

export function registerPacketaRoutes(app, ctx = {}) {
  // Packeta routes moved to grabbing-zasilkovna module.
  // Keep lightweight aliases here for backward compatibility.
  const fwd = (from, to) => {
    try {
      app.all(from, (req, res) => app._router.handle({ ...req, url: to.replace(':name', encodeURIComponent(String(req.params?.name||''))) }, res, ()=>{}));
    } catch {}
  };
  fwd('/api/grabbing/packeta/download', '/api/grabbing-zasilkovna/download');
  fwd('/api/grabbings/packeta/download', '/api/grabbing-zasilkovna/download');
  fwd('/api/grabbing/packeta/parse', '/api/grabbing-zasilkovna/parse');
  fwd('/api/grabbings/packeta/parse', '/api/grabbing-zasilkovna/parse');
  fwd('/api/grabbing/packeta/latest', '/api/grabbing-zasilkovna/latest');
  fwd('/api/grabbings/packeta/latest', '/api/grabbing-zasilkovna/latest');
  fwd('/api/grabbing/packeta/cleanup', '/api/grabbing-zasilkovna/cleanup');
  fwd('/api/grabbings/packeta/cleanup', '/api/grabbing-zasilkovna/cleanup');
  fwd('/api/grabbing/packeta/file/:name', '/api/grabbing-zasilkovna/file/:name');
  fwd('/api/grabbings/packeta/file/:name', '/api/grabbing-zasilkovna/file/:name');
}
