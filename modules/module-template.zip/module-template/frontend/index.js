export { default as ModuleTemplate } from "./pages/ModuleTemplate.jsx";
export { default as ModuleTemplateSettings } from "./pages/Settings.jsx";
export { default as Main } from "./pages/ModuleTemplate.jsx";
export { default } from "./pages/ModuleTemplate.jsx";
