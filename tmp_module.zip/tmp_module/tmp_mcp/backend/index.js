import { registerTmpMcpRoutes } from './routes/mcp.routes.js';

export function register(app, ctx) {
  registerTmpMcpRoutes(app, ctx);
}

