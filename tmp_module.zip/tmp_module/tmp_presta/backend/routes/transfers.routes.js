import fs from 'fs';
import path from 'path';

function backendDirFromModule() {
  const here = path.resolve(path.dirname(new URL(import.meta.url).pathname));
  const repoRootGuess = path.resolve(here, '../../../../');
  const candidate = path.join(repoRootGuess, 'backend');
  try { if (fs.existsSync(candidate)) return candidate; } catch {}
  try { const cwd = process.cwd(); if (fs.existsSync(path.join(cwd, 'package.json'))) return cwd; } catch {}
  return candidate;
}

export function registerPrestaTransfersRoutes(app, ctx = {}) {
  const pool = ctx.pool;
  const log = (m) => { try { ctx.logToFile?.(`[tmp_presta] ${m}`); } catch {} };

  const backendDir = backendDirFromModule();
  const jeromeDir = path.join(backendDir, 'uploads', 'grabbing-jerome');
  const transfersFile = path.join(jeromeDir, 'transfers.json');

  const loadTransfers = () => { try { const t = fs.readFileSync(transfersFile, 'utf8'); const arr = JSON.parse(t||'[]'); return Array.isArray(arr)? arr: []; } catch { return []; } };

  app.get('/api/presta/transfers', async (_req, res) => {
    try {
      if (pool) {
        // Prefer DB table when available (legacy names accepted)
        try {
          const { rows } = await pool.query('select when_at as "when", id_product, product_url, image, price, currency, declinaison, file, name from grabbing_jerome_transfers order by when_at desc limit 100');
          return res.json({ ok:true, items: rows });
        } catch {}
      }
      const items = loadTransfers().map(x => ({ when: x.when || x.added_at, id_product: x.id_product, product_url: x.product_url, image: x.image, price: x.price, currency: x.currency, declinaison: x.declinaison, file: x.file, name: x.name, })).sort((a,b)=> new Date(b.when||0) - new Date(a.when||0)).slice(0,100);
      return res.json({ ok:true, items });
    } catch (e) { log(`GET /api/presta/transfers ${e?.message||e}`); return res.status(500).json({ ok:false, error:'transfers_list_failed', message: e?.message || String(e) }); }
  });
}

