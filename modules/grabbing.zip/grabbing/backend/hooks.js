export async function onModuleLoaded(ctx = {}) {
  const pool = ctx.pool;
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS mod_grabbing_config (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        target TEXT,
        options JSONB,
        enabled BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);
    // Legacy backfill from grabbing_config if present and module table empty
    try {
      const cur = await pool.query(`SELECT 1 FROM mod_grabbing_config LIMIT 1`);
      if (!cur.rowCount) {
        const tExists = await pool.query(`SELECT to_regclass('public.grabbing_config') AS t`);
        if (tExists.rows[0]?.t) {
          const r = await pool.query(`SELECT * FROM grabbing_config`);
          for (const row of r.rows) {
            const id = String(row.id || `grb_${Date.now()}`).trim();
            const name = String(row.name || row.title || id);
            const target = String(row.target || '').trim() || null;
            let options = null; try { if (row.options && typeof row.options==='object') options = row.options; else if (typeof row.options==='string' && row.options.trim()) options = JSON.parse(row.options); } catch {}
            const enabled = row.enabled === undefined ? true : !!row.enabled;
            await pool.query(`
              INSERT INTO mod_grabbing_config (id, name, target, options, enabled, created_at, updated_at)
              VALUES ($1,$2,$3,$4::jsonb,$5,NOW(),NOW())
              ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name, target=EXCLUDED.target, options=EXCLUDED.options, enabled=EXCLUDED.enabled, updated_at=NOW()
            `, [id, name, target, JSON.stringify(options||{}), enabled]);
          }
          ctx.logToFile?.(`[grabbing] Backfilled ${r.rowCount} config row(s) from grabbing_config`);
        }
      }
    } catch (e) {
      ctx.logToFile?.(`[grabbing] backfill error: ${e?.message || e}`);
    }

    ctx.logToFile?.('[grabbing] onModuleLoaded completed');
  } catch (e) {
    ctx.logToFile?.(`[grabbing] onModuleLoaded error: ${e?.message || e}`);
  }
}

export async function onModuleDisabled(_ctx = {}) {}
