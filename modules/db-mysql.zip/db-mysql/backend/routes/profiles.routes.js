function pickOrgId(req) { try { return (req.headers['x-org-id'] || req.query?.org_id || null) ? String(req.headers['x-org-id'] || req.query.org_id) : null; } catch { return null; } }

export function registerDbMysqlProfilesRoutes(app, ctx = {}) {
  const pool = ctx.pool;
  const requireAdmin = ctx.requireAdmin || ((_req, res) => { res.status(403).end(); return false; });
  if (!pool || typeof pool.query !== 'function') return;

  // List profiles
  app.get('/api/db-mysql/profiles', async (req, res) => {
    if (!requireAdmin(req, res)) return;
    const orgId = pickOrgId(req);
    try {
      const args = [];
      const whereOrg = (orgId ? ' WHERE (org_id IS NULL OR org_id = $1)' : '');
      if (orgId) args.push(orgId);
      const r = await pool.query(`SELECT id, name, host, port, "database", db_user, ssl, is_default, org_id, created_at, updated_at FROM mod_db_mysql_profiles${whereOrg} ORDER BY updated_at DESC`, args);
      return res.json({ ok:true, items: r.rows || [] });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Create profile
  app.post('/api/db-mysql/profiles', async (req, res) => {
    if (!requireAdmin(req, res)) return;
    const b = req.body || {};
    const orgId = b.org_id != null ? String(b.org_id) : (pickOrgId(req));
    try {
      const name = String(b.name || '').trim();
      const host = String(b.host || '').trim();
      const port = Number(b.port || 3306);
      const database = String(b.database || '').trim();
      const db_user = String(b.db_user || '').trim();
      const db_password = b.db_password != null ? String(b.db_password) : '';
      const ssl = !!b.ssl;
      const is_default = !!b.is_default;
      if (!name || !host || !database || !db_user) return res.status(400).json({ ok:false, error:'bad_request', message:'Missing required fields' });
      // Enforce single default per org when creating
      if (is_default) {
        const args = [];
        let sql = 'UPDATE mod_db_mysql_profiles SET is_default=FALSE, updated_at=NOW()';
        if (orgId) { sql += ' WHERE (org_id IS NULL OR org_id = $1)'; args.push(orgId); }
        await pool.query(sql, args);
      }
      const r = await pool.query(
        `INSERT INTO mod_db_mysql_profiles (name, host, port, "database", db_user, db_password, ssl, is_default, org_id, created_at, updated_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,NOW(),NOW()) RETURNING id`,
        [name, host, port, database, db_user, db_password, ssl, is_default, orgId || null]
      );
      return res.json({ ok:true, id: r.rows[0].id });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Update profile
  app.put('/api/db-mysql/profiles/:id', async (req, res) => {
    if (!requireAdmin(req, res)) return;
    const id = Number(req.params.id || 0);
    if (!id) return res.status(400).json({ ok:false, error:'bad_request' });
    const b = req.body || {};
    const orgId = pickOrgId(req);
    try {
      const fields = [];
      const vals = [];
      function set(col, val) { fields.push(col + '=$' + (vals.length+1)); vals.push(val); }
      if (b.name != null) set('name', String(b.name));
      if (b.host != null) set('host', String(b.host));
      if (b.port != null) set('port', Number(b.port));
      if (b.database != null) set('"database"', String(b.database));
      if (b.db_user != null) set('db_user', String(b.db_user));
      if (b.db_password != null) set('db_password', String(b.db_password));
      if (b.ssl != null) set('ssl', !!b.ssl);
      const makeDefault = b.is_default === true;
      if (b.is_default != null) set('is_default', !!b.is_default);
      set('updated_at', new Date());
      if (!fields.length) return res.json({ ok:true });
      vals.push(id);
      const args = vals.slice();
      const whereOrg = (orgId ? ' AND (org_id IS NULL OR org_id = $' + (args.length+1) + ')' : '');
      if (orgId) args.push(orgId);
      const sql = `UPDATE mod_db_mysql_profiles SET ${fields.join(', ')} WHERE id=$${vals.length}${whereOrg}`;
      // Enforce single default per org when toggling default TRUE on this id
      if (makeDefault) {
        const a2 = [];
        let sql2 = 'UPDATE mod_db_mysql_profiles SET is_default=FALSE, updated_at=NOW() WHERE id<>$1';
        a2.push(id);
        if (orgId) { sql2 += ' AND (org_id IS NULL OR org_id = $2)'; a2.push(orgId); }
        await pool.query(sql2, a2);
      }
      await pool.query(sql, args);
      return res.json({ ok:true });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Delete profile
  app.delete('/api/db-mysql/profiles/:id', async (req, res) => {
    if (!requireAdmin(req, res)) return;
    const id = Number(req.params.id || 0);
    if (!id) return res.status(400).json({ ok:false, error:'bad_request' });
    const orgId = pickOrgId(req);
    try {
      const args = [id];
      const whereOrg = (orgId ? ' AND (org_id IS NULL OR org_id = $2)' : '');
      if (orgId) args.push(orgId);
      await pool.query(`DELETE FROM mod_db_mysql_profiles WHERE id=$1${whereOrg}`, args);
      return res.json({ ok:true });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
}
