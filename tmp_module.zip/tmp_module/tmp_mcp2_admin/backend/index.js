import { registerTmpMcp2AdminRoutes } from './routes/mcp2-admin.routes.js';

export function register(app, ctx) {
  registerTmpMcp2AdminRoutes(app, ctx);
}

