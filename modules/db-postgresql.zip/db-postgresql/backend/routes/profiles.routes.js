export function registerDbPostgresRoutes(app, ctx = {}) {
  const pool = ctx.pool;
  const requireAdmin = ctx.requireAdmin || ((_req, res) => { res.status(401).json({ ok:false, error:'unauthorized' }); return null; });

  app.get('/api/db-postgresql/health', async (_req, res) => {
    try { return res.json({ ok:true, module: 'db-postgresql' }); } catch { return; }
  });

  async function ensureTables() {
    if (!pool) return;
    await pool.query(`
      CREATE TABLE IF NOT EXISTS mod_db_postgresql_profiles (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        host VARCHAR(255) NOT NULL,
        port INTEGER NOT NULL DEFAULT 5432,
        database VARCHAR(255) NOT NULL,
        db_user VARCHAR(255) NOT NULL,
        db_password TEXT NULL,
        ssl BOOLEAN NOT NULL DEFAULT FALSE,
        is_default BOOLEAN NOT NULL DEFAULT FALSE,
        org_id TEXT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      );
      CREATE INDEX IF NOT EXISTS idx_db_postgres_profiles_org ON mod_db_postgresql_profiles(org_id);
    `);
  }

  app.get('/api/db-postgresql/profiles', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      await ensureTables();
      const r = await pool.query('SELECT id, name, host, port, database, db_user, ssl, is_default, org_id, created_at, updated_at FROM mod_db_postgresql_profiles ORDER BY updated_at DESC');
      return res.json({ ok:true, items: r.rows });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); }
  });

  app.post('/api/db-postgresql/profiles', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      await ensureTables();
      const b = req.body || {};
      const id = b.id ? Number(b.id) : null;
      const name = String(b.name||'').trim();
      const host = String(b.host||'').trim();
      const port = Number(b.port||5432);
      const database = String(b.database||'').trim();
      const db_user = String(b.db_user||b.user||'').trim();
      const db_password = typeof b.db_password==='string' ? b.db_password : null;
      const ssl = !!b.ssl;
      const is_default = !!b.is_default;
      const org_id = (b.org_id==null? null : String(b.org_id));
      if (!name || !host || !database || !db_user) return res.status(400).json({ ok:false, error:'bad_request' });
      if (is_default) { try { await pool.query('UPDATE mod_db_postgresql_profiles SET is_default=FALSE WHERE is_default IS TRUE'); } catch {} }
      if (id) {
        const r = await pool.query(
          `UPDATE mod_db_postgresql_profiles SET name=$1, host=$2, port=$3, database=$4, db_user=$5, db_password=$6, ssl=$7, is_default=$8, org_id=$9, updated_at=NOW() WHERE id=$10 RETURNING id`,
          [name,host,port,database,db_user,db_password,ssl,is_default,org_id,id]
        );
        if (!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' });
        return res.json({ ok:true, id });
      } else {
        const r = await pool.query(
          `INSERT INTO mod_db_postgresql_profiles (name,host,port,database,db_user,db_password,ssl,is_default,org_id) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
          [name,host,port,database,db_user,db_password,ssl,is_default,org_id]
        );
        return res.status(201).json({ ok:true, id: r.rows[0].id });
      }
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); }
  });
}

