import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

export function registerTmpMcpDevRoutes(app, ctx = {}) {
  const requireAdmin = ctx.requireAdmin || ((_req, res) => { res.status(401).json({ ok:false, error: 'unauthorized' }); return null; });
  const getSetting = ctx.getSetting || (async () => null);
  const setSetting = ctx.setSetting || (async () => {});
  const pool = ctx.pool;
  const extras = ctx.extras || {};

  function backendDirFromModule() {
    const here = path.resolve(path.dirname(new URL(import.meta.url).pathname));
    const repoRootGuess = path.resolve(here, '../../../../');
    const candidate = path.join(repoRootGuess, 'backend');
    try { if (fs.existsSync(candidate)) return candidate; } catch {}
    try { const cwd = process.cwd(); if (fs.existsSync(path.join(cwd, 'package.json'))) return cwd; } catch {}
    return candidate;
  }

  async function ensureMcpFilesTable() { try { await pool.query(`CREATE TABLE IF NOT EXISTS mcp_files (id TEXT PRIMARY KEY, file_name TEXT, file_path TEXT, content_type TEXT, size_bytes BIGINT, server_name TEXT, bot_id TEXT, created_at TIMESTAMP DEFAULT NOW())`); } catch {} }

  // Status (derive httpBase + wsUrl from MCP_DEV_PUBLIC_BASE or request headers)
  app.get('/mcp-dev/status', (req, res) => {
    try {
      const enabledRaw = process.env.MCP_DEV_ENABLED;
      const enabled = enabledRaw ? !/^(0|false|no)$/i.test(enabledRaw) : true;
      let httpBase = '';
      try { httpBase = new URL(String(process.env.MCP_DEV_PUBLIC_BASE || '')).origin; } catch {}
      if (!httpBase) {
        const fproto = String(req.headers['x-forwarded-proto'] || '').split(',')[0]?.trim();
        const fhost = String(req.headers['x-forwarded-host'] || '').split(',')[0]?.trim();
        const proto = (fproto || req.protocol || 'http').toLowerCase();
        const host = (fhost || req.headers.host || 'localhost').trim();
        httpBase = `${proto}://${host}`;
      }
      const wsScheme = httpBase.startsWith('https') ? 'wss' : 'ws';
      const host = (() => { try { return new URL(httpBase).host; } catch { return req.headers.host || ''; } })();
      const wsUrl = `${wsScheme}://${host}/mcp-dev/ws`;
      res.json({ ok: true, httpBase, wsUrl, enabled });
    } catch (e) {
      res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) });
    }
  });

  // Admin: MCP-DEV token
  app.get('/api/admin/mcp-dev/token', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const t = await getSetting('MCP_DEV_TOKEN'); res.json({ ok:true, token: t || null, required: !!t }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/admin/mcp-dev/token/regenerate', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const tok = (globalThis.crypto?.randomUUID?.() || '') + '-' + (crypto.randomBytes ? crypto.randomBytes(16).toString('hex') : Math.random().toString(16).slice(2)); await setSetting('MCP_DEV_TOKEN', tok); res.json({ ok:true, token: tok }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/admin/mcp-dev/token/disable', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { await setSetting('MCP_DEV_TOKEN', ''); res.json({ ok:true, token: null, required: false }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/admin/mcp-dev/token', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const t = String(req.body?.token || '').trim(); await setSetting('MCP_DEV_TOKEN', t); res.json({ ok:true, token: t || null, required: !!t }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Admin: MCP-DEV public base
  app.get('/api/admin/mcp-dev/public-base', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const v = await getSetting('MCP_DEV_PUBLIC_BASE'); res.json({ ok:true, value: v || null }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/admin/mcp-dev/public-base', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const v = String(req.body?.value || '').trim(); await setSetting('MCP_DEV_PUBLIC_BASE', v); res.json({ ok:true, value: v || null }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // MCP-DEV-Prestashop status (minimal)
  const prestaStatus = (req, res) => {
    try {
      let httpBase = '';
      try { httpBase = new URL(String(process.env.MCP_DEV_PRESTA_PUBLIC_BASE || '')).origin; } catch {}
      if (!httpBase) {
        const fproto = String(req.headers['x-forwarded-proto'] || '').split(',')[0]?.trim();
        const fhost = String(req.headers['x-forwarded-host'] || '').split(',')[0]?.trim();
        const proto = (fproto || req.protocol || 'http').toLowerCase();
        const host = (fhost || req.headers.host || 'localhost').trim();
        httpBase = `${proto}://${host}`;
      }
      const wsScheme = httpBase.startsWith('https') ? 'wss' : 'ws';
      const host = (() => { try { return new URL(httpBase).host; } catch { return req.headers.host || ''; } })();
      const wsUrl = `${wsScheme}://${host}/mcp-dev-prestashop/ws`;
      res.json({ ok: true, version: '0.1', httpBase, wsUrl });
    } catch (e) {
      res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) });
    }
  };
  app.get('/mcp-dev-prestashop/status', prestaStatus);
  app.get('/mcp/mcp-dev-prestashop/status', prestaStatus);

  // Files: accept base64 content and save locally + DB row
  app.post('/mcp-dev/files/base64', async (req, res) => {
    try {
      const { filename, content_base64, bot_id } = req.body || {};
      if (!filename || !content_base64) return res.status(400).json({ ok:false, error:'bad_request' });
      await ensureMcpFilesTable();
      const id = (globalThis.crypto?.randomUUID?.() || '') + '-' + (Math.random().toString(16).slice(2));
      const buf = Buffer.from(String(content_base64), 'base64');
      const backendDir = backendDirFromModule();
      const rel = path.join('uploads', 'mcp-dev', `${id}-${filename.replace(/[^A-Za-z0-9._\-]/g,'_')}`);
      const full = path.join(backendDir, rel);
      fs.mkdirSync(path.dirname(full), { recursive: true });
      fs.writeFileSync(full, buf);
      const ct = 'application/octet-stream';
      await pool.query(`INSERT INTO mcp_files (id, file_name, file_path, content_type, size_bytes, server_name, bot_id) VALUES ($1,$2,$3,$4,$5,$6,$7)`, [id, filename, rel, ct, buf.length, 'MCP-DEV', bot_id || null]);
      res.status(201).json({ ok:true, id, file: { id, name: filename, size: buf.length } });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message||String(e) }); }
  });

  app.get('/mcp-dev/files', async (req, res) => {
    try { await ensureMcpFilesTable(); const limit = Math.max(1, Math.min(200, Number(req.query.limit || 50))); const r = await pool.query(`SELECT id, file_name, content_type, size_bytes, server_name, bot_id, created_at FROM mcp_files ORDER BY created_at DESC LIMIT $1`, [limit]); res.json({ ok:true, items: r.rows || [] }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message||String(e) }); }
  });

  app.get('/mcp-dev/file/:id/download', async (req, res) => {
    try { const id = String(req.params.id||'').trim(); if (!id) return res.status(400).json({ ok:false, error:'bad_request' }); await ensureMcpFilesTable(); const r = await pool.query(`SELECT * FROM mcp_files WHERE id=$1 LIMIT 1`, [id]); if (!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' }); const row = r.rows[0]; const p = path.isAbsolute(row.file_path) ? row.file_path : path.join(backendDirFromModule(), row.file_path); if (!fs.existsSync(p)) return res.status(404).json({ ok:false, error:'not_found' }); res.setHeader('Content-Type', row.content_type || 'application/octet-stream'); res.setHeader('Content-Disposition', `attachment; filename="${row.file_name || (id + '.bin')}"`); fs.createReadStream(p).pipe(res); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message||String(e) }); }
  });

  // SSE + Stream minimal equivalents
  app.get(['/mcp-dev/events','/mcp2/events','/mcp-dev/sse','/mcp2/sse'], (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();
    let alive = true; req.on('close', () => { alive = false; });
    const ping = setInterval(() => { if (!alive) { clearInterval(ping); return; } try { res.write(`event: ping\n`); res.write(`data: {"ts":${Date.now()}}\n\n`); } catch { clearInterval(ping); } }, 15000);
  });
  app.post(['/mcp-dev/stream'], async (req, res) => { try { res.json({ ok:true, echo: req.body || {} }); } catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message||String(e) }); } });
}
