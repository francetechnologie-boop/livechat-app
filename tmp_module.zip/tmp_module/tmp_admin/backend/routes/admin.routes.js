import fs from 'fs';
import path from 'path';

export function registerTmpAdminRoutes(app, ctx = {}) {
  const requireAdmin = ctx.requireAdmin || ((_req, res) => { res.status(401).json({ error: 'unauthorized' }); return null; });
  const getLogFilePath = ctx.extras?.getLogFilePath || (() => null);

  app.get('/api/admin/deploy/status', async (req, res) => {
    if (!requireAdmin(req, res)) return;
    try {
      const lockFile = process.env.DEPLOY_LOCK_FILE || '/var/lock/livechat-deploy.lock';
      const countFile = process.env.DEPLOY_COUNT_FILE || '/var/lock/livechat-deploy.count';
      const backupRoot = process.env.BACKUP_ROOT || '/root/livechat-app-backup';

      let lockExists = false; try { lockExists = fs.existsSync(lockFile); } catch {}
      let lockFree = null;
      try {
        const cp = await import('child_process');
        const r = cp.spawnSync('flock', ['-n', lockFile, 'sh', '-c', 'true'], { stdio: 'ignore' });
        if (typeof r.status === 'number') lockFree = (r.status === 0);
      } catch {}

      let deployCount = null; try { const s = fs.readFileSync(countFile, 'utf8').trim(); if (s) deployCount = parseInt(s, 10); } catch {}

      let backups = [];
      try {
        backups = fs.readdirSync(backupRoot)
          .filter(n => /\.zip$|\.dump$/.test(n))
          .map(name => { try { const st = fs.statSync(path.join(backupRoot, name)); return { name, size: st.size, mtime: st.mtime }; } catch { return { name }; } })
          .sort((a, b) => (new Date(b.mtime) - new Date(a.mtime)))
          .slice(0, 10);
      } catch {}

      let build = null; try {
        const distBase = process.env.FRONTEND_DIST_DIR || path.join(process.cwd(), '..', 'frontend', 'dist');
        const fp = path.join(distBase, '__build.json');
        const txt = fs.readFileSync(fp, 'utf8');
        build = JSON.parse(txt);
      } catch {}

      let logTail = [];
      try {
        const p = getLogFilePath();
        if (p) { const t = fs.readFileSync(p, 'utf8'); const lines = t.split(/\r?\n/); logTail = lines.slice(-100); }
      } catch {}

      return res.json({ ok: true, lock: { file: lockFile, exists: !!lockExists, free: lockFree }, counter: { file: countFile, count: deployCount }, backups, build, log_tail: logTail });
    } catch (e) {
      return res.status(500).json({ ok: false, error: 'status_failed', message: e?.message || String(e) });
    }
  });
}

