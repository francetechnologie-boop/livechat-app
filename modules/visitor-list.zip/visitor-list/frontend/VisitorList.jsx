import React, { useEffect, useState } from "react";
import { socket } from "@app-lib/socket";

export default function VisitorList({ setSelectedVisitor, selectedVisitor }) {
  const [visitors, setVisitors] = useState([]);

  useEffect(() => {
    const onDash = (data) => {
      if (!data?.visitorId) return;
      setVisitors((prev) => (prev.includes(data.visitorId) ? prev : [...prev, data.visitorId]));
    };
    socket.on("dashboard_message", onDash);
    return () => socket.off("dashboard_message", onDash);
  }, []); // you already had the right event here — just making cleanup explicit. :contentReference[oaicite:2]{index=2}

  return (
    <>
      <h2 className="text-lg font-bold mb-4">Visiteurs</h2>
      {visitors.map((id) => (
        <div
          key={id}
          className={`p-2 rounded cursor-pointer hover:bg-gray-200 ${
            selectedVisitor === id ? "bg-white font-semibold" : ""
          }`}
          onClick={() => setSelectedVisitor(id)}
        >
          {id.substring(0, 8)}…
        </div>
      ))}
    </>
  );
}
