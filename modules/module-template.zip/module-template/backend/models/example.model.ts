export interface Example {
  id: number;
  org_id: number | null;
  name: string;
  created_at?: string;
}

