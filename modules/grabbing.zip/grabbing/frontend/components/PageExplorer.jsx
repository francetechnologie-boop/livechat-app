export { default } from "../../../automation-suite/frontend/components/PageExplorer.jsx";

