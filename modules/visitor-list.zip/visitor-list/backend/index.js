import { registerVisitorListRoutes } from './routes/visitor-list.routes.js';
import { installModule } from './installer.js';

export function register(app, ctx) {
  try {
    const key = '/api/visitor-list';
    const mounted = (globalThis.__moduleJsonMounted ||= new Set());
    const json = ctx?.expressJson;
    if (typeof json === 'function' && !mounted.has(key)) { app.use(key, json({ limit: String(process.env.API_JSON_LIMIT || '50mb'), strict: false })); mounted.add(key); }
  } catch {}
  try { installModule().catch(() => {}); } catch {}
  registerVisitorListRoutes(app, ctx);
}


// Auto-added ping for compliance
try { app.get('/api/visitor-list/ping', (_req, res) => res.json({ ok: true, module: 'visitor-list' })); } catch {}
