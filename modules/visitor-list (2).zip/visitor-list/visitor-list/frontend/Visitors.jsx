import React, { useEffect, useMemo, useState } from 'react';
import { loadModuleState, saveModuleState } from '@app-lib/uiState';
import { socket } from '@app-lib/socket';
import { FlagIcon } from '@shared-modules';

function timeAgo(ts) {
  if (!ts) return '';
  const d = Math.max(0, Date.now() - (typeof ts === 'string' ? Date.parse(ts) : ts));
  const s = Math.floor(d/1000);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s/60);
  if (m < 60) return `${m} min`;
  const h = Math.floor(m/60);
  if (h < 24) return `${h} h`;
  const day = Math.floor(h/24);
  return `${day} j`;
}

const hostOf = (u) => { try { return new URL(u).host; } catch { return ''; } };

export default function Visitors() {
  // Breadcrumb: base only
  useEffect(() => {
    try { window.dispatchEvent(new CustomEvent('app-breadcrumb', { detail: ['Visitors'] })); } catch {}
  }, []);
  const [rows, setRows] = useState([]);
  const [q, setQ] = useState(() => { try { const st = loadModuleState('visitors'); return st.q || ''; } catch { return ''; } });

  const load = () => {
    fetch('/api/visitors/list')
      .then((r) => (r.ok ? r.json() : []))
      .then((data) => setRows(Array.isArray(data) ? data : []))
      .catch(() => setRows([]));
  };
  useEffect(() => { load(); }, []);
  // Persist search query per agent
  useEffect(() => { try { saveModuleState('visitors', { q }); } catch {} }, [q]);
  // React to restore broadcast
  useEffect(() => {
    const onRestore = (e) => {
      try { const v = e?.detail?.modules?.['visitors']?.q; if (typeof v === 'string') setQ(v); } catch {}
    };
    window.addEventListener('app-restore', onRestore);
    return () => window.removeEventListener('app-restore', onRestore);
  }, []);

  // Live updates: when a visitor_update arrives, bump last_seen, title/page/referrer if present.
  // If it's a new visitor (not in the table yet), trigger a lightweight refresh.
  useEffect(() => {
    const lastReloadRef = { current: 0 };
    const throttleReload = () => {
      const now = Date.now();
      if (now - lastReloadRef.current > 1000) { // at most once per second
        lastReloadRef.current = now;
        try { load(); } catch {}
      }
    };
    const onVu = (p) => {
      if (!p?.visitorId) return;
      let found = false;
      setRows((prev) => {
        const base = Array.isArray(prev) ? prev : [];
        const next = base.map((r) => {
          if (r.visitor_id !== p.visitorId) return r;
          found = true;
          return {
            ...r,
            last_seen: p.last_seen || new Date().toISOString(),
            page_url_last: p.page_url || p.page_url_last || r.page_url_last,
            title: p.title || r.title,
            referrer: p.referrer || r.referrer,
            origin: p.origin || r.origin,
            lang_iso: p.lang_iso || r.lang_iso,
            country_code: p.country_code || r.country_code,
            chatbot_id: p.chatbot_id || r.chatbot_id,
          };
        });
        if (!found) {
          // Optimistically insert a minimal row so it appears immediately
          next.unshift({
            visitor_id: p.visitorId,
            customer_firstname: '',
            customer_lastname: '',
            customer_email: '',
            country_code: p.country_code || '',
            lang_iso: (p.lang_iso || '').toUpperCase(),
            last_seen: p.last_seen || new Date().toISOString(),
            page_url_last: p.page_url || p.page_url_last || '',
            title: p.title || '',
            referrer: p.referrer || '',
            origin: p.origin || '',
            visits_count: 0,
            agent_messages_count: 0,
            chatbot_id: p.chatbot_id || '',
          });
        }
        return next;
      });
      if (!found) throttleReload();
    };
    socket.on('visitor_update', onVu);
    return () => socket.off('visitor_update', onVu);
  }, []);

  const filtered = useMemo(() => {
    const base = Array.isArray(rows) ? rows : [];
    const v = (q || '').trim().toLowerCase();
    if (!v) return base;
    return base.filter((r) =>
      (r.visitor_id||'').toLowerCase().includes(v) ||
      (r.customer_email||'').toLowerCase().includes(v) ||
      (r.customer_firstname||'').toLowerCase().includes(v) ||
      (r.customer_lastname||'').toLowerCase().includes(v) ||
      (r.title||'').toLowerCase().includes(v) ||
      (r.page_url_last||'').toLowerCase().includes(v)
    );
  }, [rows, q]);

  return (
    <div className="visitors-page">
      <div className="visitors-page__header">
        <div className="font-semibold">Visiteurs</div>
        <div className="flex items-center gap-2">
          <div className="text-xs text-gray-500">Nombre de visiteurs {rows.length}</div>
        </div>
      </div>

      <div className="visitors-page__search">
        <input
          type="search"
          placeholder="Rechercher..."
          className="visitors-page__input"
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
      </div>

      <div className="visitors-page__table scroll-area">
        <table className="visitors-table">
          <thead className="visitors-table__head">
            <tr>
              <th className="visitors-table__heading">Visiteur</th>
              <th className="visitors-table__heading">En ligne</th>
              <th className="visitors-table__heading">Page courante</th>
              <th className="visitors-table__heading">Est venue de</th>
              <th className="visitors-table__heading">Chatbot (ext)</th>
              <th className="visitors-table__heading visitors-table__heading--right">Visites</th>
              <th className="visitors-table__heading visitors-table__heading--right">Chats</th>
            </tr>
          </thead>
          <tbody>
            {Array.isArray(filtered) && filtered.map((r) => {
              const name = (r.customer_firstname || r.customer_lastname)
                ? `${r.customer_firstname || ''} ${r.customer_lastname || ''}`.trim()
                : (r.customer_email || r.visitor_id);
              const online = r.last_seen && (Date.now() - Date.parse(r.last_seen) < 2*60*1000);
              const refHost = hostOf(r.referrer || r.origin);
              return (
                <>
                <tr key={r.visitor_id} className="visitors-table__row">
                  <td className="visitors-table__cell">
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <div className="h-8 w-8 rounded-full bg-gray-200 flex items-center justify-center text-xs text-gray-600">{(name||'?').slice(0,2).toUpperCase()}</div>
                        {online && <span className="absolute -right-1 -bottom-1 inline-block w-2.5 h-2.5 bg-green-500 rounded-full" />}
                      </div>
                      <div>
                        <div className="font-medium text-gray-900">{name}</div>
                        <div className="text-xs text-gray-500 flex items-center gap-1">
                          <FlagIcon cc={r.country_code} />
                          <span className="uppercase">{(r.lang_iso || '').toUpperCase()}</span>
                          <span className="text-gray-400">•</span>
                          <span>{r.visitor_id.slice(0, 10)}…</span>
                        </div>
                      </div>
                    </div>
                  </td>
                  <td className="visitors-table__cell">{r.last_seen ? timeAgo(r.last_seen) : '-'}</td>
                  <td className="visitors-table__cell">
                    <div className="truncate max-w-[520px]" title={r.page_url_last || ''}>{r.page_url_last || '-'}</div>
                  </td>
                  <td className="visitors-table__cell">{refHost || '-'}</td>
                  <td className="visitors-table__cell">
                    <span className="text-xs font-mono text-gray-700">
                      {(() => { try { const v = (r.chatbot_id ?? '').toString().trim(); return v || '(none)'; } catch { return '(none)'; } })()}
                    </span>
                  </td>
                  <td className="px-4 py-2 text-right">{r.visits_count || 0}</td>
                  <td className="px-4 py-2 text-right">{r.agent_messages_count || 0}</td>
                </tr>
                
                </>
              );
            })}
            {filtered.length === 0 && (
              <tr><td className="px-4 py-8 text-gray-500" colSpan={7}>Aucun visiteur.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

