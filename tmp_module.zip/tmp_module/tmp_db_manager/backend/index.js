import { registerTmpDbmAiRoutes } from './routes/ai.routes.js';

export function register(app, ctx) {
  registerTmpDbmAiRoutes(app, ctx);
}

