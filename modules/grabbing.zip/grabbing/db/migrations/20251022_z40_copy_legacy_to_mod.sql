-- Copy data from legacy grabbing_jerome_* tables into module-prefixed mod_grabbing_jerome_* tables
-- Safeguards:
--  - Only copy when legacy relation exists AND is a real table (not a view)
--  - Use ON CONFLICT DO NOTHING to avoid duplicates
--  - For serial IDs, omit id column to let new IDs be generated

DO $$
DECLARE
  is_table boolean;
BEGIN
  -- Queue
  SELECT (c.relkind = 'r') INTO is_table
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname='public' AND c.relname='grabbing_jerome_queue';
  IF is_table THEN
    EXECUTE $mig$
      INSERT INTO mod_grabbing_jerome_queue (id, url, status, added_at)
      SELECT id, url, status, added_at FROM grabbing_jerome_queue
      ON CONFLICT DO NOTHING
    $mig$;
  END IF;

  -- Extracts
  SELECT (c.relkind = 'r') INTO is_table
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname='public' AND c.relname='grabbing_jerome_extracts';
  IF is_table THEN
    EXECUTE $mig$
      INSERT INTO mod_grabbing_jerome_extracts (file_name, mtime, size, download_url, product_url, price, currency, image, declinaison, json_data)
      SELECT file_name, mtime, size, download_url, product_url, price, currency, image, declinaison, json_data
      FROM grabbing_jerome_extracts
      ON CONFLICT DO NOTHING
    $mig$;
  END IF;

  -- Transfers
  SELECT (c.relkind = 'r') INTO is_table
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname='public' AND c.relname='grabbing_jerome_transfers';
  IF is_table THEN
    EXECUTE $mig$
      INSERT INTO mod_grabbing_jerome_transfers (when_at, id_product, product_url, image, price, currency, declinaison, file, name)
      SELECT when_at, id_product, product_url, image, price, currency, declinaison, file, name
      FROM grabbing_jerome_transfers
      ON CONFLICT DO NOTHING
    $mig$;
  END IF;

  -- Domains
  SELECT (c.relkind = 'r') INTO is_table
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname='public' AND c.relname='grabbing_jerome_domains';
  IF is_table THEN
    EXECUTE $mig$
      INSERT INTO mod_grabbing_jerome_domains (domain, sitemap_url, sitemaps, selected_sitemaps, sitemap_total_urls, config, config_transfert, created_at, updated_at)
      SELECT domain, sitemap_url, sitemaps, selected_sitemaps, sitemap_total_urls, config, config_transfert, created_at, updated_at
      FROM grabbing_jerome_domains
      ON CONFLICT (domain) DO UPDATE SET
        sitemap_url = EXCLUDED.sitemap_url,
        sitemaps = EXCLUDED.sitemaps,
        selected_sitemaps = EXCLUDED.selected_sitemaps,
        sitemap_total_urls = EXCLUDED.sitemap_total_urls,
        config = EXCLUDED.config,
        config_transfert = EXCLUDED.config_transfert,
        updated_at = EXCLUDED.updated_at
    $mig$;
  END IF;

  -- Domains URL
  SELECT (c.relkind = 'r') INTO is_table
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname='public' AND c.relname='grabbing_jerome_domains_url';
  IF is_table THEN
    EXECUTE $mig$
      INSERT INTO mod_grabbing_jerome_domains_url (domain, url, type, title, page_type, meta, product, explored, discovered_at)
      SELECT domain, url, type, title,
             COALESCE(page_type, type) AS page_type,
             meta, product, explored, COALESCE(discovered_at, now())
      FROM grabbing_jerome_domains_url
      ON CONFLICT DO NOTHING
    $mig$;
  END IF;

  -- Page explore snapshots
  SELECT (c.relkind = 'r') INTO is_table
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname='public' AND c.relname='grabbing_jerome_domains_url_page_explore';
  IF is_table THEN
    EXECUTE $mig$
      INSERT INTO mod_grabbing_jerome_domains_url_page_explore (domain, url, page_type, meta, product, links_sample, explored_at, result_json, config_version)
      SELECT domain, url, page_type, meta, product, links_sample, explored_at, result_json, config_version
      FROM grabbing_jerome_domains_url_page_explore
      ON CONFLICT DO NOTHING
    $mig$;
  END IF;

  -- Ready to transfer
  SELECT (c.relkind = 'r') INTO is_table
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname='public' AND c.relname='grabbing_jerome_domains_url_ready_transfert';
  IF is_table THEN
    EXECUTE $mig$
      INSERT INTO mod_grabbing_jerome_domains_url_ready_transfert (domain, url, prepared_at, source_url_id, page_type, title, meta, product_raw, mapped, status, notes, id_product)
      SELECT domain, url, prepared_at, source_url_id, page_type, title, meta, product_raw, mapped, status, notes, id_product
      FROM grabbing_jerome_domains_url_ready_transfert
      ON CONFLICT DO NOTHING
    $mig$;
  END IF;

  -- Config history
  SELECT (c.relkind = 'r') INTO is_table
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname='public' AND c.relname='grabbing_jerome_domain_config_history';
  IF is_table THEN
    EXECUTE $mig$
      INSERT INTO mod_grabbing_jerome_domain_config_history (domain, config, saved_at, version, note)
      SELECT domain, config, saved_at, version, note
      FROM grabbing_jerome_domain_config_history
      ON CONFLICT DO NOTHING
    $mig$;
  END IF;

  -- Transfer config history
  SELECT (c.relkind = 'r') INTO is_table
  FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
  WHERE n.nspname='public' AND c.relname='grabbing_jerome_domain_config_transfert_history';
  IF is_table THEN
    EXECUTE $mig$
      INSERT INTO mod_grabbing_jerome_domain_config_transfert_history (domain, type, config, saved_at, version)
      SELECT domain, type, config, saved_at, version
      FROM grabbing_jerome_domain_config_transfert_history
      ON CONFLICT DO NOTHING
    $mig$;
  END IF;
END $$ LANGUAGE plpgsql;
