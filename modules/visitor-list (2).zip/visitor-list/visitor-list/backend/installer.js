/**
 * Visitor List Module Installer
 * - Applies SQL migrations under modules/visitor-list/db/migrations
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const moduleRoot = path.resolve(__dirname, '..');
const migrationsDir = path.join(moduleRoot, 'db', 'migrations');
const appBackendDir = path.resolve(moduleRoot, '..', '..', 'backend');

async function getPgPool() {
  try {
    const pg = await import('pg');
    const { Pool } = pg.default || pg;
    return new Pool({ connectionString: process.env.DATABASE_URL });
  } catch {}
  const pgEsm = path.join(appBackendDir, 'node_modules', 'pg', 'esm', 'index.mjs');
  const pg = await import(pathToFileURL(pgEsm).href);
  const { Pool } = pg;
  const url = (process.env.DATABASE_URL || '').trim();
  return new Pool(url ? { connectionString: url } : undefined);
}

async function applyMigrations(pool) {
  if (!fs.existsSync(migrationsDir)) return;
  // Minimal migrations log (module-scoped)
  await pool.query(`CREATE TABLE IF NOT EXISTS migrations_log (
    id SERIAL PRIMARY KEY,
    module_name VARCHAR(255),
    filename VARCHAR(255),
    applied_at TIMESTAMP DEFAULT NOW(),
    CONSTRAINT uq_migrations_log UNIQUE(module_name, filename)
  );`);
  const files = fs.readdirSync(migrationsDir).filter(f => f.endsWith('.sql')).sort();
  for (const file of files) {
    const seen = await pool.query(`SELECT 1 FROM migrations_log WHERE module_name=$1 AND filename=$2`, ['visitor-list', file]);
    if (seen.rowCount) continue;
    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query(sql);
      await client.query(`INSERT INTO migrations_log(module_name, filename) VALUES ($1,$2)`, ['visitor-list', file]);
      await client.query('COMMIT');
    } catch (e) {
      try { await client.query('ROLLBACK'); } catch {}
      throw e;
    } finally { client.release(); }
  }
}

export async function installModule() {
  const pool = await getPgPool();
  await applyMigrations(pool);
  await pool.end().catch(() => {});
}

if (import.meta.url === pathToFileURL(__filename).href) {
  installModule().catch((e) => { console.error('[visitor-list] installer failed:', e?.message || e); process.exitCode = 1; });
}

