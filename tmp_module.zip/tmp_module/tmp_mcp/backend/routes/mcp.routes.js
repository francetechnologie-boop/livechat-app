import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

function backendDirFromModule() {
  const here = path.resolve(path.dirname(new URL(import.meta.url).pathname));
  const repoRootGuess = path.resolve(here, '../../../../');
  const candidate = path.join(repoRootGuess, 'backend');
  try { if (fs.existsSync(candidate)) return candidate; } catch {}
  try { const cwd = process.cwd(); if (fs.existsSync(path.join(cwd, 'package.json'))) return cwd; } catch {}
  return candidate;
}

export function registerTmpMcpRoutes(app, ctx = {}) {
  const requireAdmin = ctx.requireAdmin || ((_req, res) => { res.status(401).json({ ok:false, error: 'unauthorized' }); return null; });
  const requireAuth = ctx.requireAuth || ((_req, res) => { res.status(401).json({ ok:false, error: 'unauthorized' }); return null; });
  const getSetting = ctx.getSetting || (async () => null);
  const setSetting = ctx.setSetting || (async () => {});
  const pool = ctx.pool;
  const extras = ctx.extras || {};

  async function importMcpTools() {
    try {
      const backendDir = backendDirFromModule();
      const { pathToFileURL } = await import('url');
      const mod = await import(pathToFileURL(path.join(backendDir, 'lib', 'mcpTools.js')).href);
      return mod && (mod.createMcpTools || mod.default);
    } catch { return null; }
  }

  function makeMcp() {
    const create = extras.__createMcpTools || null;
    const fallback = create;
    const uploadDir = path.join(backendDirFromModule(), 'uploads', 'mcp');
    try { fs.mkdirSync(uploadDir, { recursive: true }); } catch {}
    let mcp = null;
    const deps = {
      pool,
      io: extras.io,
      dbSchema: extras.dbSchema,
      ensureVisitorExists: extras.ensureVisitorExists,
      sanitizeAgentHtmlServer: extras.sanitizeAgentHtmlServer,
      textToSafeHTML: extras.textToSafeHTML,
      upsertVisitorColumns: extras.upsertVisitorColumns,
      uploadDir,
      verifyToken: async (token) => {
        try { const t = await getSetting('MCP_TOKEN'); if (t && String(token||'') !== String(t)) return false; return true; } catch { return true; }
      },
      needsAuth: async () => { try { const t = await getSetting('MCP_TOKEN'); return !!t; } catch { return false; } }
    };
    return { deps, uploadDir };
  }

  async function ensureMcpFilesTable() {
    try { await pool.query(`CREATE TABLE IF NOT EXISTS mcp_files (id TEXT PRIMARY KEY, file_name TEXT, file_path TEXT, content_type TEXT, size_bytes BIGINT, server_name TEXT, bot_id TEXT, created_at TIMESTAMP DEFAULT NOW())`); } catch {}
  }

  // Status: simple OK, can be expanded to include http base
  app.get('/mcp/status', (_req, res) => {
    res.json({ ok: true, notes: 'MCP status OK' });
  });

  // Agent token fetch (session-authenticated)
  app.get('/api/mcp/token', async (req, res) => {
    const u = requireAuth(req, res); if (!u) return;
    try {
      const t = await getSetting('MCP_TOKEN');
      if (!t) return res.json({ ok: true, required: false, token: null });
      res.json({ ok: true, required: true, token: t });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Admin: read/regenerate/disable global MCP token
  app.get('/api/admin/mcp/token', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const t = await getSetting('MCP_TOKEN'); res.json({ ok:true, token: t || null, required: !!t }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/admin/mcp/token/regenerate', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const tok = (globalThis.crypto?.randomUUID?.() || '') + '-' + (crypto.randomBytes ? crypto.randomBytes(16).toString('hex') : Math.random().toString(16).slice(2)); await setSetting('MCP_TOKEN', tok); res.json({ ok:true, token: tok }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/admin/mcp/token/disable', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { await setSetting('MCP_TOKEN', ''); res.json({ ok:true, token: null, required: false }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/admin/mcp/token', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const t = String(req.body?.token || '').trim(); await setSetting('MCP_TOKEN', t); res.json({ ok:true, token: t || null, required: !!t }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Admin: MCP public base
  app.get('/api/admin/mcp/public-base', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const v = await getSetting('MCP_PUBLIC_BASE'); res.json({ ok:true, value: v || null }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/admin/mcp/public-base', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const v = String(req.body?.value || '').trim(); await setSetting('MCP_PUBLIC_BASE', v); res.json({ ok:true, value: v || null }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Per-bot MCP token management (chatbot_config table)
  app.get('/api/automations/chatbots/:id/mcp/token', async (req, res) => {
    const u = requireAuth(req, res); if (!u) return;
    try { const id = String(req.params.id || '').trim(); const r = await pool.query(`SELECT mcp_token FROM chatbot_config WHERE id_bot=$1`, [id]); const token = r.rowCount ? (r.rows[0].mcp_token || null) : null; res.json({ ok:true, required: !!token, token }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/automations/chatbots/:id/mcp/token/regenerate', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const id = String(req.params.id || '').trim(); const tok = (globalThis.crypto?.randomUUID?.() || '') + '-' + (crypto.randomBytes ? crypto.randomBytes(16).toString('hex') : Math.random().toString(16).slice(2)); await pool.query(`UPDATE chatbot_config SET mcp_token=$1, updated_at=NOW() WHERE id_bot=$2`, [tok, id]); res.json({ ok:true, token: tok }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/automations/chatbots/:id/mcp/token/disable', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const id = String(req.params.id || '').trim(); await pool.query(`UPDATE chatbot_config SET mcp_token=NULL, updated_at=NOW() WHERE id_bot=$1`, [id]); res.json({ ok:true, token: null, required: false }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/automations/chatbots/:id/mcp/token', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const id = String(req.params.id || '').trim(); const t = String(req.body?.token || '').trim(); await pool.query(`UPDATE chatbot_config SET mcp_token=$1, updated_at=NOW() WHERE id_bot=$2`, [t || null, id]); res.json({ ok:true, token: t || null, required: !!t }); }
    catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // -------- Tools listing and calling --------
  app.get('/mcp/actions/tools', async (req, res) => {
    try {
      const createMcpTools = await importMcpTools();
      if (!createMcpTools) return res.status(500).json({ ok:false, error:'mcp_init_failed' });
      const { deps } = makeMcp();
      const mcp = createMcpTools(deps);
      const list = mcp.tools();
      res.json({ ok:true, tools: list });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/mcp/actions/tools/call', async (req, res) => {
    try {
      const { name, arguments: args } = req.body || {};
      if (!name) return res.status(400).json({ ok:false, error:'bad_request', message:'name required' });
      const createMcpTools = await importMcpTools();
      if (!createMcpTools) return res.status(500).json({ ok:false, error:'mcp_init_failed' });
      const { deps } = makeMcp();
      const mcp = createMcpTools(deps);
      const out = await mcp.run(name, args || {}, {});
      res.json({ ok:true, result: out });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // -------- Files list and download (basic) --------
  app.get('/mcp/files', async (req, res) => {
    try {
      await ensureMcpFilesTable();
      const limit = Math.max(1, Math.min(200, Number(req.query.limit || 50)));
      const r = await pool.query(`SELECT id, file_name, content_type, size_bytes, server_name, bot_id, created_at FROM mcp_files ORDER BY created_at DESC LIMIT $1`, [limit]);
      res.json({ ok:true, items: r.rows || [] });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.get('/mcp/file/:id/download', async (req, res) => {
    try {
      const id = String(req.params.id||'').trim(); if (!id) return res.status(400).json({ ok:false, error:'bad_request' });
      await ensureMcpFilesTable();
      const r = await pool.query(`SELECT * FROM mcp_files WHERE id=$1 LIMIT 1`, [id]);
      if (!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' });
      const row = r.rows[0];
      const p = path.isAbsolute(row.file_path) ? row.file_path : path.join(backendDirFromModule(), row.file_path);
      if (!fs.existsSync(p)) return res.status(404).json({ ok:false, error:'not_found' });
      res.setHeader('Content-Type', row.content_type || 'application/octet-stream');
      res.setHeader('Content-Disposition', `attachment; filename="${row.file_name || (id + '.bin')}"`);
      fs.createReadStream(p).pipe(res);
    } catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Base64 upload (like mcp-dev variant)
  app.post('/mcp/files/base64', async (req, res) => {
    try {
      const { filename, content_base64, bot_id } = req.body || {};
      if (!filename || !content_base64) return res.status(400).json({ ok:false, error:'bad_request' });
      await ensureMcpFilesTable();
      const id = (globalThis.crypto?.randomUUID?.() || '') + '-' + (Math.random().toString(16).slice(2));
      const buf = Buffer.from(String(content_base64), 'base64');
      const backendDir = backendDirFromModule();
      const rel = path.join('uploads', 'mcp', `${id}-${filename.replace(/[^A-Za-z0-9._\-]/g,'_')}`);
      const full = path.join(backendDir, rel);
      fs.mkdirSync(path.dirname(full), { recursive: true });
      fs.writeFileSync(full, buf);
      const ct = 'application/octet-stream';
      await pool.query(`INSERT INTO mcp_files (id, file_name, file_path, content_type, size_bytes, server_name, bot_id) VALUES ($1,$2,$3,$4,$5,$6,$7)`, [id, filename, rel, ct, buf.length, 'MCP', bot_id || null]);
      res.status(201).json({ ok:true, id, file: { id, name: filename, size: buf.length } });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message||String(e) }); }
  });

  // -------- SSE + Stream (minimal) --------
  app.get(['/mcp/events', '/mcp/sse', '/mcp2/events', '/mcp2/sse', '/mcp/:name/events', '/mcp/:name/sse'], (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders?.();
    let alive = true;
    req.on('close', () => { alive = false; });
    const ping = setInterval(() => { if (!alive) { clearInterval(ping); return; } try { res.write(`event: ping\n`); res.write(`data: {"ts":${Date.now()}}\n\n`); } catch { clearInterval(ping); } }, 15000);
  });
  app.post(['/mcp/stream','/mcp2/stream','/mcp/:name/stream','/mcp2/:name/stream'], async (req, res) => {
    try {
      const { name, arguments: args } = req.body || {};
      if (!name) return res.status(400).json({ ok:false, error:'bad_request', message:'name required' });
      const createMcpTools = await importMcpTools();
      if (!createMcpTools) return res.status(500).json({ ok:false, error:'mcp_init_failed' });
      const { deps } = makeMcp();
      const mcp = createMcpTools(deps);
      const out = await mcp.run(name, args || {}, {});
      res.json({ ok:true, result: out });
    } catch (e) { res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
}
