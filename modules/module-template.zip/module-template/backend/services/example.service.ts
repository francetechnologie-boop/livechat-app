export function greet(name: string): string {
  return `Hello, ${name}!`;
}

