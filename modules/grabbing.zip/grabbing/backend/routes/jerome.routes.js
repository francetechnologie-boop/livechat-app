import fs from 'fs';
import path from 'path';

function backendDirFromModule() {
  const here = path.resolve(path.dirname(new URL(import.meta.url).pathname));
  const repoRootGuess = path.resolve(here, '../../../../');
  const candidate = path.join(repoRootGuess, 'backend');
  try { if (fs.existsSync(candidate)) return candidate; } catch {}
  try { const cwd = process.cwd(); if (fs.existsSync(path.join(cwd, 'package.json'))) return cwd; } catch {}
  return candidate;
}

export function registerJeromeRoutes(app, ctx = {}) {
  const requireAdmin = ctx.requireAdmin || ((_req, res) => { res.status(401).json({ error: 'unauthorized' }); return null; });
  const pool = ctx.pool;
  const log = (m) => { try { ctx.logToFile?.(`[grabbing:jerome] ${m}`); } catch {} };

  const backendDir = backendDirFromModule();
  const jeromeDir = path.join(backendDir, 'uploads', 'grabbing-jerome');
  const configDir = path.join(jeromeDir, 'config');
  try { fs.mkdirSync(jeromeDir, { recursive: true }); } catch {}
  try { fs.mkdirSync(configDir, { recursive: true }); } catch {}

  async function getPg() {
    // ctx.pool is a lazy wrapper (modulePool) compatible with pool.query
    if (!pool || typeof pool.query !== 'function') throw new Error('db_unavailable');
    return pool;
  }

  // Helper: normalize domain string
  function normDomain(input) {
    let raw = String(input || '').trim();
    if (!raw) return '';
    try { if (/^https?:\/\//i.test(raw)) { const u = new URL(raw); raw = (u.hostname || '').toLowerCase(); } } catch {}
    return raw.toLowerCase().replace(/^www\./, '');
  }

  // Alias register helper
  const add = (method, path1, path2, handler) => {
    app[method](path1, handler);
    if (path2) app[method](path2, handler);
  };

  // Helper: best-effort importer for backend normalizer (optional)
  async function importNormalizer() {
    try {
      const file = path.join(backendDir, 'lib', 'grabbing', 'normalize.js');
      if (fs.existsSync(file)) {
        const { pathToFileURL } = await import('url');
        const mod = await import(pathToFileURL(file).href);
        if (mod && (mod.mapProductForPresta || (mod.default && mod.default.mapProductForPresta))) {
          const mapProductForPresta = mod.mapProductForPresta || mod.default.mapProductForPresta;
          return { mapProductForPresta };
        }
      }
    } catch {}
    return { mapProductForPresta: (_meta = {}, _product = {}) => ({ name:'', sku:'', price:null, currency:'', images:[], documents:[], description:'', variants:[] }) };
  }

  // Persist selected sitemaps for a domain
  add('post', '/api/grabbing/jerome/domains/select', '/api/grabbings/jerome/domains/select', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const p = await getPg();
      const domain = normDomain(req.body?.domain);
      const list = Array.isArray(req.body?.sitemaps) ? req.body.sitemaps : [];
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      if (!list.length) return res.status(400).json({ ok:false, error:'bad_request', message:'sitemaps required' });
      const norm = [];
      for (const s of list) {
        try { const abs = new URL(String(s), `https://${domain}`).toString(); norm.push(abs); } catch {}
      }
      const uniq = Array.from(new Set(norm));
      if (!uniq.length) return res.status(400).json({ ok:false, error:'bad_request', message:'no valid sitemaps' });
      await p.query(
        `insert into mod_grabbing_jerome_domains(domain, selected_sitemaps, updated_at)
         values($1,$2::jsonb, now())
         on conflict (domain)
         do update set selected_sitemaps = EXCLUDED.selected_sitemaps, updated_at = now()`,
        [domain, JSON.stringify(uniq)]
      );
      return res.json({ ok:true, domain, selected_sitemaps: uniq });
    } catch (e) { return res.status(500).json({ ok:false, error:'select_failed', message: e?.message || String(e) }); }
  });

  // List URLs for a domain from grabbing_jerome_domains_url
  add('get', '/api/grabbing/jerome/domains/urls', '/api/grabbings/jerome/domains/urls', async (req, res) => {
    try {
      const domain = normDomain(req.query?.domain);
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      const limit = Math.min(1000, Math.max(1, Number(req.query?.limit || 200)));
      const offset = Math.max(0, Number(req.query?.offset || 0));
      const p = await getPg();
      const c = await p.query('select count(*)::int as c from public.mod_grabbing_jerome_domains_url where domain=$1', [domain]);
      const total = Number(c.rows?.[0]?.c || 0);
      const { rows } = await p.query(
        `select u.id, u.url,
                coalesce(u.page_type, u.type) as page_type,
                u.explored,
                coalesce(u.title, (u.meta->>'title')) as title,
                (u.meta->>'type_reason') as type_reason,
                (select e.config_version from public.mod_grabbing_jerome_domains_url_page_explore e where e.domain=u.domain and lower(trim(both from e.url))=lower(trim(both from u.url)) order by e.explored_at desc nulls last limit 1) as config_version
           from public.mod_grabbing_jerome_domains_url u
          where u.domain=$1
          order by u.id asc limit $2 offset $3`,
        [domain, limit, offset]
      );
      return res.json({ ok:true, domain, total, items: rows });
    } catch (e) { return res.status(500).json({ ok:false, error:'list_failed', message: e?.message || String(e) }); }
  });

  // Reset explored status and snapshots for a domain (optionally limited to URL list)
  add('post', '/api/grabbing/jerome/domains/urls/reset-explored', '/api/grabbings/jerome/domains/urls/reset-explored', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const domain = normDomain(req.body?.domain);
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      const urls = Array.isArray(req.body?.urls) ? req.body.urls.map(s=>String(s||'').trim()).filter(Boolean) : [];
      const all = !!req.body?.all;
      const deleteUrls = !!req.body?.delete_urls;
      if (!all && !urls.length) return res.status(400).json({ ok:false, error:'bad_request', message:'provide urls[] or set all=true' });
      const p = await getPg();
      let deleted = 0, affected = 0;
      if (all) {
        const del = await p.query('delete from public.mod_grabbing_jerome_domains_url_page_explore where domain=$1', [domain]);
        deleted = Number(del.rowCount||0);
        if (deleteUrls) {
          const del2 = await p.query('delete from public.mod_grabbing_jerome_domains_url where domain=$1', [domain]);
          affected = Number(del2.rowCount||0);
        } else {
          const upd = await p.query('update public.mod_grabbing_jerome_domains_url set explored=NULL where domain=$1', [domain]);
          affected = Number(upd.rowCount||0);
        }
      } else {
        const list = urls.map(s=>s.toLowerCase().trim());
        const del = await p.query('delete from public.mod_grabbing_jerome_domains_url_page_explore where domain=$1 and lower(trim(both from url)) = any($2::text[])', [domain, list]);
        deleted = Number(del.rowCount||0);
        if (deleteUrls) {
          const del2 = await p.query('delete from public.mod_grabbing_jerome_domains_url where domain=$1 and lower(trim(both from url)) = any($2::text[])', [domain, list]);
          affected = Number(del2.rowCount||0);
        } else {
          const upd = await p.query('update public.mod_grabbing_jerome_domains_url set explored=NULL where domain=$1 and lower(trim(both from url)) = any($2::text[])', [domain, list]);
          affected = Number(upd.rowCount||0);
        }
      }
      return res.json({ ok:true, domain, deleted_snapshots: deleted, affected_rows: affected, deleted_urls: deleteUrls });
    } catch (e) { return res.status(500).json({ ok:false, error:'reset_failed', message: e?.message || String(e) }); }
  });

  // Clear metadata fields on stored domain URLs (without deleting rows)
  add('post', '/api/grabbing/jerome/domains/urls/clear-fields', '/api/grabbings/jerome/domains/urls/clear-fields', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const domain = normDomain(req.body?.domain);
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      const urls = Array.isArray(req.body?.urls) ? req.body.urls.map(s=>String(s||'').trim()).filter(Boolean) : [];
      const all = !!req.body?.all;
      const resetDiscoveredAt = !!req.body?.reset_discovered_at;
      if (!all && !urls.length) return res.status(400).json({ ok:false, error:'bad_request', message:'provide urls[] or set all=true' });
      const p = await getPg();
      let affected = 0;
      if (all) {
        const upd = await p.query(
          `update public.mod_grabbing_jerome_domains_url
              set type=NULL,
                  title=NULL,
                  page_type=NULL,
                  meta=NULL,
                  product=NULL,
                  explored=NULL,
                  discovered_at = case when $2 then now() else discovered_at end
            where domain=$1`,
          [domain, resetDiscoveredAt]
        );
        affected = Number(upd.rowCount||0);
      } else {
        const list = urls.map(s=>s.toLowerCase().trim());
        const upd = await p.query(
          `update public.mod_grabbing_jerome_domains_url
              set type=NULL,
                  title=NULL,
                  page_type=NULL,
                  meta=NULL,
                  product=NULL,
                  explored=NULL,
                  discovered_at = case when $3 then now() else discovered_at end
            where domain=$1 and lower(trim(both from url)) = any($2::text[])`,
          [domain, list, resetDiscoveredAt]
        );
        affected = Number(upd.rowCount||0);
      }
      return res.json({ ok:true, domain, affected_rows: affected, reset_discovered_at: resetDiscoveredAt });
    } catch (e) { return res.status(500).json({ ok:false, error:'clear_failed', message: e?.message || String(e) }); }
  });

  // List recent page explores for a domain
  add('get', '/api/grabbing/jerome/page/explore/list', '/api/grabbings/jerome/page/explore/list', async (req, res) => {
    try {
      const domain = normDomain(req.query?.domain);
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      const limit = Math.min(500, Math.max(1, Number(req.query?.limit || 100)));
      const p = await getPg();
      const c = await p.query('select count(*)::int as c from public.mod_grabbing_jerome_domains_url_page_explore where domain=$1', [domain]);
      const total = Number(c.rows?.[0]?.c || 0);
      const { rows } = await p.query('select url, page_type, explored_at from public.mod_grabbing_jerome_domains_url_page_explore where domain=$1 order by explored_at desc limit $2', [domain, limit]);
      return res.json({ ok:true, domain, total, items: rows });
    } catch (e) { return res.status(500).json({ ok:false, error:'list_failed', message: e?.message || String(e) }); }
  });

  // Sitemap tree builder (index and urlset traversal, small sample)
  add('get', '/api/grabbing/jerome/sitemap/tree', '/api/grabbings/jerome/sitemap/tree', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const startUrl = String(req.query?.url || '').trim();
      if (!/^https?:\/\//i.test(startUrl)) return res.status(400).json({ ok:false, error:'bad_request', message:'Valid url required' });
      const maxSitemaps = Math.max(1, Math.min(Number(req.query?.max_sitemaps || 2000), 100000));
      const origin = new URL(startUrl);
      const visited = new Set();
      const flat = new Set();
      const parseXml = (xml) => {
        const locs = Array.from(xml.matchAll(/<loc>\s*([^<\s][^<]*)\s*<\/loc>/gi)).map(m => (m && m[1] ? m[1].trim() : '')).filter(Boolean);
        const isIndex = /<sitemapindex[\s>]/i.test(xml);
        const lastmods = [];
        try {
          const smRe = /<sitemap>([\s\S]*?)<\/sitemap>/gi; let m;
          while ((m = smRe.exec(xml))) { const block = m[1]||''; const loc = ((block.match(/<loc>\s*([^<]+)\s*<\/loc>/i)||[])[1]||'').trim(); const lm = ((block.match(/<lastmod>\s*([^<]+)\s*<\/lastmod>/i)||[])[1]||'').trim(); if (loc) lastmods.push({ loc, lastmod: lm }); }
        } catch {}
        return { isIndex, locs, lastmods };
      };
      const gunzipMaybe = async (buf, url) => {
        try { if (/\.gz($|\?)/i.test(url)) { const z = await import('zlib'); return z.gunzipSync(Buffer.from(buf)).toString('utf8'); } } catch {}
        return Buffer.isBuffer(buf) ? buf.toString('utf8') : String(buf);
      };
      const fetchSitemap = async (url) => {
        const node = { url, type:'urlset', children:[] };
        if (!url || visited.has(url) || visited.size >= maxSitemaps) return node;
        visited.add(url); flat.add(url);
        const r = await fetch(url, { method:'GET' });
        if (!r.ok) return node;
        const arr = Buffer.from(await r.arrayBuffer());
        const xml = await gunzipMaybe(arr, url);
        const { isIndex, locs, lastmods } = parseXml(xml||'');
        if (isIndex) node.type = 'index';
        try { const lmSelf = (xml.match(/<lastmod>\s*([^<]+)\s*<\/lastmod>/i) || [])[1]; if (lmSelf) node.lastmod = lmSelf.trim(); } catch {}
        if (isIndex) {
          for (const loc of (locs||[])) {
            if (node.children.length >= maxSitemaps) break;
            try { const abs = new URL(loc, origin).toString(); const child = await fetchSitemap(abs); const lm = (lastmods.find(x => (x.loc||'').trim() === loc.trim()) || {}).lastmod; if (lm && !child.lastmod) child.lastmod = lm; node.children.push(child); } catch {}
          }
        } else { node.sample = (locs||[]).slice(0, 25).map(loc => { try { return new URL(loc, origin).toString(); } catch { return loc; } }); }
        return node;
      };
      const root = await fetchSitemap(new URL(startUrl).toString());
      return res.json({ ok:true, root, flat_sitemaps: Array.from(flat) });
    } catch (e) { return res.status(500).json({ ok:false, error:'tree_failed', message: e?.message || String(e) }); }
  });

  // Get per-domain extraction config (DB first, fallback to file)
  add('get', '/api/grabbing/jerome/domains/config', '/api/grabbings/jerome/domains/config', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const domain = normDomain(req.query?.domain);
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      const safe = domain.replace(/[^a-z0-9.-]/g,'_');
      const filePath = path.join(configDir, `${safe}.json`);
      const p = await getPg();
      try {
        const r = await p.query('select config, (select max(version) from mod_grabbing_jerome_domain_config_history where domain=$1) as version from mod_grabbing_jerome_domains where domain=$1 limit 1', [domain]);
        if (r.rows && r.rows.length && r.rows[0].config) {
          let config_text = '';
          try { if (fs.existsSync(filePath)) config_text = fs.readFileSync(filePath, 'utf8'); } catch {}
          if (!config_text) { try { config_text = JSON.stringify(r.rows[0].config, null, 2); } catch {} }
          const version = Number(r.rows?.[0]?.version ?? '') || null;
          return res.json({ ok:true, domain, config: r.rows[0].config, config_text, version });
        }
      } catch {}
      // Fallback to file only when DB is empty
      let cfg = {};
      try { if (fs.existsSync(filePath)) { const t = fs.readFileSync(filePath, 'utf8'); cfg = JSON.parse(t); } } catch {}
      let config_text = '';
      try { if (fs.existsSync(filePath)) config_text = fs.readFileSync(filePath, 'utf8'); } catch {}
      // Best-effort version lookup
      let version = null;
      try { const vr = await p.query('select max(version) as v from mod_grabbing_jerome_domain_config_history where domain=$1', [domain]); version = Number(vr.rows?.[0]?.v ?? '') || null; } catch {}
      return res.json({ ok:true, domain, config: cfg, config_text, version, source: 'file' });
    } catch (e) { return res.status(500).json({ ok:false, error:'config_failed', message: e?.message || String(e) }); }
  });

  // Explore a single page and optionally persist snapshot in module tables
  add('post', '/api/grabbing/jerome/page/explore', '/api/grabbings/jerome/page/explore', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const rawUrl = String(req.body?.url || '').trim();
      if (!/^https?:\/\//i.test(rawUrl)) return res.status(400).json({ ok:false, error:'bad_request', message:'Valid url required' });
      const urlObj = new URL(rawUrl);
      const domain = normDomain(urlObj.hostname);
      const preview = !!req.body?.preview;
      const p = await getPg();
      // quick allow if domain present in module domains
      try { const r = await p.query('select 1 from mod_grabbing_jerome_domains where domain=$1 limit 1', [domain]); if (!r.rowCount) return res.status(403).json({ ok:false, error:'forbidden', message:'domain_not_selected' }); } catch {}
      const r = await fetch(rawUrl, { method:'GET', redirect:'follow', headers:{ 'user-agent':'Mozilla/5.0 (compatible; LivechatBot/1.0)' } });
      if (!r.ok) return res.status(502).json({ ok:false, error:'fetch_failed', status:r.status });
      const html = await r.text();
      const getTitle = () => { const m = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i); return m && m[1] ? m[1].trim() : ''; };
      const ogType = (()=>{ const m = html.match(/<meta[^>]+property=["']og:type["'][^>]*content=["']([^"']+)["'][^>]*>/i); return m && m[1] ? m[1].trim().toLowerCase() : ''; })();
      const hasArticle = /<article[\s>]|property=["']article:/i.test(html);
      const pathLower = (urlObj.pathname||'').toLowerCase();
      const hasCollectionSignals = /category|collections|catalog|listing/.test(pathLower);
      let page_type = 'page';
      if (ogType === 'product' || /product/.test(pathLower)) page_type = 'product';
      else if (hasCollectionSignals) page_type = 'category';
      else if (hasArticle) page_type = 'article';
      const meta = { title: getTitle() };
      const product = {};
      if (!preview) {
        await p.query(
          `insert into public.mod_grabbing_jerome_domains_url(domain,url,type,title,page_type,meta,product,explored,discovered_at)
           values($1,$2,$3,$4,$5,$6::jsonb,$7::jsonb, now(), coalesce((select discovered_at from public.mod_grabbing_jerome_domains_url where domain=$1 and lower(trim(both from url))=lower(trim(both from $2)) limit 1), now()))
           on conflict (domain, lower(trim(both from url))) do update
           set type=EXCLUDED.type, title=EXCLUDED.title, page_type=EXCLUDED.page_type, meta=EXCLUDED.meta, product=EXCLUDED.product, explored=now()`,
          [domain, rawUrl, page_type, meta.title||'', page_type, JSON.stringify(meta||{}), JSON.stringify(product||{})]
        );
        await p.query(
          `insert into public.mod_grabbing_jerome_domains_url_page_explore(domain,url,page_type,meta,product,links_sample,explored_at,result_json,config_version)
           values($1,$2,$3,$4::jsonb,$5::jsonb,$6::jsonb, now(), $7::jsonb, null)
           on conflict (domain, lower(trim(both from url))) do update
           set page_type=EXCLUDED.page_type, meta=EXCLUDED.meta, product=EXCLUDED.product, links_sample=EXCLUDED.links_sample, explored_at=EXCLUDED.explored_at, result_json=EXCLUDED.result_json`,
          [domain, rawUrl, page_type, JSON.stringify(meta||{}), JSON.stringify(product||{}), JSON.stringify([]), JSON.stringify({ meta, product, page_type, url: rawUrl })]
        );
      }
      return res.json({ ok:true, url: rawUrl, page_type, meta, product, links_sample: [] });
    } catch (e) { return res.status(500).json({ ok:false, error:'explore_failed', message: e?.message || String(e) }); }
  });

  // Resolve stored snapshot (result_json) for a domain+url
  add('get', '/api/grabbing/jerome/domains/url/stored', '/api/grabbings/jerome/domains/url/stored', async (req, res) => {
    try {
      const domain = normDomain(req.query?.domain);
      const rawUrl = String(req.query?.url || '').trim();
      if (!domain || !rawUrl) return res.status(400).json({ ok:false, error:'bad_request', message:'domain and url required' });
      const p = await getPg();
      const q = await p.query(
        `select url, page_type, explored_at, result_json
           from public.mod_grabbing_jerome_domains_url_page_explore
          where domain=$1 and lower(trim(both from url)) = lower(trim(both from $2))
          order by explored_at desc nulls last
          limit 1`,
        [domain, rawUrl]
      );
      if (!q.rows?.length) return res.status(404).json({ ok:false, error:'not_found' });
      const row = q.rows[0];
      return res.json({ ok:true, item:{ domain, url: row.url, page_type: row.page_type || null, explored_at: row.explored_at || null, result_json: row.result_json || null } });
    } catch (e) { return res.status(500).json({ ok:false, error:'stored_read_failed', message: e?.message || String(e) }); }
  });

  // Resolve config_version for a batch of URLs
  add('post', '/api/grabbing/jerome/domains/urls/versions', '/api/grabbings/jerome/domains/urls/versions', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const domain = normDomain(req.body?.domain);
      const urls = Array.isArray(req.body?.urls) ? req.body.urls.map(x=>String(x||'').trim()).filter(Boolean) : [];
      if (!domain || !urls.length) return res.status(400).json({ ok:false, error:'bad_request', message:'domain and urls required' });
      const p = await getPg();
      const keys = urls.map(s => s.toLowerCase().trim());
      const sql = `
        select distinct on (lower(trim(both from url)))
               url,
               coalesce(config_version, nullif((result_json->'meta'->'config_used'->>'version'),'')::int) as config_version,
               explored_at
          from public.mod_grabbing_jerome_domains_url_page_explore
         where domain = $1
           and lower(trim(both from url)) = any($2)
         order by lower(trim(both from url)), explored_at desc nulls last`;
      const { rows } = await p.query(sql, [domain, keys]);
      return res.json({ ok:true, domain, items: rows });
    } catch (e) { return res.status(500).json({ ok:false, error:'versions_failed', message: e?.message || String(e) }); }
  });

  // Prepare a URL for Presta transfer (insert/upsert into ready table)
  add('post', '/api/grabbing/jerome/domains/url/prepare-presta', '/api/grabbings/jerome/domains/url/prepare-presta', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const domain = normDomain(req.body?.domain);
      const rawUrl = String(req.body?.url || '').trim();
      if (!domain || !rawUrl) return res.status(400).json({ ok:false, error:'bad_request', message:'domain and url required' });
      const p = await getPg();
      const norm = rawUrl.toLowerCase().trim();
      const one = await p.query(
        `select coalesce(pa
                ge_type, type) as page_type, title, meta, product
           from public.mod_grabbing_jerome_domains_url
          where domain=$1 and lower(trim(both from url)) = lower(trim(both from $2))
          limit 1`,
        [domain, rawUrl]
      );
      const pe = await p.query(
        `select result_json, config_version
           from public.mod_grabbing_jerome_domains_url_page_explore
          where domain=$1 and lower(trim(both from url)) = lower(trim(both from $2))
          order by explored_at desc nulls last
          limit 1`,
        [domain, rawUrl]
      );
      const meta = (one.rows?.[0]?.meta || pe.rows?.[0]?.result_json?.meta || {}) || {};
      const product = (one.rows?.[0]?.product || pe.rows?.[0]?.result_json?.product || {}) || {};
      const page_type = (one.rows?.[0]?.page_type || pe.rows?.[0]?.result_json?.page_type || null);
      const cv = pe.rows?.[0]?.config_version || null;
      const { mapProductForPresta } = await importNormalizer();
      const mapped0 = mapProductForPresta(meta, product);
      await p.query(
        `insert into public.mod_grabbing_jerome_domains_url_ready_transfert(domain,url,prepared_at,source_url_id,page_type,title,meta,product_raw,mapped,status,notes,id_product,config_transfert_version)
         values($1,$2, now(), null, $3, $4, $5::jsonb, $6::jsonb, $7::jsonb, 'pending', null, null, $8)
         on conflict (domain, lower(trim(both from url))) do update set page_type=EXCLUDED.page_type, title=EXCLUDED.title, meta=EXCLUDED.meta, product_raw=EXCLUDED.product_raw, mapped=EXCLUDED.mapped, prepared_at=EXCLUDED.prepared_at, config_transfert_version=EXCLUDED.config_transfert_version`,
        [domain, rawUrl, page_type, (product?.name || meta?.title || ''), JSON.stringify(meta||{}), JSON.stringify(product||{}), JSON.stringify(mapped0||{}), cv]
      );
      return res.json({ ok:true, domain, url: rawUrl, page_type, mapped: mapped0, version: cv });
    } catch (e) { return res.status(500).json({ ok:false, error:'prepare_failed', message: e?.message || String(e) }); }
  });

  // Ready transfers list for a domain
  add('get', '/api/grabbing/jerome/domains/ready-transfers', '/api/grabbings/jerome/domains/ready-transfers', async (req, res) => {
    try {
      const domain = normDomain(req.query?.domain);
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      const limit = Math.min(1000, Math.max(1, Number(req.query?.limit || 200)));
      const offset = Math.max(0, Number(req.query?.offset || 0));
      const p = await getPg();
      const c = await p.query('select count(*)::int as c from public.mod_grabbing_jerome_domains_url_ready_transfert where domain=$1', [domain]);
      const total = Number(c.rows?.[0]?.c || 0);
      const { rows } = await p.query(
        `select id, url, prepared_at, status, title, page_type, id_product, meta
           from public.mod_grabbing_jerome_domains_url_ready_transfert
          where domain=$1
          order by prepared_at desc nulls last, id desc
          limit $2 offset $3`,
        [domain, limit, offset]
      );
      return res.json({ ok:true, domain, total, items: rows });
    } catch (e) { return res.status(500).json({ ok:false, error:'list_failed', message: e?.message || String(e) }); }
  });

  // Stored prepared record (for View JSON)
  add('get', '/api/grabbing/jerome/domains/url/ready', '/api/grabbings/jerome/domains/url/ready', async (req, res) => {
    try {
      const domain = normDomain(req.query?.domain);
      const rawUrl = String(req.query?.url || '').trim();
      if (!domain || !rawUrl) return res.status(400).json({ ok:false, error:'bad_request', message:'domain and url required' });
      const p = await getPg();
      const q = await p.query(
        `select id, url, prepared_at, status, title, page_type, id_product, meta, product_raw, mapped, config_transfert_version
           from public.mod_grabbing_jerome_domains_url_ready_transfert
          where domain=$1 and lower(trim(both from url)) = lower(trim(both from $2))
          limit 1`,
        [domain, rawUrl]
      );
      if (!q.rows.length) return res.status(404).json({ ok:false, error:'not_found' });
      return res.json({ ok:true, domain, url: rawUrl, item: q.rows[0] });
    } catch (e) { return res.status(500).json({ ok:false, error:'fetch_failed', message: e?.message || String(e) }); }
  });

  // Update status/notes/id_product on prepared record
  add('post', '/api/grabbing/jerome/domains/url/ready/status', '/api/grabbings/jerome/domains/url/ready/status', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const domain = normDomain(req.body?.domain);
      const rawUrl = String(req.body?.url || '').trim();
      const status = String(req.body?.status || '').trim();
      const notes = (req.body?.notes == null ? null : String(req.body?.notes));
      const idProduct = req.body?.id_product != null ? Number(req.body.id_product) : null;
      if (!domain || !rawUrl || !status) return res.status(400).json({ ok:false, error:'bad_request', message:'domain, url and status required' });
      const p = await getPg();
      let sql = `update public.mod_grabbing_jerome_domains_url_ready_transfert set status=$3, notes=$4, prepared_at=now()`;
      const params = [domain, rawUrl, status, notes];
      if (idProduct != null && !Number.isNaN(idProduct)) { sql += `, id_product = $5`; params.push(idProduct); }
      sql += ` where domain=$1 and lower(trim(both from url)) = lower(trim(both from $2)) returning id, id_product`;
      const q = await p.query(sql, params);
      if (!q.rows.length) return res.status(404).json({ ok:false, error:'not_found' });
      return res.json({ ok:true, updated: q.rows[0].id, id_product: q.rows[0].id_product || idProduct || null });
    } catch (e) { return res.status(500).json({ ok:false, error:'status_update_failed', message: e?.message || String(e) }); }
  });


  // Transfer config (get/save/history/revert)
  add('get', '/api/grabbing/jerome/domains/config-transfert', '/api/grabbings/jerome/domains/config-transfert', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const domain = normDomain(req.query?.domain);
      const type = String(req.query?.type||'product').trim().toLowerCase() || 'product';
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      const p = await getPg();
      const r = await p.query('select config_transfert from mod_grabbing_jerome_domains where domain=$1 limit 1', [domain]);
      const all = r.rows?.[0]?.config_transfert || {};
      const cfg = (all && typeof all === 'object') ? (all[type] || {}) : {};
      let version = null;
      try { const vr = await p.query('select max(version) as v from mod_grabbing_jerome_domain_config_transfert_history where domain=$1 and type=$2', [domain, type]); version = Number(vr.rows?.[0]?.v ?? '') || null; } catch {}
      return res.json({ ok:true, domain, type, config: cfg, version });
    } catch (e) { return res.status(500).json({ ok:false, error:'config_transfert_failed', message: e?.message || String(e) }); }
  });

  add('post', '/api/grabbing/jerome/domains/config-transfert', '/api/grabbings/jerome/domains/config-transfert', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const domain = normDomain(req.body?.domain);
      const type = String(req.body?.type||'product').trim().toLowerCase() || 'product';
      const config = (req.body && typeof req.body.config === 'object') ? req.body.config : {};
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      const p = await getPg();
      let current = {};
      try { const r = await p.query('select config_transfert from mod_grabbing_jerome_domains where domain=$1 limit 1', [domain]); current = r.rows?.[0]?.config_transfert || {}; } catch {}
      const nextAll = { ...(current || {}) }; nextAll[type] = config || {};
      await p.query(
        `insert into mod_grabbing_jerome_domains(domain, config_transfert, updated_at)
         values($1,$2::jsonb, now())
         on conflict (domain) do update set config_transfert = EXCLUDED.config_transfert, updated_at = now()`,
        [domain, JSON.stringify(nextAll)]
      );
      let nextVer = 1; try { const vr = await p.query('select coalesce(max(version),0)+1 as v from mod_grabbing_jerome_domain_config_transfert_history where domain=$1 and type=$2', [domain, type]); nextVer = Number(vr.rows?.[0]?.v || 1); } catch {}
      await p.query('insert into mod_grabbing_jerome_domain_config_transfert_history(domain, type, config, version) values($1,$2,$3::jsonb,$4)', [domain, type, JSON.stringify(config), nextVer]);
      return res.json({ ok:true, domain, type, saved: true, version: nextVer });
    } catch (e) { return res.status(500).json({ ok:false, error:'config_transfert_failed', message: e?.message || String(e) }); }
  });

  add('get', '/api/grabbing/jerome/domains/config-transfert/history', '/api/grabbings/jerome/domains/config-transfert/history', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const domain = normDomain(req.query?.domain);
      const type = String(req.query?.type||'product').trim().toLowerCase() || 'product';
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      const p = await getPg();
      const { rows } = await p.query('select id, saved_at, config, version from mod_grabbing_jerome_domain_config_transfert_history where domain=$1 and type=$2 order by saved_at desc limit 50', [domain, type]);
      return res.json({ ok:true, domain, type, items: rows });
    } catch (e) { return res.status(500).json({ ok:false, error:'history_failed', message: e?.message || String(e) }); }
  });

  add('post', '/api/grabbing/jerome/domains/config-transfert/revert', '/api/grabbings/jerome/domains/config-transfert/revert', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const domain = normDomain(req.body?.domain);
      const type = String(req.body?.type||'product').trim().toLowerCase() || 'product';
      const id = Number(req.body?.id||0);
      if (!domain || !id) return res.status(400).json({ ok:false, error:'bad_request', message:'domain and id required' });
      const p = await getPg();
      const one = await p.query('select config from mod_grabbing_jerome_domain_config_transfert_history where id=$1 and domain=$2 and type=$3 limit 1', [id, domain, type]);
      if (!one.rows.length) return res.status(404).json({ ok:false, error:'not_found' });
      const config = one.rows[0].config || {};
      let current = {}; try { const r = await p.query('select config_transfert from mod_grabbing_jerome_domains where domain=$1 limit 1', [domain]); current = r.rows?.[0]?.config_transfert || {}; } catch {}
      const nextAll = { ...(current || {}) }; nextAll[type] = config || {};
      await p.query(
        `insert into mod_grabbing_jerome_domains(domain, config_transfert, updated_at)
         values($1,$2::jsonb, now())
         on conflict (domain) do update set config_transfert = EXCLUDED.config_transfert, updated_at = now()`,
        [domain, JSON.stringify(nextAll)]
      );
      let nextVer = 1; try { const vr = await p.query('select coalesce(max(version),0)+1 as v from mod_grabbing_jerome_domain_config_transfert_history where domain=$1 and type=$2', [domain, type]); nextVer = Number(vr.rows?.[0]?.v || 1); } catch {}
      await p.query('insert into mod_grabbing_jerome_domain_config_transfert_history(domain, type, config, version) values($1, $2, $3::jsonb, $4)', [domain, type, JSON.stringify(config), nextVer]);
      return res.json({ ok:true, domain, type, id, reverted: true, version: nextVer });
    } catch (e) { return res.status(500).json({ ok:false, error:'revert_failed', message: e?.message || String(e) }); }
  });

  add('delete', '/api/grabbing/jerome/domains/config-transfert/history/:id', '/api/grabbings/jerome/domains/config-transfert/history/:id', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { const id = Number(req.params.id || 0); if (!id) return res.status(400).json({ ok:false, error:'bad_request', message:'id required' }); const p = await getPg(); await p.query('delete from mod_grabbing_jerome_domain_config_transfert_history where id=$1', [id]); return res.json({ ok:true, id }); }
    catch (e) { return res.status(500).json({ ok:false, error:'delete_failed', message: e?.message || String(e) }); }
  });

  // List available domains from module table (for Domain Config Maker)
  // GET /api/grabbing/jerome/domains?q=term&limit=200
  add('get', '/api/grabbing/jerome/domains', '/api/grabbings/jerome/domains', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const p = await getPg();
      const q = String(req.query?.q || '').trim().toLowerCase();
      const limit = Math.min(1000, Math.max(1, Number(req.query?.limit || 200)));
      const where = [];
      const params = [];
      let idx = 1;
      if (q) { where.push(`(lower(domain) like $${idx} or lower(coalesce(sitemap_url,'')) like $${idx})`); params.push(`%${q}%`); idx++; }
      const sql = `select domain, sitemap_url, sitemaps, selected_sitemaps, sitemap_total_urls, config, config_transfert, created_at, updated_at
                   from mod_grabbing_jerome_domains
                   ${where.length ? 'where '+where.join(' and '): ''}
                   order by updated_at desc nulls last, domain asc
                   limit $${idx}`;
      params.push(limit);
      const { rows } = await p.query(sql, params);
      return res.json({ ok:true, items: rows });
    } catch (e) { return res.status(500).json({ ok:false, error:'list_failed', message: e?.message || String(e) }); }
  });

  // Create/Add a domain (idempotent upsert)
  // POST /api/grabbing/jerome/domains { domain, sitemap_url? }
  add('post', '/api/grabbing/jerome/domains', '/api/grabbings/jerome/domains', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const raw = String(req.body?.domain || '').trim();
      const domain = normDomain(raw);
      const sitemap_url = String(req.body?.sitemap_url || '').trim() || null;
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      const p = await getPg();
      const { rows } = await p.query(
        `insert into mod_grabbing_jerome_domains(domain, sitemap_url, updated_at)
         values($1, $2, now())
         on conflict (domain)
         do update set sitemap_url = coalesce(EXCLUDED.sitemap_url, mod_grabbing_jerome_domains.sitemap_url), updated_at = now()
         returning domain, sitemap_url, sitemaps, selected_sitemaps, sitemap_total_urls, config, config_transfert, created_at, updated_at`,
        [domain, sitemap_url]
      );
      return res.json({ ok:true, item: rows[0] });
    } catch (e) { return res.status(500).json({ ok:false, error:'create_failed', message: e?.message || String(e) }); }
  });

  // Delete a domain entry
  // DELETE /api/grabbing/jerome/domains/:domain
  add('delete', '/api/grabbing/jerome/domains/:domain', '/api/grabbings/jerome/domains/:domain', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const param = String(req.params?.domain || '').trim();
      const domain = normDomain(param);
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      const p = await getPg();
      const r = await p.query('delete from mod_grabbing_jerome_domains where domain=$1', [domain]);
      if (!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' });
      return res.json({ ok:true, domain, deleted: true });
    } catch (e) { return res.status(500).json({ ok:false, error:'delete_failed', message: e?.message || String(e) }); }
  });

  // Latest extracted JSON files (filesystem, same pattern as legacy server)
  add('get', '/api/grabbing/jerome/latest', '/api/grabbings/jerome/latest', async (_req, res) => {
    try {
      if (!fs.existsSync(jeromeDir)) return res.json({ ok:true, items: [] });
      const items = fs.readdirSync(jeromeDir, { withFileTypes: true })
        .filter(d => d.isFile() && /\.(json|ndjson)$/i.test(d.name))
        .map(d => {
          const p = path.join(jeromeDir, d.name);
          const st = fs.statSync(p);
          return { name: d.name, size: st.size, mtime: st.mtime, download_url: `/api/grabbings/jerome/file/${encodeURIComponent(d.name)}` };
        })
        .sort((a,b)=> b.mtime - a.mtime)
        .slice(0, 50);
      return res.json({ ok:true, items });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Discover aliases (port of legacy helpers)
  // GET /api/grabbings/jerome/discover/latest -> same as latest
  add('get', '/api/grabbing/jerome/discover/latest', '/api/grabbings/jerome/discover/latest', async (_req, res) => {
    try {
      if (!fs.existsSync(jeromeDir)) return res.json({ ok:true, items: [] });
      const items = fs.readdirSync(jeromeDir, { withFileTypes: true })
        .filter(d => d.isFile() && /\.(json|ndjson)$/i.test(d.name))
        .map(d => { const p = path.join(jeromeDir, d.name); const st = fs.statSync(p); return { name: d.name, size: st.size, mtime: st.mtime, download_url: `/api/grabbings/jerome/file/${encodeURIComponent(d.name)}` }; })
        .sort((a,b)=> new Date(b.mtime) - new Date(a.mtime))
        .slice(0, 50);
      return res.json({ ok:true, items });
    } catch (e) { return res.status(500).json({ ok:false, error:'list_failed', message: e?.message || String(e) }); }
  });

  // GET /api/grabbings/jerome/discover/export/:name -> send file by name from jeromeDir
  add('get', '/api/grabbing/jerome/discover/export/:name', '/api/grabbings/jerome/discover/export/:name', (req, res) => {
    try {
      const name = String(req.params?.name || '').trim();
      const full = path.join(jeromeDir, name);
      if (!name || !fs.existsSync(full) || !fs.statSync(full).isFile()) return res.status(404).json({ ok:false, error:'not_found' });
      res.sendFile(full);
    } catch (e) { return res.status(500).json({ ok:false, error:'file_failed', message: e?.message || String(e) }); }
  });

  // GET /api/grabbings/jerome/discover/stats -> rough counts from DB
  add('get', '/api/grabbing/jerome/discover/stats', '/api/grabbings/jerome/discover/stats', async (_req, res) => {
    try {
      const p = await getPg();
      const q1 = await p.query('select count(*)::int as c from mod_grabbing_jerome_domains');
      const q2 = await p.query('select count(*)::int as c from mod_grabbing_jerome_domains_url');
      const q3 = await p.query('select count(*)::int as c from mod_grabbing_jerome_domains_url_page_explore');
      return res.json({ ok:true, totals: { domains: Number(q1.rows?.[0]?.c||0), urls: Number(q2.rows?.[0]?.c||0), explores: Number(q3.rows?.[0]?.c||0) } });
    } catch (e) { return res.status(500).json({ ok:false, error:'stats_failed', message: e?.message || String(e) }); }
  });

  // GET /api/grabbings/jerome/discover/domain/:domain -> list recent explore snapshots for a domain
  add('get', '/api/grabbing/jerome/discover/domain/:domain', '/api/grabbings/jerome/discover/domain/:domain', async (req, res) => {
    try {
      const domain = normDomain(req.params?.domain);
      if (!domain) return res.status(400).json({ ok:false, error:'bad_request', message:'domain required' });
      const p = await getPg();
      const { rows } = await p.query('select url, page_type, explored_at from mod_grabbing_jerome_domains_url_page_explore where domain=$1 order by explored_at desc limit 50', [domain]);
      return res.json({ ok:true, domain, items: rows });
    } catch (e) { return res.status(500).json({ ok:false, error:'domain_failed', message: e?.message || String(e) }); }
  });

  // Serve extracted JSON file
  add('get', '/api/grabbing/jerome/file/:name', '/api/grabbings/jerome/file/:name', (req, res) => {
    try {
      const name = String(req.params.name||'').replace(/[^A-Za-z0-9._\-]/g,'');
      if (!name) return res.status(400).json({ ok:false, error:'bad_request' });
      const p = path.join(jeromeDir, name);
      if (!fs.existsSync(p)) return res.status(404).json({ ok:false, error:'not_found' });
      const dl = /^(1|true|yes)$/i.test(String(req.query?.download||''));
      res.setHeader('Content-Type', 'application/json');
      if (dl) res.setHeader('Content-Disposition', `attachment; filename="${name}"`);
      fs.createReadStream(p).pipe(res);
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
}
