import { registerTmpAdminRoutes } from './routes/admin.routes.js';

export function register(app, ctx) {
  registerTmpAdminRoutes(app, ctx);
}

