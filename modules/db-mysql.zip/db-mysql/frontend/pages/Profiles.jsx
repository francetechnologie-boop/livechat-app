import React, { useEffect, useState } from 'react';

async function api(path, opts = {}) {
  const res = await fetch(path, { headers: { 'Content-Type': 'application/json', ...(opts.headers||{}) }, ...opts });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(json?.message || res.statusText);
  return json;
}

export default function DbMysqlProfilesPage() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState('');
  const [form, setForm] = useState({ name:'', host:'', port:3306, database:'', db_user:'', db_password:'', ssl:false, is_default:false });
  const [editId, setEditId] = useState(null);
  const [orgId, setOrgId] = useState('');

  async function load() {
    setLoading(true); setErr('');
    try {
      const q = orgId ? `?org_id=${encodeURIComponent(orgId)}` : '';
      const r = await api(`/api/db-mysql/profiles${q}`);
      setItems(r.items || []);
    } catch (e) { setErr(String(e.message||e)); } finally { setLoading(false); }
  }
  useEffect(() => { load(); }, [orgId]);

  async function onCreate(e) {
    e.preventDefault(); setErr(''); setLoading(true);
    try {
      const body = { ...form }; if (orgId) body.org_id = orgId;
      if (editId) {
        const q = orgId ? `?org_id=${encodeURIComponent(orgId)}` : '';
        await api(`/api/db-mysql/profiles/${editId}${q}`, { method:'PUT', body: JSON.stringify(body) });
      } else {
        await api('/api/db-mysql/profiles', { method:'POST', body: JSON.stringify(body) });
      }
      setEditId(null);
      setForm({ name:'', host:'', port:3306, database:'', db_user:'', db_password:'', ssl:false, is_default:false });
      await load();
    } catch (e) { setErr(String(e.message||e)); } finally { setLoading(false); }
  }

  async function onDelete(id) {
    if (!window.confirm('Delete profile #' + id + '?')) return;
    setLoading(true); setErr('');
    try {
      const q = orgId ? `?org_id=${encodeURIComponent(orgId)}` : '';
      await api(`/api/db-mysql/profiles/${id}${q}`, { method:'DELETE' });
      await load();
    } catch (e) { setErr(String(e.message||e)); } finally { setLoading(false); }
  }

  async function onTest(id) {
    setLoading(true); setErr('');
    try {
      const q = orgId ? `?org_id=${encodeURIComponent(orgId)}` : '';
      const r = await api(`/api/db-mysql/test${q}`, { method:'POST', body: JSON.stringify({ profile_id: id }) });
      alert('Test: ' + JSON.stringify(r));
    } catch (e) { setErr(String(e.message||e)); } finally { setLoading(false); }
  }

  function onEdit(it) {
    setErr('');
    setEditId(it.id);
    setForm({
      name: it.name || '',
      host: it.host || '',
      port: Number(it.port || 3306),
      database: it.database || '',
      db_user: it.db_user || '',
      db_password: '', // leave empty unless user wants to change
      ssl: !!it.ssl,
      is_default: !!it.is_default,
    });
  }

  function onCancelEdit() {
    setEditId(null);
    setForm({ name:'', host:'', port:3306, database:'', db_user:'', db_password:'', ssl:false, is_default:false });
  }

  return (
    <div style={{ padding: 16 }}>
      <h2>DB MySQL Profiles</h2>
      <div style={{ marginBottom: 12 }}>
        <label>Org ID: <input value={orgId} onChange={e=>setOrgId(e.target.value)} placeholder="optional" /></label>
        <button onClick={load} disabled={loading} style={{ marginLeft: 8 }}>Reload</button>
      </div>
      {err ? <div style={{ color:'red' }}>{err}</div> : null}
      <form onSubmit={onCreate} style={{ border:'1px solid #ccc', padding: 12, marginBottom: 16 }}>
        <h3>{editId ? `Edit Profile #${editId}` : 'Create Profile'}</h3>
        <div>
          <input placeholder="Name" value={form.name} onChange={e=>setForm({ ...form, name:e.target.value })} required />
          <input placeholder="Host" value={form.host} onChange={e=>setForm({ ...form, host:e.target.value })} required style={{ marginLeft: 8 }} />
          <input placeholder="Port" type="number" value={form.port} onChange={e=>setForm({ ...form, port:Number(e.target.value||3306) })} style={{ width: 90, marginLeft: 8 }} />
        </div>
        <div style={{ marginTop: 8 }}>
          <input placeholder="Database" value={form.database} onChange={e=>setForm({ ...form, database:e.target.value })} required />
          <input placeholder="DB User" value={form.db_user} onChange={e=>setForm({ ...form, db_user:e.target.value })} required style={{ marginLeft: 8 }} />
          <input placeholder="DB Password" value={form.db_password} onChange={e=>setForm({ ...form, db_password:e.target.value })} style={{ marginLeft: 8 }} />
        </div>
        <div style={{ marginTop: 8 }}>
          <label><input type="checkbox" checked={form.ssl} onChange={e=>setForm({ ...form, ssl:e.target.checked })} /> SSL</label>
          <label style={{ marginLeft: 12 }}><input type="checkbox" checked={form.is_default} onChange={e=>setForm({ ...form, is_default:e.target.checked })} /> Default</label>
          <button type="submit" disabled={loading} style={{ marginLeft: 12 }}>{editId ? 'Save Changes' : 'Create'}</button>
          {editId ? <button type="button" onClick={onCancelEdit} disabled={loading} style={{ marginLeft: 8 }}>Cancel</button> : null}
        </div>
      </form>
      <table border="1" cellPadding="6" style={{ borderCollapse:'collapse', width:'100%' }}>
        <thead>
          <tr>
            <th>ID</th><th>Name</th><th>Host</th><th>Port</th><th>Database</th><th>User</th><th>SSL</th><th>Default</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {(items||[]).map(it => (
            <tr key={it.id}>
              <td>{it.id}</td>
              <td>{it.name}</td>
              <td>{it.host}</td>
              <td>{it.port}</td>
              <td>{it.database}</td>
              <td>{it.db_user}</td>
              <td>{String(it.ssl)}</td>
              <td>{String(it.is_default)}</td>
              <td>
                <button onClick={()=>onTest(it.id)} disabled={loading}>Test</button>
                <button onClick={()=>onEdit(it)} disabled={loading} style={{ marginLeft: 8 }}>Edit</button>
                <button onClick={()=>onDelete(it.id)} disabled={loading} style={{ marginLeft: 8 }}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
