import { registerTmpMcpDevRoutes } from './routes/mcp-dev.routes.js';

export function register(app, ctx) {
  registerTmpMcpDevRoutes(app, ctx);
}

