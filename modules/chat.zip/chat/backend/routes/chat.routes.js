export function registerChatRoutes(app, ctx = {}) {
  app.get('/api/chat/ping', (_req, res) => res.json({ ok: true, module: 'chat' }));
}

