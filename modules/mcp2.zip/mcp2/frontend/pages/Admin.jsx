import React, { useEffect, useMemo, useState } from "react";

function Section({ title, right, children }) {
  return (
    <div className="bg-white rounded border">
      <div className="px-3 py-2 border-b flex items-center justify-between">
        <div className="font-medium text-sm">{title}</div>
        {right}
      </div>
      <div className="p-3">{children}</div>
    </div>
  );
}

function TextInput({ label, value, onChange, placeholder, type = "text" }) {
  return (
    <label className="block text-sm">
      <span className="text-gray-600 text-xs">{label}</span>
      <input
        className="mt-1 w-full border rounded px-3 py-2"
        value={value}
        onChange={(e) => onChange(type === 'number' ? Number(e.target.value) : e.target.value)}
        placeholder={placeholder || ""}
        type={type}
      />
    </label>
  );
}

function Select({ label, value, onChange, options, placeholder }) {
  return (
    <label className="block text-sm">
      <span className="text-gray-600 text-xs">{label}</span>
      <select
        className="mt-1 w-full border rounded px-3 py-2 bg-white"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      >
        <option value="">{placeholder || "Select"}</option>
        {(options || []).map((opt) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
    </label>
  );
}

function SmallButton({ children, onClick, kind = "secondary", disabled }) {
  const base = "text-xs px-2 py-1 rounded border";
  const styles = kind === 'primary'
    ? " bg-blue-600 text-white border-blue-600 hover:bg-blue-700"
    : kind === 'danger'
      ? " text-red-700 border-red-300 hover:bg-red-50"
      : " text-gray-700 border-gray-300 hover:bg-gray-50";
  return (
    <button disabled={disabled} className={`${base}${styles} disabled:opacity-60`} onClick={onClick}>{children}</button>
  );
}

export default function Mcp2Admin() {
  const [tab, setTab] = useState('servers'); // 'kinds' | 'types' | 'servers'
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [kinds, setKinds] = useState([]);
  const [types, setTypes] = useState([]);
  const [servers, setServers] = useState([]);
  // Modules that expose MCP tools (for Origin Module selector)
  const [modChoices, setModChoices] = useState([]);
  const originOpts = useMemo(() => (Array.isArray(modChoices) ? modChoices : []).map(m => ({ value: m.id, label: m.name || m.id })), [modChoices]);
  const kindOpts = useMemo(() => (Array.isArray(kinds) ? kinds : []).map(k => ({ value: k.id, label: k.name || k.code || k.id })), [kinds]);
  const [statuses, setStatuses] = useState({}); // id -> { ok, method, ms }
  const [statusMeta, setStatusMeta] = useState({ mounted:false, moduleLoaded:false, node:'' });
  // Process status for the currently edited server
  const [procStatus, setProcStatus] = useState(null);
  // Process config form (stored under server.options)
  const [procForm, setProcForm] = useState({ command:'', args:'', cwd:'', env:'', upstream_mcp_url:'' });

  const load = async () => {
    setLoading(true); setError("");
    try {
      const [rk, rt, rs, rm] = await Promise.all([
        fetch('/api/mcp2/kinds', { credentials: 'include' }),
        fetch('/api/mcp2/types', { credentials: 'include' }),
        fetch('/api/mcp2/servers', { credentials: 'include' }),
        fetch('/api/mcp2/modules', { credentials: 'include' }),
      ]);
      const jk = await rk.json().catch(()=>({}));
      const jt = await rt.json().catch(()=>({}));
      const js = await rs.json().catch(()=>({}));
      setKinds(Array.isArray(jk?.items) ? jk.items : []);
      setTypes(Array.isArray(jt?.items) ? jt.items : []);
      setServers(Array.isArray(js?.items) ? js.items : []);
      try {
        const jmods = await rm.json().catch(()=>({}));
        setModChoices(Array.isArray(jmods?.items) ? jmods.items : []);
      } catch {}
      try {
        const rs2 = await fetch('/api/mcp2/servers/status', { credentials: 'include' });
        const j2 = await rs2.json().catch(()=>({}));
        if (rs2.ok && j2?.ok) {
          if (Array.isArray(j2.items)) { const m = {}; for (const it of j2.items) m[String(it.id)] = it; setStatuses(m); } else setStatuses({});
          setStatusMeta({ mounted: !!j2.mounted, moduleLoaded: !!j2.moduleLoaded, node: j2.node || '' });
        } else { setStatuses({}); setStatusMeta({ mounted:false, moduleLoaded:false, node:'' }); }
      } catch { setStatuses({}); setStatusMeta({ mounted:false, moduleLoaded:false, node:'' }); }
    } catch (e) { setError(String(e?.message || e)); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);
  // When editing a server, poll its process status
  useEffect(() => {
    let t;
    const fetchOnce = async () => {
      if (!editServerId) { setProcStatus(null); return; }
      try {
        const r = await fetch(`/api/mcp2/servers/${encodeURIComponent(editServerId)}/process`, { credentials:'include' });
        const j = await r.json().catch(()=>({}));
        if (r.ok && j?.ok) setProcStatus(j.status || {}); else setProcStatus(null);
      } catch { setProcStatus(null); }
    };
    fetchOnce();
    if (editServerId) t = setInterval(fetchOnce, 3000);
    return () => { if (t) clearInterval(t); };
  }, [editServerId]);
  // Periodically refresh server statuses
  useEffect(() => {
    const t = setInterval(async () => {
      try {
        const rs2 = await fetch('/api/mcp2/servers/status', { credentials: 'include' });
        const j2 = await rs2.json().catch(()=>({}));
        if (rs2.ok && j2?.ok && Array.isArray(j2.items)) {
          const m = {}; for (const it of j2.items) m[String(it.id)] = it; setStatuses(m);
        }
        if (rs2.ok && j2?.ok) {
          setStatusMeta({ mounted: !!j2.mounted, moduleLoaded: !!j2.moduleLoaded, node: j2.node || '' });
        }
      } catch {}
    }, 10000);
    return () => clearInterval(t);
  }, []);

  // Kinds form
  const [kindForm, setKindForm] = useState({ code: '', name: '', description: '' });
  const addKind = async () => {
    try {
      const r = await fetch('/api/mcp2/kinds', { method:'POST', headers:{'Content-Type':'application/json'}, credentials:'include', body: JSON.stringify(kindForm) });
      const j = await r.json().catch(()=>({}));
      if (!r.ok || j?.ok === false) throw new Error(j?.message || j?.error || 'create_failed');
      setKindForm({ code:'', name:'', description:'' });
      await load();
    } catch (e) { alert(String(e?.message || e)); }
  };
  const deleteKind = async (id) => {
    if (!id) return; if (!confirm('Delete kind?')) return;
    try { await fetch(`/api/mcp2/kinds/${encodeURIComponent(id)}`, { method:'DELETE', credentials:'include' }); await load(); } catch {}
  };

  // Types form
  const [typeForm, setTypeForm] = useState({ code: '', name: '', description: '' });
  const addType = async () => {
    try {
      const r = await fetch('/api/mcp2/types', { method:'POST', headers:{'Content-Type':'application/json'}, credentials:'include', body: JSON.stringify(typeForm) });
      const j = await r.json().catch(()=>({}));
      if (!r.ok || j?.ok === false) throw new Error(j?.message || j?.error || 'create_failed');
      setTypeForm({ code:'', name:'', description:'' });
      await load();
    } catch (e) { alert(String(e?.message || e)); }
  };
  const deleteType = async (id) => {
    if (!id) return; if (!confirm('Delete type?')) return;
    try { await fetch(`/api/mcp2/types/${encodeURIComponent(id)}`, { method:'DELETE', credentials:'include' }); await load(); } catch {}
  };

  // Servers form
  const [editServerId, setEditServerId] = useState(null);
  const editing = useMemo(() => (servers || []).find(s => s && s.id === editServerId) || null, [servers, editServerId]);
  const DEFAULT_HTTP_BASE = 'https://chat.piscinesondespro.fr/';
  const [serverForm, setServerForm] = useState({ name:'', kind_id:'', origin_module:'', http_base: DEFAULT_HTTP_BASE, ws_url:'', stream_url:'', sse_url:'', token:'', require_token:true, enabled:false, notes:'', server_url_pref:'stream' });
  // Per-server tools view
  const [serverTools, setServerTools] = useState([]);
  const [serverToolsLoading, setServerToolsLoading] = useState(false);
  const loadServerTools = async (id) => {
    if (!id) { setServerTools([]); return; }
    setServerToolsLoading(true);
    try {
      const r = await fetch(`/api/mcp2/servers/${encodeURIComponent(id)}/tools`, { credentials: 'include' });
      const j = await r.json().catch(()=>({}));
      if (!r.ok || j?.ok===false) throw new Error(j?.message || j?.error || 'load_failed');
      setServerTools(Array.isArray(j.items) ? j.items : []);
    } catch { setServerTools([]); }
    finally { setServerToolsLoading(false); }
  };
  const urlEncode = (s='') => encodeURIComponent(String(s));
  const trimBase = (b='') => String(b||'').replace(/\/+$/,'');
  const computeDerivedUrls = (base, name) => {
    const safeBase = trimBase(base || DEFAULT_HTTP_BASE);
    const safeName = urlEncode(name || '');
    const host = safeBase.replace(/^https?:\/\//i, '');
    const wsScheme = /^https:\/\//i.test(safeBase) ? 'wss://' : 'ws://';
    return {
      ws_url: wsScheme + host + '/mcp2/' + safeName + '/ws',
      stream_url: safeBase + '/api/mcp2/' + safeName + '/stream',
      sse_url: safeBase + '/api/mcp2/' + safeName + '/events',
    };
  };

  // Auto-fill URLs when Name or HTTP Base changes (runs after helpers are defined)
  useEffect(() => {
    try {
      const derived = computeDerivedUrls(serverForm.http_base, serverForm.name);
      if (derived.ws_url !== serverForm.ws_url || derived.stream_url !== serverForm.stream_url || derived.sse_url !== serverForm.sse_url) {
        setServerForm(f => ({ ...f, ...derived }));
      }
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [serverForm.name, serverForm.http_base]);
  const regenerateToken = () => {
    try {
      const arr = new Uint8Array(32);
      (window.crypto || window.msCrypto).getRandomValues(arr);
      const hex = Array.from(arr).map(b=>b.toString(16).padStart(2,'0')).join('');
      setServerForm(f => ({ ...f, token: hex }));
    } catch {
      const hex = Array.from({length:64},()=>Math.floor(Math.random()*16).toString(16)).join('');
      setServerForm(f => ({ ...f, token: hex }));
    }
  };
  const beginNew = () => { setEditServerId(null); setServerForm({ name:'', kind_id:'', origin_module:'', http_base: DEFAULT_HTTP_BASE, ws_url:'', stream_url:'', sse_url:'', token:'', require_token:true, enabled:false, notes:'', server_url_pref:'stream' }); setProcForm({ command:'', args:'', cwd:'', env:'' }); setProcStatus(null); setServerTools([]); };
  const beginEdit = (it) => {
    setEditServerId(it?.id || null);
    let pref = 'stream';
    try { const opt = typeof it.options === 'string' ? JSON.parse(it.options) : (it.options || {}); if (opt && (opt.server_url_pref === 'sse' || opt.server_url_pref === 'stream')) pref = opt.server_url_pref; } catch {}
    const opt = (()=>{ try { return typeof it?.options==='string'? JSON.parse(it.options): (it?.options||{}); } catch { return {}; } })();
    const require_token = (()=>{ try { const o = typeof it?.options==='string'? JSON.parse(it.options): (it?.options||{}); if (o && typeof o.require_auth==='boolean') return !!o.require_auth; } catch {} return !!(it?.token); })();
    setServerForm({ name: it?.name || '', kind_id: it?.kind_id || '', origin_module: opt.origin_module || '', http_base: it?.http_base || DEFAULT_HTTP_BASE, ws_url: it?.ws_url || '', stream_url: it?.stream_url || '', sse_url: it?.sse_url || '', token: it?.token || '', require_token, enabled: !!it?.enabled, notes: it?.notes || '', server_url_pref: pref });
    // Populate process form from options
    const pf = { command:'', args:'', cwd:'', env:'', upstream_mcp_url:'' };
    try { if (opt && typeof opt.command==='string') pf.command = opt.command; } catch {}
    try { if (Array.isArray(opt?.args)) pf.args = opt.args.join(' '); else if (typeof opt?.args==='string') pf.args = opt.args; } catch {}
    try { if (typeof opt?.cwd==='string') pf.cwd = opt.cwd; } catch {}
    try { if (opt && typeof opt.env==='object') pf.env = JSON.stringify(opt.env); } catch {}
    try { if (typeof opt?.upstream_mcp_url==='string') pf.upstream_mcp_url = opt.upstream_mcp_url; } catch {}
    setProcForm(pf);
    loadServerTools(it?.id || null);
  };
  const parseArgsString = (s) => {
    const v = String(s || '').trim();
    if (!v) return [];
    if (v.startsWith('[')) { try { const arr = JSON.parse(v); return Array.isArray(arr)? arr.map(x=>String(x)) : []; } catch { /* fallthrough */ } }
    // naive split preserving quoted segments
    const re = /\"([^\"]*)\"|'([^']*)'|\S+/g; const out=[]; let m; while((m=re.exec(v))) { out.push(m[1]||m[2]||m[0]); } return out;
  };
  const parseEnvString = (s) => {
    const v = String(s || '').trim();
    if (!v) return {};
    try { const o = JSON.parse(v); if (o && typeof o==='object' && !Array.isArray(o)) return o; } catch {}
    // support KEY=VAL lines
    const obj = {}; v.split(/\s+/).forEach(p=>{ const i=p.indexOf('='); if (i>0) obj[p.slice(0,i)] = p.slice(i+1); }); return obj;
  };
  const saveServer = async () => {
    try {
      const derived = computeDerivedUrls(serverForm.http_base, serverForm.name);
      const tokenOut = serverForm.require_token ? (serverForm.token || '') : '';
      const options = { server_url_pref: serverForm.server_url_pref || 'stream', origin_module: serverForm.origin_module || '', require_auth: !!serverForm.require_token };
      // attach process config if provided
      if (procForm.command && procForm.command.trim()) options.command = procForm.command.trim();
      const argsArr = parseArgsString(procForm.args);
      if (argsArr && argsArr.length) options.args = argsArr;
      if (procForm.cwd && procForm.cwd.trim()) options.cwd = procForm.cwd.trim();
      const envObj = parseEnvString(procForm.env);
      if (envObj && Object.keys(envObj).length) options.env = envObj;
      if (procForm.upstream_mcp_url && procForm.upstream_mcp_url.trim()) options.upstream_mcp_url = procForm.upstream_mcp_url.trim();
      const payload = { ...serverForm, ...derived, token: tokenOut, options };
      if (!editServerId) {
        const r = await fetch('/api/mcp2/servers', { method:'POST', headers:{'Content-Type':'application/json'}, credentials:'include', body: JSON.stringify(payload) });
        const j = await r.json().catch(()=>({}));
        if (!r.ok || j?.ok === false) throw new Error(j?.message || j?.error || 'create_failed');
      } else {
        const derived = computeDerivedUrls(serverForm.http_base, serverForm.name);
        const tokenOut2 = serverForm.require_token ? (serverForm.token || '') : '';
        const options2 = { ...options };
        const body = { ...serverForm, ...derived, token: tokenOut2, options: options2 };
        const r = await fetch(`/api/mcp2/servers/${encodeURIComponent(editServerId)}`, { method:'PATCH', headers:{'Content-Type':'application/json'}, credentials:'include', body: JSON.stringify(body) });
        const j = await r.json().catch(()=>({}));
        if (!r.ok || j?.ok === false) throw new Error(j?.message || j?.error || 'update_failed');
      }
      await load(); beginNew();
    } catch (e) { alert(String(e?.message || e)); }
  };
  const deleteServer = async (id) => {
    if (!id) return; if (!confirm('Delete server?')) return;
    try { await fetch(`/api/mcp2/servers/${encodeURIComponent(id)}`, { method:'DELETE', credentials:'include' }); await load(); } catch {}
  };
  const testServer = async (id) => {
    try {
      let r, j;
      if (id) {
        r = await fetch(`/api/mcp2/servers/${encodeURIComponent(id)}/status`, { credentials:'include' });
        j = await r.json().catch(()=>({}));
      } else {
        const derived = computeDerivedUrls(serverForm.http_base, serverForm.name);
        const payload = { http_base: serverForm.http_base, stream_url: derived.stream_url, sse_url: derived.sse_url, token: serverForm.token, options: { server_url_pref: serverForm.server_url_pref || 'stream' } };
        r = await fetch('/api/mcp2/servers/test', { method:'POST', headers:{'Content-Type':'application/json'}, credentials:'include', body: JSON.stringify(payload) });
        j = await r.json().catch(()=>({}));
      }
      if (r.ok && j?.ok) {
        const st = j.status || {};
        alert(st.ok ? `OK (${st.method||''}) in ${st.ms||'?'}ms` : `Failed: ${st.error || st.status || 'unreachable'}`);
      } else alert(j?.error || 'test_failed');
    } catch (e) { alert(String(e?.message || e)); }
  };

  // (removed duplicates: kindOpts/modChoices/originOpts and serverTools were already declared earlier in file)

  // Breadcrumb: tell shell we are on MCP2 Admin
  useEffect(() => {
    try { window.dispatchEvent(new CustomEvent('app-breadcrumb', { detail: ['MCP2 Admin'] })); } catch {}
  }, []);

  return (
    <div className="w-full px-2 md:px-4">
      <div className="mb-3 flex items-center justify-between">
        <div className="text-lg font-semibold">MCP2 Administration</div>
        <div className="space-x-2">
          <SmallButton onClick={() => setTab('kinds')} kind={tab==='kinds'?'primary':'secondary'}>Kinds</SmallButton>
          <SmallButton onClick={() => setTab('types')} kind={tab==='types'?'primary':'secondary'}>Types</SmallButton>
          <SmallButton onClick={() => setTab('servers')} kind={tab==='servers'?'primary':'secondary'}>Servers</SmallButton>
        </div>
      </div>
      <div className="mb-3 text-xs text-gray-600">
        <span className={statusMeta.mounted? 'text-green-700 font-medium':'text-red-700 font-medium'}>
          Transport Mounted: {statusMeta.mounted? 'Yes':'No'}
        </span>
        <span className="mx-2">|</span>
        <span>Node: <span className="font-mono">{statusMeta.node || 'n/a'}</span></span>
      </div>
      {!statusMeta.mounted && (
        <div className="mb-3 bg-red-50 border border-red-200 text-red-800 px-3 py-2 rounded text-xs">
          <div className="font-medium">MCP2 transport not mounted</div>
          <div className="mt-1">Backend didn’t load /mcp2 stream/events routes. Status checks may show 404/401.</div>
          <div className="mt-1">
            <span className="underline cursor-help" title="Tips: Ensure Apache vhost has ProxyPass for /mcp2/ and a WebSocket Upgrade rule for /mcp2/*/ws. Restart backend with PM2 and verify Node interpreter: 'pm2 restart livechat --update-env' and 'pm2 restart livechat --interpreter $(which node)'. Check PM2 logs for 'backend/index load error' or 'transport.routes.js'.">Troubleshooting tips</span>
            <span className="ml-2 text-gray-700">• Node: <span className="font-mono">{statusMeta.node || 'n/a'}</span></span>
          </div>
        </div>
      )}
      {loading && (<div className="text-sm text-gray-500">Loading…</div>)}
      {error && (<div className="text-sm text-red-600">{error}</div>)}

      {tab === 'kinds' && (
        <div className="grid md:grid-cols-2 gap-3">
          <Section title="Kinds">
            <div className="space-y-2">
              {(kinds || []).map(k => (
                <div key={k.id} className="border rounded p-2 flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm">{k.name || k.code} <span className="text-xs text-gray-500">({k.code})</span></div>
                    {k.description ? (<div className="text-xs text-gray-600">{k.description}</div>) : null}
                  </div>
                  <div className="space-x-2">
                    <SmallButton kind="danger" onClick={() => deleteKind(k.id)}>Delete</SmallButton>
                  </div>
                </div>
              ))}
            </div>
          </Section>
          <Section title="Add Kind">
            <div className="space-y-2">
              <TextInput label="Code" value={kindForm.code} onChange={(v) => setKindForm({ ...kindForm, code: v })} />
              <TextInput label="Name" value={kindForm.name} onChange={(v) => setKindForm({ ...kindForm, name: v })} />
              <TextInput label="Description" value={kindForm.description} onChange={(v) => setKindForm({ ...kindForm, description: v })} />
              <div className="flex justify-end"><SmallButton kind="primary" onClick={addKind}>Create</SmallButton></div>
            </div>
          </Section>
        </div>
      )}

      {tab === 'types' && (
        <div className="grid md:grid-cols-2 gap-3">
          <Section title="Types">
            <div className="space-y-2">
              {(types || []).map(t => (
                <div key={t.id} className="border rounded p-2 flex items-center justify-between">
                  <div>
                    <div className="font-medium text-sm">{t.name || t.code} <span className="text-xs text-gray-500">({t.code})</span></div>
                    {t.description ? (<div className="text-xs text-gray-600">{t.description}</div>) : null}
                  </div>
                  <div className="space-x-2">
                    <SmallButton kind="danger" onClick={() => deleteType(t.id)}>Delete</SmallButton>
                  </div>
                </div>
              ))}
            </div>
          </Section>
          <Section title="Add Type">
            <div className="space-y-2">
              <TextInput label="Code" value={typeForm.code} onChange={(v) => setTypeForm({ ...typeForm, code: v })} />
              <TextInput label="Name" value={typeForm.name} onChange={(v) => setTypeForm({ ...typeForm, name: v })} />
              <TextInput label="Description" value={typeForm.description} onChange={(v) => setTypeForm({ ...typeForm, description: v })} />
              <div className="flex justify-end"><SmallButton kind="primary" onClick={addType}>Create</SmallButton></div>
            </div>
          </Section>
        </div>
      )}

      {tab === 'servers' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
          <div className="lg:col-span-1">
          <Section title="Servers" right={<SmallButton onClick={beginNew}>New</SmallButton>}>
            <div className="space-y-2">
              {(servers || []).map(s => {
                const st = statuses[s.id] || {};
                const online = !!st.ok;
                const kindLabel = (() => { try { const k = (kinds || []).find(kk => kk.id === s.kind_id); return k ? (k.name || k.code || k.id) : '—'; } catch { return '—'; } })();
                return (
                  <div key={s.id} className={`w-full text-left border rounded p-2 ${editServerId===s.id?'border-blue-400 bg-blue-50':''}`}>
                    <div className="flex items-center justify-between gap-2">
                      <button onClick={() => beginEdit(s)} className="font-medium text-sm truncate hover:underline text-left flex-1">
                        {s.name || s.id}
                      </button>
                      
                      <div className={`text-xs inline-flex items-center gap-1 ${online?'text-green-700':'text-gray-600'}`}>
                        <span className={`inline-block w-2 h-2 rounded-full ${online?'bg-green-500':'bg-gray-400'}`}></span>
                        {online ? 'Online' : 'Offline'}
                      </div>
                    </div>
                    <div className="mt-1 space-y-1 text-[11px] text-gray-700">
                      <div><span className="text-gray-500">Origin:</span> {(() => { try { const o = typeof s.options === 'string' ? JSON.parse(s.options) : (s.options||{}); return o.origin_module || o.module || '—'; } catch { return '—'; } })()}</div>
                      <div><span className="text-gray-500">Kind:</span> {kindLabel}</div>
                      <div><span className="text-gray-500">Preferred Server URL:</span> {(() => { try { const o = typeof s.options === 'string' ? JSON.parse(s.options) : (s.options||{}); return o.server_url_pref || 'sse'; } catch { return 'sse'; } })()}</div>
                      <div className="truncate"><span className="text-gray-500">Stream URL:</span> {s.stream_url || `${window.location.origin}/api/mcp2/${encodeURIComponent(s.name||'')}/stream`}</div>
                      <div className="truncate"><span className="text-gray-500">SSE URL:</span> {s.sse_url || `${window.location.origin}/api/mcp2/${encodeURIComponent(s.name||'')}/events`}</div>
                      <div className="truncate"><span className="text-gray-500">Token:</span> <span className="font-mono">{s.token || '—'}</span></div>
                    </div>
                    <div className="mt-1 text-[11px] text-gray-600 truncate">{s.http_base || s.sse_url || s.stream_url || s.ws_url || ''}</div>
                    <div className="mt-0.5 text-[10px] text-gray-500 truncate">
                      Pref: {(() => { try { const o = typeof s.options === 'string' ? JSON.parse(s.options) : (s.options||{}); return o.server_url_pref || 'sse'; } catch { return 'sse'; } })()}
                    </div>
                    <div className="mt-2 flex items-center justify-between gap-2">
                      <div className="text-[11px] text-gray-500">
                        {online ? (<>
                          {st.method || ''}{st.ms!=null?` • ${st.ms}ms`:''}
                        </>) : (
                          <>
                            {st.code ? `HTTP ${st.code}` : 'No response'}{st.error ? ` • ${st.error}` : ''}
                          </>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <SmallButton onClick={() => beginEdit(s)}>Edit</SmallButton>
                        <SmallButton kind="danger" onClick={() => deleteServer(s.id)}>Delete</SmallButton>
                      </div>
                    </div>
                  </div>
                );
              })}
              {(!servers || !servers.length) && (
                <div className="text-xs text-gray-500">No servers yet. Click New to create one.</div>
              )}
            </div>
          </Section>
          </div>
          <div className="lg:col-span-2 space-y-3">
          <Section title={editServerId? 'Edit Server' : 'New Server'}>
            <div className="space-y-2">
              <TextInput label="Name" value={serverForm.name} onChange={(v)=>setServerForm({...serverForm, name:v})} />
              {editServerId && (
                <div className="flex items-center justify-between text-xs text-gray-600">
                  <div>ID: <span className="font-mono">{editServerId}</span></div>
                  <SmallButton onClick={async ()=>{ try { await navigator.clipboard.writeText(editServerId); } catch {} }}>Copy Id</SmallButton>
                </div>
              )}
              {editServerId && (
                <div className="flex items-center justify-between text-xs">
                  <div className="text-gray-700">
                    Proc: {procStatus?.running ?
                      (<span className="text-green-700">running</span>) :
                      (<span className="text-gray-600">stopped</span>)}
                    {procStatus?.pid ? <span> • PID <span className="font-mono">{procStatus.pid}</span></span> : null}
                  </div>
                  <div className="space-x-2">
                    <SmallButton kind="secondary" onClick={async ()=>{
                      try { const r = await fetch(`/api/mcp2/servers/${encodeURIComponent(editServerId)}/start`, { method:'POST', credentials:'include' }); await r.json().catch(()=>({})); } catch {}
                    }}>Start</SmallButton>
                    <SmallButton kind="danger" onClick={async ()=>{
                      try { const r = await fetch(`/api/mcp2/servers/${encodeURIComponent(editServerId)}/stop`, { method:'POST', credentials:'include' }); await r.json().catch(()=>({})); } catch {}
                    }}>Stop</SmallButton>
                  </div>
                </div>
              )}
              <Select label="Kind" value={serverForm.kind_id} onChange={(v)=>setServerForm({...serverForm, kind_id:v})} options={kindOpts} placeholder="Choose a kind" />
              <Select label="Origin Module" value={serverForm.origin_module} onChange={(v)=>setServerForm({...serverForm, origin_module:v})} options={originOpts} placeholder="Choose a module" />
              {(!originOpts || originOpts.length===0) && (
                <div className="text-[11px] text-red-700 bg-red-50 border border-red-200 rounded px-2 py-1">
                  No modules discovered. Ensure a module has "hasMcpTool": true or "mcpTools" in modules/&lt;id&gt;/module.config.json, then reload.
                </div>
              )}
              <TextInput label="HTTP Base" value={serverForm.http_base} onChange={(v)=>setServerForm({...serverForm, http_base:v})} placeholder="https://chat.piscinesondespro.fr/" />
              <TextInput label="WS URL (auto)" value={serverForm.ws_url} onChange={(v)=>setServerForm({...serverForm, ws_url:v})} placeholder="wss://host/mcp2/<name>/ws" />
              <TextInput label="Stream URL (auto)" value={serverForm.stream_url} onChange={(v)=>setServerForm({...serverForm, stream_url:v})} placeholder="https://host/api/mcp2/<name>/stream" />
              <TextInput label="SSE URL (auto)" value={serverForm.sse_url} onChange={(v)=>setServerForm({...serverForm, sse_url:v})} placeholder="https://host/api/mcp2/<name>/events" />
              <div className="flex items-center gap-2">
                <label className="inline-flex items-center text-sm select-none mr-2">
                  <input type="checkbox" className="mr-2" checked={!!serverForm.require_token} onChange={(e)=>setServerForm({...serverForm, require_token: !!e.target.checked})} />
                  Require token
                </label>
                <div className="flex-1"><TextInput label="Token" value={serverForm.token} onChange={(v)=>setServerForm({...serverForm, token:v})} placeholder="Auth token (blank to disable)" /></div>
                <SmallButton onClick={regenerateToken} disabled={!serverForm.require_token}>Regenerate</SmallButton>
              </div>
              <label className="inline-flex items-center text-sm select-none">
                <input type="checkbox" className="mr-2" checked={!!serverForm.enabled} onChange={(e)=>setServerForm({...serverForm, enabled: !!e.target.checked})} />
                Enabled
              </label>
              <TextInput label="Notes" value={serverForm.notes} onChange={(v)=>setServerForm({...serverForm, notes:v})} />
              <Select label="Preferred Server URL" value={serverForm.server_url_pref} onChange={(v)=>setServerForm({...serverForm, server_url_pref:v})} options={[{value:'sse',label:'SSE'},{value:'stream',label:'Stream'}]} />
              <div className="mt-3 p-2 border rounded bg-gray-50">
                <div className="text-xs font-medium text-gray-700 mb-2">Local Process (optional)</div>
                <div className="grid md:grid-cols-2 gap-2">
                  <TextInput label="Command" value={procForm.command} onChange={(v)=>setProcForm({...procForm, command: v})} placeholder="node" />
                  <TextInput label="Args (space or JSON array)" value={procForm.args} onChange={(v)=>setProcForm({...procForm, args: v})} placeholder="/path/server.js --port 8088" />
                  <TextInput label="CWD" value={procForm.cwd} onChange={(v)=>setProcForm({...procForm, cwd: v})} placeholder="/root/livechat-app" />
                  <TextInput label="Env (JSON or KEY=VAL)" value={procForm.env} onChange={(v)=>setProcForm({...procForm, env: v})} placeholder='{"NODE_ENV":"production"}' />
                  <TextInput label="Upstream MCP URL (proxy)" value={procForm.upstream_mcp_url} onChange={(v)=>setProcForm({...procForm, upstream_mcp_url: v})} placeholder="http://127.0.0.1:8000/mcp" />
                </div>
              </div>
              <div className="flex items-center justify-between">
                <SmallButton onClick={() => testServer(editServerId || null)}>Test</SmallButton>
                <div className="space-x-2">
                  {editServerId && <SmallButton kind="danger" onClick={() => deleteServer(editServerId)}>Delete</SmallButton>}
                  <SmallButton onClick={beginNew}>Reset</SmallButton>
                  <SmallButton kind="primary" onClick={saveServer}>{editServerId? 'Save' : 'Create'}</SmallButton>
                </div>
              </div>
            </div>
          </Section>
          
          {/* Tools panel for selected server */}
          {editServerId && (
            <Section title="Server Tools">
              <div className="mb-2 text-xs text-gray-600">Origin Module: <span className="font-mono">{serverForm.origin_module || '—'}</span></div>
              {!serverForm.origin_module && (
                <div className="text-xs text-gray-500">Select an Origin Module to view and toggle tools for this server.</div>
              )}
              {serverForm.origin_module && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-gray-600">Tools from module</div>
                    <SmallButton onClick={() => loadServerTools(editServerId)} disabled={serverToolsLoading}>{serverToolsLoading? 'Loading…' : 'Refresh'}</SmallButton>
                  </div>
                  <div className="border rounded">
                    <div className="grid grid-cols-12 px-2 py-1 border-b bg-gray-50 text-[11px] text-gray-600">
                      <div className="col-span-6">Name</div>
                      <div className="col-span-5">Description</div>
                      <div className="col-span-1 text-right">On</div>
                    </div>
                    <div>
                      {(serverTools || []).map((t) => (
                        <div key={t.name} className="grid grid-cols-12 px-2 py-1 border-b last:border-b-0 text-sm items-center">
                          <div className="col-span-6 font-mono truncate" title={t.name}>{t.name}</div>
                          <div className="col-span-5 text-xs text-gray-600 truncate" title={t.description||''}>{t.description || ''}</div>
                          <div className="col-span-1 text-right">
                            <input type="checkbox" checked={!!t.enabled} onChange={async (e)=>{
                              try {
                                const r = await fetch(`/api/mcp2/servers/${encodeURIComponent(editServerId)}/tools`, { method:'PATCH', headers:{'Content-Type':'application/json'}, credentials:'include', body: JSON.stringify({ name: t.name, enabled: !!e.target.checked }) });
                                const j = await r.json().catch(()=>({}));
                                if (!r.ok || j?.ok===false) throw new Error(j?.message || j?.error || 'toggle_failed');
                                setServerTools((arr)=> (arr||[]).map(x=> x.name===t.name ? { ...x, enabled: !!e.target.checked } : x));
                              } catch (err) { alert(String(err?.message || err)); }
                            }} />
                          </div>
                        </div>
                      ))}
                      {(!serverTools || !serverTools.length) && (
                        <div className="px-2 py-2 text-xs text-gray-500">No tools found in module.</div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </Section>
          )}
          </div>
        </div>
      )}

    </div>
  );
}




