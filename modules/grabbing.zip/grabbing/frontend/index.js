export { default as Main } from "./pages/GrabbingMain.jsx";
export { default } from "./pages/GrabbingMain.jsx";
export { default as Settings } from "./pages/Settings.jsx";
