# Visitor List Module

Purpose
- Explore visitor journeys and context; assist agents in picking conversations.

Directory Layout
- frontend/: Pages/components for visitors list and details.
- backend/: Add services/routes if needed.
- db/migrations/: SQL migrations for stored visitor metadata (optional).

Frontend Access
- Default route: `#/visitors` (top-level tab in the app).

Configuration & JSON
- Store org‑scoped configuration in DB as JSON.

Migrations
- Timestamped up/down SQL files under `db/migrations/`.

Deployment
- `sync+deploy.sh`. Follow `AGENTS.md` for conventions and safety.
This module follows the LiveChat-App module independence rules.

- Canonical rules: see `AGENTS.md` and `modules/MODULE_CHECKLIST.md`.
- API namespace: `/api/visitor-list/*`.
