export function registerMcp2Routes(app, ctx = {}) {
  const pool = ctx.pool;
  const requireAdmin = ctx.requireAdmin || ((_req, res) => { res.status(401).json({ ok:false, error:'unauthorized' }); return null; });
  const getLoadedModules = ctx.getLoadedModules || (()=>[]);
  const repoRoot = ctx.repoRoot || process.cwd();

  function safeJsonParse(s, dflt) { try { return typeof s === 'string' ? JSON.parse(s) : (s || dflt); } catch { return dflt; } }
  function readModuleConfig(modId) {
    try {
      const fs = require('fs');
      const path = require('path');
      const candidates = [];
      try { if (repoRoot) candidates.push(path.join(repoRoot, 'modules', String(modId||'').trim(), 'module.config.json')); } catch {}
      try { if (ctx.backendDir) candidates.push(path.join(ctx.backendDir, '..', 'modules', String(modId||'').trim(), 'module.config.json')); } catch {}
      for (const p of candidates) {
        try {
          if (p && fs.existsSync(p)) {
            const raw = fs.readFileSync(p, 'utf8');
            return JSON.parse(raw);
          }
        } catch {}
      }
      return null;
    } catch { return null; }
  }
  async function listMcpToolModules() {
    // 1) Prefer DB flags from mod_module_manager_modules when available
    try {
      if (pool && typeof pool.query === 'function') {
        const q = `SELECT module_name AS id, module_name AS name, mcp_tools FROM mod_module_manager_modules WHERE has_mcp_tool = TRUE`;
        const r = await pool.query(q);
        if (r && Array.isArray(r.rows) && r.rows.length) {
          const items = r.rows.map(row => ({ id: String(row.id), name: row.name || String(row.id), tools: (Array.isArray(row.mcp_tools) ? row.mcp_tools : []) }));
          try { ctx.logToFile?.(`[mcp2] modules discovery (DB) found=${items.length}`); } catch {}
          return items;
        }
      }
    } catch (e) {
      try { ctx.logToFile?.(`[mcp2] modules discovery (DB) error: ${e?.message || e}`); } catch {}
    }

    // 2) Fallback to filesystem scan of module.config.json
    try {
      const fs = require('fs');
      const path = require('path');
      const roots = [];
      try { if (repoRoot) roots.push(path.join(repoRoot, 'modules')); } catch {}
      try { if (ctx.backendDir) roots.push(path.join(ctx.backendDir, '..', 'modules')); } catch {}
      const seen = new Set();
      const items = [];
      for (const base of roots) {
        try {
          if (!base || !fs.existsSync(base)) continue;
          for (const ent of (fs.readdirSync(base, { withFileTypes: true })||[])) {
            if (!ent.isDirectory()) continue;
            const id = String(ent.name);
            if (seen.has(id)) continue; // de-duplicate across roots
            const cfg = readModuleConfig(id) || {};
            const has = !!cfg.hasMcpTool || Array.isArray(cfg.mcpTools);
            if (!has) continue;
            const tools = Array.isArray(cfg.mcpTools) ? cfg.mcpTools : [];
            items.push({ id, name: (cfg && cfg.name) || id, tools });
            seen.add(id);
          }
        } catch {}
      }
      // 3) Fallback to loader list of loaded modules
      if (!items.length && typeof getLoadedModules === 'function') {
        try {
          const loaded = (getLoadedModules()||[]).map(m=>m && m.id).filter(Boolean);
          for (const id of loaded) {
            if (seen.has(id)) continue;
            const cfg = readModuleConfig(id) || {};
            const has = !!cfg.hasMcpTool || Array.isArray(cfg.mcpTools);
            if (!has) continue;
            const tools = Array.isArray(cfg.mcpTools) ? cfg.mcpTools : [];
            items.push({ id, name: (cfg && cfg.name) || id, tools });
            seen.add(id);
          }
        } catch {}
      }
      try { ctx.logToFile?.(`[mcp2] modules discovery (FS) roots=${roots.join(', ')} found=${items.length}`); } catch {}
      return items;
    } catch { return []; }
  }

  function hasTransportMounted() {
    try {
      const stack = (app && app._router && Array.isArray(app._router.stack)) ? app._router.stack : [];
      const seen = { stream:false, events:false, alias:false };
      const checkLayer = (layer) => {
        try {
          if (!layer) return;
          if (layer.route && layer.route.path) {
            const p = String(layer.route.path);
            if (p.includes('/mcp2/:name/stream')) seen.stream = true;
            if (p.includes('/mcp2/:name/events')) seen.events = true;
            if (p.includes('/api/mcp2/transport/:name/stream')) seen.alias = true;
          } else if (Array.isArray(layer.handle?.stack)) {
            for (const sub of layer.handle.stack) checkLayer(sub);
          }
        } catch {}
      };
      for (const l of stack) checkLayer(l);
      return !!(seen.stream || seen.events || seen.alias);
    } catch { return false; }
  }

  // ----- Kinds CRUD (mod_mcp2_kind)
  app.get('/api/mcp2/kinds', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const r = await pool.query(`SELECT id, code, name, description, org_id, created_at, updated_at FROM mod_mcp2_kind ORDER BY lower(code)`); return res.json({ ok:true, items:r.rows }); } catch(e) { return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });
  app.post('/api/mcp2/kinds', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const b=req.body||{}; const id=`m2k_${Date.now().toString(36)}_${Math.random().toString(16).slice(2)}`; const code=String(b.code||'').trim(); if(!code) return res.status(400).json({ ok:false, error:'bad_request' }); const name=String(b.name||'').trim()||code; const description=(typeof b.description==='string'&&b.description)||null; const r=await pool.query(`INSERT INTO mod_mcp2_kind (id, code, name, description, created_at, updated_at) VALUES ($1,$2,$3,$4,NOW(),NOW()) RETURNING id, code, name, description, created_at, updated_at`, [id,code,name,description]); return res.status(201).json({ ok:true, item:r.rows[0] }); } catch(e) { return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });
  app.patch('/api/mcp2/kinds/:id', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const id=String(req.params.id||'').trim(); const allowed=new Set(['code','name','description','org_id']); const ent=Object.entries(req.body||{}).filter(([k])=>allowed.has(k)); if(!ent.length) return res.status(400).json({ ok:false, error:'bad_request' }); const sets=ent.map(([k],i)=>`${k} = $${i+1}`); const vals=ent.map(([,v])=>v); sets.push('updated_at = NOW()'); const r=await pool.query(`UPDATE mod_mcp2_kind SET ${sets.join(', ')} WHERE id=$${vals.length+1} RETURNING id, code, name, description, created_at, updated_at`, [...vals,id]); if(!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' }); return res.json({ ok:true, item:r.rows[0] }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });
  app.delete('/api/mcp2/kinds/:id', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const id=String(req.params.id||'').trim(); await pool.query(`DELETE FROM mod_mcp2_kind WHERE id=$1`, [id]); return res.json({ ok:true }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });

  // ----- Types CRUD (mod_mcp2_type)
  app.get('/api/mcp2/types', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const r = await pool.query(`SELECT id, code, name, description, tool_prefix, org_id, created_at, updated_at FROM mod_mcp2_type ORDER BY lower(code)`); return res.json({ ok:true, items:r.rows }); } catch(e) { return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });
  app.post('/api/mcp2/types', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const b=req.body||{}; const id=`m2t_${Date.now().toString(36)}_${Math.random().toString(16).slice(2)}`; const code=String(b.code||'').trim(); if(!code) return res.status(400).json({ ok:false, error:'bad_request' }); const name=String(b.name||'').trim()||code; const description=(typeof b.description==='string'&&b.description)||null; const r=await pool.query(`INSERT INTO mod_mcp2_type (id, code, name, description, created_at, updated_at) VALUES ($1,$2,$3,$4,NOW(),NOW()) RETURNING id, code, name, description, created_at, updated_at`, [id,code,name,description]); return res.status(201).json({ ok:true, item:r.rows[0] }); } catch(e) { return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });
  app.patch('/api/mcp2/types/:id', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const id=String(req.params.id||'').trim(); const allowed=new Set(['code','name','description','tool_prefix','org_id']); const ent=Object.entries(req.body||{}).filter(([k])=>allowed.has(k)); if(!ent.length) return res.status(400).json({ ok:false, error:'bad_request' }); const sets=ent.map(([k],i)=>`${k} = $${i+1}`); const vals=ent.map(([,v])=>v); sets.push('updated_at = NOW()'); const r=await pool.query(`UPDATE mod_mcp2_type SET ${sets.join(', ')} WHERE id=$${vals.length+1} RETURNING id, code, name, description, tool_prefix, created_at, updated_at`, [...vals,id]); if(!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' }); return res.json({ ok:true, item:r.rows[0] }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });
  app.delete('/api/mcp2/types/:id', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const id=String(req.params.id||'').trim(); await pool.query(`DELETE FROM mod_mcp2_type WHERE id=$1`, [id]); return res.json({ ok:true }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });

  // Modules exposing MCP tools (from module.config.json)
  app.get('/api/mcp2/modules', async (_req, res) => {
    try { const items = await listMcpToolModules(); return res.json({ ok:true, items }); }
    catch (e) { return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); }
  });

  // ----- Servers CRUD (mod_mcp2_server)
  app.get('/api/mcp2/servers', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const r=await pool.query(`SELECT id, name, kind_id, type_id, http_base, ws_url, stream_url, sse_url, token, enabled, options, notes, org_id, created_at, updated_at FROM mod_mcp2_server ORDER BY updated_at DESC`); return res.json({ ok:true, items:r.rows }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });
  app.post('/api/mcp2/servers', async (req, res) => {
    const u=requireAdmin(req,res); if(!u) return;
    try {
      const b=req.body||{};
      const id=`m2s_${Date.now().toString(36)}_${Math.random().toString(16).slice(2)}`;
      const name=String(b.name||'').trim();
      if(!name) return res.status(400).json({ ok:false, error:'bad_request' });
      const kind_id=(typeof b.kind_id==='string'&&b.kind_id.trim())||null;
      const http_base=(typeof b.http_base==='string'&&b.http_base.trim())||null;
      const ws_url=(typeof b.ws_url==='string'&&b.ws_url.trim())||null;
      const stream_url=(typeof b.stream_url==='string'&&b.stream_url.trim())||null;
      const sse_url=(typeof b.sse_url==='string'&&b.sse_url.trim())||null;
      let token=(typeof b.token==='string'? b.token : null);
      const enabled=!!b.enabled;
      const notes=(typeof b.notes==='string'&&b.notes)||null;
      let options=null; try{ if(b.options&&typeof b.options==='object'&&!Array.isArray(b.options)) options=b.options; else if(typeof b.options==='string'&&b.options.trim()) options=JSON.parse(b.options); }catch{}
      const requireAuth = (()=>{ try{ const o=(typeof b.options==='string')? JSON.parse(b.options): (b.options||{}); if (o && o.require_auth===false) return false; }catch{} return token && String(token).trim().length>0; })();
      if (!requireAuth) { token = null; }
      else { if (!token || !String(token).trim()) token=(globalThis.crypto?.randomUUID?.()||Math.random().toString(36).slice(2)); }
      // persist options including require_auth
      const finalOptions = { ...(options||{}), require_auth: !!requireAuth };
      // Columns: 13 total. We supply 11 parameters + NOW(), NOW() for timestamps.
      // Keep options as JSON using an explicit cast.
      const r=await pool.query(
        `INSERT INTO mod_mcp2_server (
            id, name, kind_id, http_base, ws_url, stream_url, sse_url, token, enabled, options, notes, created_at, updated_at
         ) VALUES (
            $1,$2,$3,$4,$5,$6,$7,$8,$9,$10::json,$11,NOW(),NOW()
         )
         RETURNING id, name, kind_id, http_base, ws_url, stream_url, sse_url, token, enabled, options, notes, created_at, updated_at`,
        [id, name, kind_id, http_base, ws_url, stream_url, sse_url, token, enabled, JSON.stringify(finalOptions||{}), notes]
      );
      return res.status(201).json({ ok:true, item:r.rows[0] });
    } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); }
  });
  app.patch('/api/mcp2/servers/:id', async (req, res) => {
    const u=requireAdmin(req,res); if(!u) return;
    try {
      const id=String(req.params.id||'').trim();
      const allowed=new Set(['name','kind_id','http_base','ws_url','stream_url','sse_url','token','enabled','options','notes']);
      const body = req.body || {};
      // Normalize: allow clearing token by sending empty string or null
      if (Object.prototype.hasOwnProperty.call(body,'token') && (!body.token || String(body.token).trim()==='')) body.token = null;
      // Ensure options.require_auth reflects token presence if provided
      if (body.options && typeof body.options==='object') {
        if (!Object.prototype.hasOwnProperty.call(body.options,'require_auth')) {
          body.options.require_auth = !!(body.token && String(body.token).length);
        }
      }
      const ent=Object.entries(body).filter(([k])=>allowed.has(k)).map(([k,v])=> (k==='options' && v && typeof v==='object')?[k,JSON.stringify(v)]:[k,v]);
      if(!ent.length) return res.status(400).json({ ok:false, error:'bad_request' });
      const sets=ent.map(([k],i)=> (k==='options'?`${k} = $${i+1}::json`:`${k} = $${i+1}`));
      const vals=ent.map(([,v])=>v);
      sets.push('updated_at = NOW()');
      const r=await pool.query(`UPDATE mod_mcp2_server SET ${sets.join(', ')} WHERE id=$${vals.length+1} RETURNING id, name, kind_id, http_base, ws_url, stream_url, sse_url, token, enabled, options, notes, created_at, updated_at`, [...vals,id]);
      if(!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' });
      return res.json({ ok:true, item:r.rows[0] });
    } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); }
  });

  // Server tools toggles (per origin module)
  app.get('/api/mcp2/servers/:id/tools', async (req, res) => { try { const u=requireAdmin(req,res); if(!u) return; const id=String(req.params.id||'').trim(); const r=await pool.query(`SELECT id, name, options FROM mod_mcp2_server WHERE id=$1 LIMIT 1`, [id]); if(!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' }); const srv=r.rows[0]; const opt=safeJsonParse(srv.options||{},{}); const origin=String((opt&&opt.origin_module)||'').trim(); const cfg=origin?readModuleConfig(origin):null; const list=Array.isArray(cfg&&cfg.mcpTools)?cfg.mcpTools:[]; const map=(opt&&typeof opt.tools_enabled==='object')?opt.tools_enabled:{}; const items=(list||[]).map(t=>({ name:(t&&t.name)||String(t), description:(t&&t.description)||'', enabled: map[((t&&t.name)||String(t))]!==false })); return res.json({ ok:true, items, origin_module: origin }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });
  app.patch('/api/mcp2/servers/:id/tools', async (req, res) => { try { const u=requireAdmin(req,res); if(!u) return; const id=String(req.params.id||'').trim(); const body=req.body||{}; const name=String(body.name||'').trim(); const enabled=!!body.enabled; if(!name) return res.status(400).json({ ok:false, error:'bad_request' }); const r=await pool.query(`SELECT id, options FROM mod_mcp2_server WHERE id=$1 LIMIT 1`, [id]); if(!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' }); const opt=safeJsonParse(r.rows[0].options||{},{}); const map=(opt&&typeof opt.tools_enabled==='object')?opt.tools_enabled:{}; map[name]=enabled; const next={ ...(opt||{}), tools_enabled: map }; const r2=await pool.query(`UPDATE mod_mcp2_server SET options=$1::json, updated_at=NOW() WHERE id=$2 RETURNING options`, [JSON.stringify(next), id]); return res.json({ ok:true, item:{ name, enabled }, options:r2.rows[0].options }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });
  app.delete('/api/mcp2/servers/:id', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const id=String(req.params.id||'').trim(); await pool.query(`DELETE FROM mod_mcp2_server WHERE id=$1`, [id]); return res.json({ ok:true }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });

  // Token helpers
  app.get('/api/mcp2/servers/:id/token', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const id=String(req.params.id||'').trim(); const r=await pool.query(`SELECT token FROM mod_mcp2_server WHERE id=$1 LIMIT 1`, [id]); if(!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' }); return res.json({ ok:true, token:r.rows[0].token||'' }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });
  app.post('/api/mcp2/servers/:id/token/regenerate', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const id=String(req.params.id||'').trim(); const tok=(globalThis.crypto?.randomUUID?.()||Math.random().toString(36).slice(2)); await pool.query(`UPDATE mod_mcp2_server SET token=$1, updated_at=NOW() WHERE id=$2`, [tok,id]); return res.json({ ok:true, token: tok }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });
  app.post('/api/mcp2/servers/:id/token/disable', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const id=String(req.params.id||'').trim(); await pool.query(`UPDATE mod_mcp2_server SET token=NULL, updated_at=NOW() WHERE id=$1`, [id]); return res.json({ ok:true }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:String(e?.message||e) }); } });

  // Status endpoints (best-effort, non-blocking)
  app.get('/api/mcp2/servers/status', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const r = await pool.query(`SELECT id, name, http_base, stream_url, sse_url, token, options FROM mod_mcp2_server ORDER BY updated_at DESC`);
      const items = [];
      const now = () => Date.now();
      const pref = (opt) => {
        try { const o = typeof opt === 'string' ? JSON.parse(opt) : (opt||{}); const v = o.server_url_pref; return (v==='stream'||v==='sse')?v:'sse'; } catch { return 'sse'; }
      };
      const toAlias = (url, name) => {
        try {
          const n = name ? encodeURIComponent(name) : '';
          if (!url) return '';
          const uo = new URL(url, 'http://dummy');
          const m = (uo.pathname || '').match(/^\/mcp2\/([^/]+)\/(stream|events)$/);
          if (m) {
            uo.pathname = `/api/mcp2/transport/${n || m[1]}/${m[2]}`;
            return uo.toString();
          }
          return url;
        } catch { return url; }
      };
      for (const s of r.rows) {
        const method = pref(s.options);
        const direct = method === 'stream' ? (s.stream_url || s.sse_url) : (s.sse_url || s.stream_url);
        const url = toAlias(direct, s.name);
        let ok = false; let ms = null; let code = null; let errMsg = null;
        if (url) {
          const controller = new AbortController();
          const started = now();
          const timeout = setTimeout(()=>controller.abort(), 3000);
          try {
            const resp = await fetch(url, { method: 'GET', headers: s.token? { 'Authorization': `Bearer ${s.token}` } : {}, signal: controller.signal });
            ms = now() - started;
            ok = resp.ok; code = resp.status;
          } catch (e) { ok = false; ms = null; errMsg = e?.message || String(e); }
          finally { clearTimeout(timeout); }
        }
        items.push({ id: s.id, ok, method, ms, code, error: errMsg });
      }
      const mounted = hasTransportMounted();
      const loaded = (getLoadedModules()||[]).map(m=>m?.id).includes('mcp2');
      return res.json({ ok:true, items, mounted: !!mounted, moduleLoaded: !!loaded, node: process.version });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.get('/api/mcp2/servers/:id/status', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const id = String(req.params.id||'').trim();
      const r = await pool.query(`SELECT id, http_base, stream_url, sse_url, token, options FROM mod_mcp2_server WHERE id=$1 LIMIT 1`, [id]);
      if (!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' });
      const s = r.rows[0];
      const pref = (opt) => { try { const o = typeof opt === 'string' ? JSON.parse(opt) : (opt||{}); const v = o.server_url_pref; return (v==='stream'||v==='sse')?v:'sse'; } catch { return 'sse'; } };
      const method = pref(s.options);
      const url = method === 'stream' ? (s.stream_url || s.sse_url) : (s.sse_url || s.stream_url);
      let ok = false; let ms = null; let code = null; let errMsg = null;
      if (url) {
        const controller = new AbortController();
        const started = Date.now();
        const timeout = setTimeout(()=>controller.abort(), 3000);
        try {
          const resp = await fetch(url, { method: 'GET', headers: s.token? { 'Authorization': `Bearer ${s.token}` } : {}, signal: controller.signal });
          ms = Date.now() - started;
          ok = resp.ok; code = resp.status;
        } catch (e) { ok = false; ms = null; errMsg = e?.message || String(e); }
        finally { clearTimeout(timeout); }
      }
      return res.json({ ok:true, status: { id: s.id, ok, method, ms, code, error: errMsg } });
    } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/mcp2/servers/test', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try { const b=req.body||{}; const pref=tryPref(b.options); // Best-effort, do not reach external hosts on test; just validate shape
      const hasAny = !!(String(b.sse_url||'').trim() || String(b.stream_url||'').trim() || String(b.http_base||'').trim());
      return res.json({ ok:true, status: { ok: hasAny, method: pref||'sse', ms: hasAny? 1: null } }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error' }); } });

  function tryPref(options) { try { const opt = typeof options==='string'? JSON.parse(options): (options||{}); const p = opt && opt.server_url_pref; if (p==='sse' || p==='stream') return p; return 'sse'; } catch { return 'sse'; } }
}
