export function register(app, _ctx = {}) {
  try {
    const key = '/api/module-template';
    const mounted = (globalThis.__moduleJsonMounted ||= new Set());
    const json = _ctx?.expressJson;
    if (typeof json === 'function' && !mounted.has(key)) { app.use(key, json({ limit: String(process.env.API_JSON_LIMIT || '50mb'), strict: false })); mounted.add(key); }
  } catch {}
  app.get('/api/module-template/ping', (_req, res) => res.json({ ok: true, module: 'module-template' }));
}

export default register;
