import React, { useEffect, useMemo, useRef, useState } from "react";
import { loadModuleState, saveModuleState } from "@app-lib/uiState";

/* ---------------- Helpers pays / drapeau ---------------- */
const tldToCCFromURLish = (urlish) => {
  if (!urlish) return null;
  try {
    const { hostname } = new URL(urlish);
    const tld = hostname.split(".").pop().toUpperCase();
    const map = {
      UK: "GB", GB: "GB", FR: "FR", DE: "DE", ES: "ES", IT: "IT", PT: "PT",
      NL: "NL", BE: "BE", CH: "CH", AT: "AT", IE: "IE", DK: "DK", SE: "SE",
      NO: "NO", FI: "FI", PL: "PL", CZ: "CZ", SK: "SK", HU: "HU", RO: "RO",
      BG: "BG", GR: "GR", TR: "TR", RU: "RU", UA: "UA", US: "US", CA: "CA",
      AU: "AU", NZ: "NZ", JP: "JP", KR: "KR", CN: "CN", IN: "IN", BR: "BR",
      AR: "AR", MX: "MX", MA: "MA", TN: "TN", DZ: "DZ", SN: "SN", ZA: "ZA",
      EU: "EU",
    };
    return map[tld] || null;
  } catch {
    return null;
  }
};
const pickCountryCode = (info) => {
  const cc = info?.country_code;
  if (cc) return String(cc).toUpperCase();
  const fromOrigin   = tldToCCFromURLish(info?.origin);
  const fromPage     = tldToCCFromURLish(info?.page_url);
  const fromPageLast = tldToCCFromURLish(info?.page_url_last);
  return (fromOrigin || fromPage || fromPageLast || "").toUpperCase();
};
const ccToFlag = (raw) => {
  if (!raw) return null;
  let cc = String(raw).trim().toUpperCase();
  const remap = { UK: "GB", EL: "GR" };
  const alpha3 = { GBR: "GB", FRA: "FR", DEU: "DE", ESP: "ES", ITA: "IT", USA: "US", CAN: "CA", AUS: "AU", NZL: "NZ" };
  cc = remap[cc] || cc;
  if (/^[A-Z]{3}$/.test(cc)) cc = alpha3[cc] || cc.slice(0, 2);
  if (cc === "EU") {
    const A = 0x1f1e6;
    return String.fromCodePoint(A + ("E".charCodeAt(0) - 65), A + ("U".charCodeAt(0) - 65));
  }
  if (!/^[A-Z]{2}$/.test(cc)) return null;
  const A = 0x1f1e6;
  return String.fromCodePoint(A + (cc.charCodeAt(0) - 65), A + (cc.charCodeAt(1) - 65));
};

/* ---------------- Small utils ---------------- */
const formatWhen = (ts) => {
  if (!ts) return "";
  try { return new Date(ts).toLocaleString(); } catch { return String(ts); }
};
const timeAgo = (ts) => {
  if (!ts) return "";
  const now = Date.now();
  const d = Math.max(0, now - ts);
  const s = Math.floor(d / 1000);
  if (s < 5) return "à l’instant";
  if (s < 60) return `il y a ${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `il y a ${m} min`;
  const h = Math.floor(m / 60);
  if (h < 24) return `il y a ${h} h`;
  const day = Math.floor(h / 24);
  return `il y a ${day} j`;
};
const displayName = (info, vId) => {
  const f = (info?.customer_firstname || "").trim();
  const l = (info?.customer_lastname || "").trim();
  if (f || l) return `${f} ${l}`.trim();
  if (info?.customer_email) return info.customer_email;
  return `Visiteur ${String(vId || '').slice(0, 6)}…`;
};
const hostOf = (u) => { try { return new URL(u).host; } catch { return ""; } };

/**
 * ConversationList
 * Props:
 *  - visitors: string[] (legacy input — optional)
 *  - conversations: Array<{ visitor_id, sender, content, created_at, last_seen }>
 *  - messages: Array<{ visitorId, from, message, timestamp }>
 *  - selectedVisitor: string|null
 *  - setSelectedVisitor: (id: string) => void
 *  - visitorInfo: { [visitorId]: {...} }
 */
export default function ConversationList({
  visitors = [],
  conversations = [],
  messages = [],
  selectedVisitor,
  setSelectedVisitor,
  visitorInfo = {},
  onVisitorPatch = () => {},
}) {
  const [showActiveOnly, setShowActiveOnly] = useState(() => {
    try { const st = loadModuleState('conversation-list'); return st.showActiveOnly !== undefined ? !!st.showActiveOnly : true; } catch { return true; }
  });
  // Track newcomers for 10s blink
  const newUntilRef = useRef(new Map());
  const [, forceNow] = useState(Date.now());
  useEffect(() => {
    const now = Date.now();
    for (const id of visitors || []) {
      if (!newUntilRef.current.has(id)) newUntilRef.current.set(id, now + 10000);
    }
    for (const c of conversations || []) {
      const id = c?.visitor_id;
      if (id && !newUntilRef.current.has(id)) newUntilRef.current.set(id, now + 10000);
    }
    for (const m of messages || []) {
      const id = m?.visitorId;
      if (id && !newUntilRef.current.has(id)) newUntilRef.current.set(id, now + 10000);
    }
    for (const id of Object.keys(visitorInfo || {})) {
      if (id && !newUntilRef.current.has(id)) newUntilRef.current.set(id, now + 10000);
    }
  }, [visitors, conversations, messages, visitorInfo]);
  useEffect(() => {
    const t = setInterval(() => forceNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);
  // Persist filter toggle
  useEffect(() => { try { saveModuleState('conversation-list', { showActiveOnly }); } catch {} }, [showActiveOnly]);
  // React to restore broadcast
  useEffect(() => {
    const onRestore = (e) => {
      try { const v = e?.detail?.modules?.['conversation-list']?.showActiveOnly; if (v != null) setShowActiveOnly(!!v); } catch {}
    };
    window.addEventListener('app-restore', onRestore);
    return () => window.removeEventListener('app-restore', onRestore);
  }, []);
  // 🔹 Build a union of all known visitor IDs (so we "see all conversations")
  const allVisitorIds = useMemo(() => {
    const set = new Set();

    // from props.visitors
    for (const id of visitors || []) if (id) set.add(id);

    // from DB conversations
    for (const c of conversations || []) {
      const id = c?.visitor_id;
      if (id) set.add(id);
    }

    // from live messages
    for (const m of messages || []) {
      const id = m?.visitorId;
      if (id) set.add(id);
    }

    // from any cached info
    for (const id of Object.keys(visitorInfo || {})) if (id) set.add(id);

    return Array.from(set);
  }, [visitors, conversations, messages, visitorInfo]);

  // Index last known DB convo per visitor (if multiple rows per visitor, keep the latest)
  const convoMap = useMemo(() => {
    const m = new Map();
    for (const c of conversations || []) {
      const vId = c?.visitor_id;
      if (!vId) continue;
      const prev = m.get(vId);
      const curTs = Date.parse(c?.created_at || c?.last_seen || "") || 0;
      const prevTs = prev ? (Date.parse(prev?.created_at || prev?.last_seen || "") || 0) : -1;
      if (!prev || curTs >= prevTs) m.set(vId, c);
    }
    return m;
  }, [conversations]);

  // Last live message per visitor
  const liveLastByVisitor = useMemo(() => {
    const map = new Map();
    for (const msg of messages || []) {
      const vId = msg?.visitorId;
      if (!vId) continue;
      const prev = map.get(vId);
      if (!prev || (msg.timestamp || 0) > (prev.timestamp || 0)) {
        map.set(vId, msg);
      }
    }
    return map;
  }, [messages]);

  // Last VISITOR message per visitor (for blink)
  const lastVisitorMsgAt = useMemo(() => {
    const map = new Map();
    for (const msg of messages || []) {
      if (!msg || msg.from !== "visitor") continue;
      const id = msg.visitorId;
      if (!id) continue;
      const t = msg.timestamp || 0;
      if (!map.has(id) || t > (map.get(id) || 0)) map.set(id, t);
    }
    return map;
  }, [messages]);

  // Final rows sorted by "most recent activity"
  const rows = useMemo(() => {
    const list = [];
    for (const vId of allVisitorIds) {
      const info = visitorInfo[vId] || {};
      const cc = pickCountryCode(info);
      const flag = ccToFlag(cc) || "🌐";

      const fromDB = convoMap.get(vId) || null; // { content, sender, created_at, last_seen }
      const fromLive = liveLastByVisitor.get(vId) || null;

      // Timestamps
      const liveTime = fromLive?.timestamp || 0;
      const dbCreated = fromDB?.created_at ? Date.parse(fromDB.created_at) : 0;
      const dbSeen    = fromDB?.last_seen ? Date.parse(fromDB.last_seen) : 0;
      const infoSeen  = info?.last_seen ? Date.parse(info.last_seen) : 0;

      let lastWhen = Math.max(liveTime, dbCreated, dbSeen, infoSeen);
      if (!lastWhen && (dbSeen || dbCreated || infoSeen)) lastWhen = dbSeen || dbCreated || infoSeen;

      // Text / sender
      let lastText = "";
      let lastSender = "";
      if (liveTime >= dbCreated) {
        lastText = fromLive?.message || "";
        lastSender = fromLive?.from === "agent" ? "agent" : "visitor";
      } else {
        lastText = fromDB?.content || "";
        lastSender = fromDB?.sender === "agent" ? "agent" : "visitor";
      }

      const lastVisitorTs = lastVisitorMsgAt.get(vId) || 0;
      const isNewVisitorMsg = lastVisitorTs && (Date.now() - lastVisitorTs < 10000);

      const lastSeenTs = info?.last_seen ? Date.parse(info.last_seen) : 0;
      const online = lastSeenTs && (Date.now() - lastSeenTs) < 120000; // 2 min
      const archived = (info?.archived !== undefined) ? Boolean(info.archived) : Boolean(fromDB?.archived);
      list.push({
        vId,
        cc,
        flag,
        info,
        lastText,
        lastSender,
        lastWhen,
        hintUrl: info?.page_url || info?.page_url_last || "",
        hintTitle: info?.title || "",
        isNew: (newUntilRef.current.get(vId) || 0) > Date.now(),
        isNewVisitorMsg,
        online,
        archived,
      });
    }

    // newest first
    list.sort((a, b) => (b.lastWhen || 0) - (a.lastWhen || 0));
    const filtered = showActiveOnly
      ? list.filter((r) => {
          const isArchived = (r.info?.archived !== undefined) ? r.info.archived : r.archived;
          // Consider online presence or any recent timestamp as activity
          return ((r.online || r.lastWhen || (r.lastText && r.lastText.length > 0)) && !isArchived);
        })
      : list;
    return filtered;
  }, [allVisitorIds, visitorInfo, convoMap, liveLastByVisitor, showActiveOnly]);

  const archiveVisitor = async (visitorId, archived) => {
    try {
      await fetch(`/api/visitors/${visitorId}/archive`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ archived }),
      });
      onVisitorPatch(visitorId, {
        archived,
        conversation_status: archived ? 'archived' : 'open',
      });
    } catch (err) {
      console.error('Unable to update archive state', err);
    }
  };

  const handleRowKey = (event, visitorId) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      setSelectedVisitor(visitorId);
    }
  };

  return (
    <section className="conversation-list">
      <header className="conversation-list__toolbar">
        <div className="conversation-list__tabs" role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={showActiveOnly}
            className={`chip ${showActiveOnly ? 'chip--active' : ''}`}
            onClick={() => setShowActiveOnly(true)}
          >
            Actives
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={!showActiveOnly}
            className={`chip ${!showActiveOnly ? 'chip--active' : ''}`}
            onClick={() => setShowActiveOnly(false)}
          >
            Toutes
          </button>
        </div>
        <span className="conversation-list__count">{rows.length} visiteurs</span>
      </header>
      <div className="conversation-list__body scroll-area">
        {rows.length === 0 && (
          <div className="conversation-list__empty">Aucune conversation.</div>
        )}

        {rows.map((row) => {
          const isSelected = selectedVisitor === row.vId;
          return (
            <article
              key={row.vId}
              role="button"
              tabIndex={0}
              onClick={() => setSelectedVisitor(row.vId)}
              onKeyDown={(event) => handleRowKey(event, row.vId)}
              className={`conversation-card${isSelected ? ' is-selected' : ''}${row.isNewVisitorMsg ? ' is-highlighted' : row.isNew ? ' is-fresh' : ''}`}
            >
              <div className="conversation-card__top">
                <div className="conversation-card__identity">
                  <span className={`status-dot${row.online ? ' is-online' : ''}`} />
                  <div>
                    <div className="conversation-card__name">{displayName(row.info, row.vId)}</div>
                    <div className="conversation-card__meta">
                      <span>{timeAgo(row.lastWhen) || 'il y a longtemps'}</span>
                      {(row.info?.archived ?? row.archived) && <span className="badge badge--muted">Archive</span>}
                    </div>
                  </div>
                </div>
                <div className="conversation-card__flag">
                  <span className="flag-emoji">{row.flag}</span>
                  <span>{row.cc || ''}</span>
                </div>
              </div>

              <div className="conversation-card__snippet">
                {row.lastText || 'Pas encore de message.'}
              </div>

              {row.hintUrl && (
                <div className="conversation-card__context">
                  {row.hintTitle ? `${row.hintTitle} • ` : ''}
                  {hostOf(row.hintUrl) || row.hintUrl}
                </div>
              )}

              <div className="conversation-card__actions">
                {!row.archived ? (
                  <button
                    type="button"
                    className="chip chip--outline"
                    onClick={(event) => {
                      event.stopPropagation();
                      archiveVisitor(row.vId, true);
                    }}
                  >
                    Archiver
                  </button>
                ) : (
                  <button
                    type="button"
                    className="chip chip--outline"
                    onClick={(event) => {
                      event.stopPropagation();
                      archiveVisitor(row.vId, false);
                    }}
                  >
                    Restaurer
                  </button>
                )}
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}

