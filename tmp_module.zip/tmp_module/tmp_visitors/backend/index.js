import { registerTmpVisitorsRoutes } from './routes/visitors.routes.js';

export function register(app, ctx) {
  registerTmpVisitorsRoutes(app, ctx);
}

