-- Create legacy grabbing_jerome_* tables used by Jerome pipelines (idempotent)
CREATE TABLE IF NOT EXISTS grabbing_jerome_queue (
  id TEXT PRIMARY KEY,
  url TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  added_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS grabbing_jerome_extracts (
  id bigserial PRIMARY KEY,
  file_name text NOT NULL,
  mtime timestamptz NOT NULL DEFAULT now(),
  size bigint DEFAULT 0,
  download_url text,
  product_url text,
  price numeric,
  currency text,
  image text,
  declinaison text,
  json_data jsonb
);

CREATE TABLE IF NOT EXISTS grabbing_jerome_transfers (
  id bigserial PRIMARY KEY,
  when_at timestamptz NOT NULL DEFAULT now(),
  id_product bigint,
  product_url text,
  image text,
  price numeric,
  currency text,
  declinaison text,
  file text,
  name text
);

CREATE TABLE IF NOT EXISTS grabbing_jerome_domains (
  domain text PRIMARY KEY,
  sitemap_url text,
  sitemaps jsonb,
  selected_sitemaps jsonb,
  sitemap_total_urls integer DEFAULT 0,
  config jsonb,
  config_transfert jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS grabbing_jerome_domain_config_history (
  id bigserial PRIMARY KEY,
  domain text NOT NULL,
  config jsonb,
  saved_at timestamptz NOT NULL DEFAULT now(),
  version integer,
  note text
);
CREATE INDEX IF NOT EXISTS grabbing_jerome_domain_config_history_domain_idx ON grabbing_jerome_domain_config_history (domain);

CREATE TABLE IF NOT EXISTS grabbing_jerome_domain_config_transfert_history (
  id bigserial PRIMARY KEY,
  domain text NOT NULL,
  type text NOT NULL,
  config jsonb,
  saved_at timestamptz NOT NULL DEFAULT now(),
  version integer
);
CREATE INDEX IF NOT EXISTS gj_dom_cfg_transfert_hist_domain_type_idx ON grabbing_jerome_domain_config_transfert_history (domain, type);

CREATE TABLE IF NOT EXISTS grabbing_jerome_domains_url (
  id bigserial PRIMARY KEY,
  domain text NOT NULL,
  url text NOT NULL,
  type text,
  title text,
  page_type text,
  meta jsonb,
  product jsonb,
  explored timestamptz,
  discovered_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS grabbing_jerome_domains_url_domain_idx ON grabbing_jerome_domains_url (domain);
CREATE UNIQUE INDEX IF NOT EXISTS grabbing_jerome_domains_url_uq ON grabbing_jerome_domains_url (domain, lower(trim(both from url)));

CREATE TABLE IF NOT EXISTS grabbing_jerome_domains_url_page_explore (
  id bigserial PRIMARY KEY,
  domain text NOT NULL,
  url text NOT NULL,
  page_type text NOT NULL,
  meta jsonb,
  product jsonb,
  links_sample jsonb,
  explored_at timestamptz NOT NULL DEFAULT now(),
  result_json jsonb,
  config_version integer
);
CREATE INDEX IF NOT EXISTS grabbing_jerome_domains_url_page_explore_domain_idx ON grabbing_jerome_domains_url_page_explore (domain);
CREATE UNIQUE INDEX IF NOT EXISTS grabbing_jerome_domains_url_page_explore_uq ON grabbing_jerome_domains_url_page_explore (domain, lower(trim(both from url)));

CREATE TABLE IF NOT EXISTS grabbing_jerome_domains_url_ready_transfert (
  id bigserial PRIMARY KEY,
  domain text NOT NULL,
  url text NOT NULL,
  prepared_at timestamptz NOT NULL DEFAULT now(),
  source_url_id bigint,
  page_type text,
  title text,
  meta jsonb,
  product_raw jsonb,
  mapped jsonb,
  status text NOT NULL DEFAULT 'pending',
  notes text,
  id_product bigint
);
CREATE INDEX IF NOT EXISTS grabbing_jerome_domains_url_ready_transfert_domain_idx ON grabbing_jerome_domains_url_ready_transfert (domain);
CREATE UNIQUE INDEX IF NOT EXISTS grabbing_jerome_domains_url_ready_transfert_uq ON grabbing_jerome_domains_url_ready_transfert (domain, lower(trim(both from url)));
CREATE INDEX IF NOT EXISTS grabbing_jerome_domains_url_ready_transfert_id_product_idx ON grabbing_jerome_domains_url_ready_transfert (id_product);

