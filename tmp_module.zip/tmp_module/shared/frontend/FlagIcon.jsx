// Render a Unicode flag emoji for a 2-letter country code (e.g. "FR", "CZ").
// No external requests; works offline across browsers.

import React from 'react';

const ccToEmoji = (cc) => {
  if (!cc || typeof cc !== 'string') return '🌐';
  const s = cc.toUpperCase().trim();
  if (s === 'EU') return '🇪🇺';
  if (!/^[A-Z]{2}$/.test(s)) return '🌐';
  const A = 0x1f1e6; // Regional indicator A
  const code1 = A + (s.charCodeAt(0) - 65);
  const code2 = A + (s.charCodeAt(1) - 65);
  try { return String.fromCodePoint(code1, code2); } catch { return '🌐'; }
};

export default function FlagIcon({ cc, className = 'h-4 w-4' }) {
  const emoji = ccToEmoji(cc);
  return (
    <span
      role="img"
      aria-label={cc || 'flag'}
      title={cc || 'flag'}
      className={`inline-block align-[-0.1em] ${className}`}
      style={{ lineHeight: 1 }}
    >
      {emoji}
    </span>
  );
}

