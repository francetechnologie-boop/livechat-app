Grabbing Jerome – Extraction Test Harness

Purpose
- Produce a single JSON blob with “all data” from a product page, including variants, documents, pictures, JSON‑LD, attributes. This is the input for a later PrestaShop 8 mapping step.

Usage
- Run with Node 18+ (Node 22 recommended):

```
node livechat-app/grabbing-jerome/tests/extract-product.mjs --url "https://sensorex.com/product/gt-gg-gc-series-glass-body-high-temperature-process-ph-orp-electrodes/"
```

Output
- Writes a timestamped JSON file under `livechat-app/grabbing-jerome/tests/out/` and also prints a short summary to stdout.
- JSON includes:
  - url, page_type, title, description, image, images[]
  - json_ld.raw + json_ld.mapped
  - product{name,sku,price,currency,brand,category,description_html}
  - attributes[] (from the Woo attributes table)
  - documents[] (pdf/doc/xls/zip links)
  - variants{ skus[], items[] } extracted from WooCommerce `data-product_variations` (SKUs, variation_id, price, attributes, image_url)

Notes
- Uses the backend’s Cheerio dependency. No server needed; runs standalone.
- If the server hides content for bots, a desktop User‑Agent is sent.

Transform to PrestaShop 8 payload
- Convert an existing extract JSON to a Presta‑ready structure (product + combinations):

```
node livechat-app/grabbing-jerome/tests/to-presta8.mjs --in livechat-app/grabbing-jerome/tests/out/extract-YYYY-mm-dd_HH-MM-SS.json
```

- Writes: `livechat-app/grabbing-jerome/tests/out/presta-YYYY-mm-dd_HH-MM-SS.json`
- Contains:
  - product: name, description_html, reference, brand, categories, price, currency, images
  - combinations: [{ reference, price, attributes[{group,value}], image_url }]
  - attachments: documents[]
  - attribute_groups + attribute_values_map (for mapping/group creation)
