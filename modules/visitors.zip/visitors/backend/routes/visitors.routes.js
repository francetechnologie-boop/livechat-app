export function registerTmpVisitorsRoutes(app, ctx = {}) {
  const pool = ctx.pool;
  const log = (m) => { try { ctx.logToFile?.(`[tmp_visitors] ${m}`); } catch {} };

  // Minimal schema introspection (PostgreSQL)
  const dbSchema = {
    loaded: false,
    visitors: { exists: false, idCol: null, hasVisitorIdCol: false, hasIdCol: false, hasCreatedAt: false, hasLastSeen: false, columns: [] },
    messages: { hasContent: false, hasContentHtml: false, hasMessage: false, hasVisitorId: false, idType: null },
  };

  async function introspectDb() {
    try {
      // visitors columns
      const vCols = await pool.query(`SELECT column_name, is_nullable FROM information_schema.columns WHERE table_schema='public' AND table_name='visitors'`);
      if (vCols.rowCount) {
        dbSchema.visitors.exists = true;
        dbSchema.visitors.columns = vCols.rows.map(r => r.column_name);
        dbSchema.visitors.hasIdCol = dbSchema.visitors.columns.includes('id');
        dbSchema.visitors.hasVisitorIdCol = dbSchema.visitors.columns.includes('visitor_id');
        dbSchema.visitors.hasCreatedAt = dbSchema.visitors.columns.includes('created_at');
        dbSchema.visitors.hasLastSeen = dbSchema.visitors.columns.includes('last_seen');
        // Determine idCol preference
        dbSchema.visitors.idCol = dbSchema.visitors.hasVisitorIdCol ? 'visitor_id' : (dbSchema.visitors.hasIdCol ? 'id' : null);
      }
    } catch {}
    try {
      const mCols = await pool.query(`SELECT column_name, data_type FROM information_schema.columns WHERE table_schema='public' AND table_name='messages'`);
      for (const r of mCols.rows) {
        if (r.column_name === 'id') dbSchema.messages.idType = r.data_type;
        if (r.column_name === 'content') dbSchema.messages.hasContent = true;
        if (r.column_name === 'content_html') dbSchema.messages.hasContentHtml = true;
        if (r.column_name === 'message') dbSchema.messages.hasMessage = true;
        if (r.column_name === 'visitor_id') dbSchema.messages.hasVisitorId = true;
      }
    } catch {}
    dbSchema.loaded = true;
    log(`schema visitors=${JSON.stringify(dbSchema.visitors)} messages=${JSON.stringify(dbSchema.messages)}`);
  }

  function msgExpr() {
    if (dbSchema.messages.hasContent) return 'm.content';
    if (dbSchema.messages.hasMessage) return 'm.message';
    return 'm.message';
  }

  function msgExprSelect() {
    const base = dbSchema.messages.hasContent ? 'COALESCE(content, \"\")' : (dbSchema.messages.hasMessage ? 'COALESCE(message, \"\")' : 'COALESCE(message, \"\")');
    const html = dbSchema.messages.hasContentHtml ? ', COALESCE(content_html,\"\") AS content_html' : '';
    return { base, html };
  }

  async function ensureSchema() { if (!dbSchema.loaded) await introspectDb(); }

  // List latest conversation per visitor
  app.get('/api/conversations', async (req, res) => {
    try {
      await ensureSchema();
      const days = Math.max(0, Number(req.query.days || 30));
      const limit = Math.max(1, Math.min(1000, Number(req.query.limit || 500)));
      const params = [];
      let where = '';
      if (days > 0) { params.push(days); where = `WHERE m.created_at >= NOW() - ($1::int || ' days')::interval`; }
      let sql;
      if (dbSchema.visitors.exists) {
        sql = `SELECT * FROM (SELECT DISTINCT ON (m.visitor_id) m.visitor_id, m.sender, ${msgExpr()} AS content, m.created_at, m.created_at AS last_seen, v.archived, v.conversation_status FROM messages m LEFT JOIN visitors v ON v.${dbSchema.visitors.idCol || 'visitor_id'} = m.visitor_id ${where} ORDER BY m.visitor_id, m.created_at DESC) AS t ORDER BY t.last_seen DESC LIMIT ${limit}`;
      } else {
        sql = `SELECT * FROM (SELECT DISTINCT ON (m.visitor_id) m.visitor_id, m.sender, ${msgExpr()} AS content, m.created_at, m.created_at AS last_seen FROM messages m ${where} ORDER BY m.visitor_id, m.created_at DESC) AS t ORDER BY t.last_seen DESC LIMIT ${limit}`;
      }
      const out = await pool.query(sql, params);
      res.json(out.rows || []);
    } catch (e) {
      log(`GET /api/conversations error: ${e.message}`);
      res.status(500).json({ error: 'server_error' });
    }
  });

  // Full message history for one visitor
  app.get('/api/conversations/:visitorId/messages', async (req, res) => {
    try {
      await ensureSchema();
      const visitorId = String(req.params.visitorId || '').trim();
      const limit = Math.max(1, Math.min(2000, Number(req.query.limit || 500)));
      if (!visitorId) return res.json([]);
      const { base, html } = msgExprSelect();
      const sql = `SELECT id, visitor_id, sender, ${base} AS content, agent_id, created_at${html} FROM messages WHERE visitor_id = $1 ORDER BY created_at ASC LIMIT ${limit}`;
      const out = await pool.query(sql, [visitorId]);
      res.json(out.rows || []);
    } catch (e) {
      log(`GET /api/conversations/:id/messages error: ${e.message}`);
      res.status(500).json({ error: 'server_error' });
    }
  });

  // Recent visitors (fallback to messages when no visitors table)
  app.get('/api/visitors/recent', async (_req, res) => {
    try {
      await ensureSchema();
      if (dbSchema.visitors.exists) {
        const idCol = dbSchema.visitors.idCol || (dbSchema.visitors.hasVisitorIdCol ? 'visitor_id' : 'id');
        const sql = `SELECT ${idCol} AS visitor_id, archived, conversation_status, last_seen, created_at, page_url_last, title, referrer, origin FROM visitors ORDER BY COALESCE(last_seen, created_at) DESC LIMIT 200`;
        const out = await pool.query(sql);
        return res.json(out.rows || []);
      }
      const out = await pool.query(`SELECT DISTINCT ON (visitor_id) visitor_id, sender, ${msgExpr()} AS content, created_at AS last_seen FROM messages ORDER BY visitor_id, created_at DESC LIMIT 200`);
      res.json(out.rows || []);
    } catch (e) {
      log(`GET /api/visitors/recent error: ${e.message}`);
      res.status(500).json({ error: 'server_error' });
    }
  });

  // Visitors list with basic stats
  app.get('/api/visitors/list', async (_req, res) => {
    try {
      await ensureSchema();
      if (!dbSchema.visitors.exists) return res.json([]);
      const idCol = dbSchema.visitors.idCol || (dbSchema.visitors.hasVisitorIdCol ? 'visitor_id' : 'id');
      const sql = `SELECT v.${idCol} AS visitor_id, COALESCE(v.customer_firstname,'') AS customer_firstname, COALESCE(v.customer_lastname,'') AS customer_lastname, COALESCE(v.customer_email,'') AS customer_email, COALESCE(v.country_code,'') AS country_code, COALESCE(v.lang_iso,'') AS lang_iso, v.last_seen, v.page_url_last, v.title, v.referrer, v.origin, (SELECT COUNT(*) FROM visits vi WHERE vi.visitor_id = v.${idCol}) AS visits_count, (SELECT COUNT(*) FROM messages m WHERE m.visitor_id = v.${idCol}) AS messages_count, (SELECT COUNT(*) FROM messages m WHERE m.visitor_id = v.${idCol} AND m.sender = 'agent') AS agent_messages_count FROM visitors v ORDER BY COALESCE(v.last_seen, v.created_at) DESC LIMIT 500`;
      const out = await pool.query(sql);
      res.json(out.rows || []);
    } catch (e) {
      log(`GET /api/visitors/list error: ${e.message}`);
      res.status(500).json({ error: 'server_error' });
    }
  });

  // One visitor info (flattened)
  app.get('/api/visitors/:visitorId', async (req, res) => {
    try {
      await ensureSchema();
      const visitorId = String(req.params.visitorId || '').trim();
      if (!visitorId || !dbSchema.visitors.exists) return res.status(404).json({ error: 'not_found' });
      const idCol = dbSchema.visitors.idCol || (dbSchema.visitors.hasVisitorIdCol ? 'visitor_id' : 'id');
      const out = await pool.query(`SELECT * FROM visitors WHERE ${idCol} = $1 LIMIT 1`, [visitorId]);
      if (!out.rowCount) return res.status(404).json({ error: 'not_found' });
      res.json(out.rows[0] || {});
    } catch (e) {
      log(`GET /api/visitors/:id error: ${e.message}`);
      res.status(500).json({ error: 'server_error' });
    }
  });

  // Archive/unarchive a visitor conversation
  app.post('/api/visitors/:visitorId/archive', async (req, res) => {
    try {
      await ensureSchema();
      const visitorId = String(req.params.visitorId || '').trim();
      if (!visitorId || !dbSchema.visitors.exists) return res.status(404).json({ error: 'not_found' });
      const archived = Boolean(req.body?.archived ?? true);
      const status = archived ? 'archived' : 'open';
      const where = (dbSchema.visitors.hasVisitorIdCol && dbSchema.visitors.hasIdCol) ? '(visitor_id = $1 OR id = $1)' : (dbSchema.visitors.hasVisitorIdCol ? 'visitor_id = $1' : (dbSchema.visitors.hasIdCol ? 'id = $1' : `${dbSchema.visitors.idCol || 'visitor_id'} = $1`));
      const r = await pool.query(`UPDATE visitors SET archived = $2, conversation_status = $3 WHERE ${where}`, [visitorId, archived, status]);
      if (!r.rowCount) return res.status(404).json({ error: 'not_found' });
      res.json({ ok: true, archived, rows: r.rowCount });
    } catch (e) {
      log(`POST /api/visitors/:id/archive error: ${e.message}`);
      res.status(500).json({ error: 'server_error' });
    }
  });

  // Recent visits for one visitor (simple table-backed)
  app.get('/api/visitors/:visitorId/visits', async (req, res) => {
    try {
      const visitorId = String(req.params.visitorId || '').trim();
      if (!visitorId) return res.json([]);
      const limit = Math.max(1, Math.min(200, Number(req.query.limit || 50)));
      const out = await pool.query(`SELECT visitor_id, page_url, title, origin, referrer, utm_source, utm_medium, utm_campaign, utm_term, utm_content, occurred_at FROM visits WHERE visitor_id = $1 ORDER BY occurred_at DESC LIMIT ${limit}`, [visitorId]);
      res.json(out.rows || []);
    } catch (e) {
      log(`GET /api/visitors/:id/visits error: ${e.message}`);
      res.status(500).json({ error: 'server_error' });
    }
  });
}

