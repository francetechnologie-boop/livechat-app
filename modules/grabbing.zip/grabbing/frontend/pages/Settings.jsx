import React from 'react';

export default function Settings() {
  return (
    <div className="p-4">
      <div className="text-sm text-gray-600">No settings for Grabbing yet.</div>
    </div>
  );
}

