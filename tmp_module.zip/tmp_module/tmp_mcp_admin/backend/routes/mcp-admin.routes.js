import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

function backendDirFromModule() {
  const here = path.resolve(path.dirname(new URL(import.meta.url).pathname));
  const repoRootGuess = path.resolve(here, '../../../../');
  const candidate = path.join(repoRootGuess, 'backend');
  try { if (fs.existsSync(candidate)) return candidate; } catch {}
  try { const cwd = process.cwd(); if (fs.existsSync(path.join(cwd, 'package.json'))) return cwd; } catch {}
  return candidate;
}
function getMcpUploadDir() {
  const backendDir = backendDirFromModule();
  const dir = path.join(backendDir, 'uploads', 'mcp');
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  return dir;
}
function slugifyName(name = '') {
  try { return String(name).toLowerCase().replace(/[^a-z0-9._-]+/g, '-').replace(/-+/g, '-').replace(/^-+|-+$/g, ''); } catch { return String(name || 'mcp'); }
}
function buildOpenAIHeaders(key, { organization, project } = {}) {
  const headers = { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' };
  try {
    const isProjectScoped = /^sk-proj-/.test(String(key));
    const org = organization || process.env.OPENAI_ORG || '';
    const proj = project || process.env.OPENAI_PROJECT || '';
    if (!isProjectScoped && org) headers['OpenAI-Organization'] = org;
    if (!isProjectScoped && proj) headers['OpenAI-Project'] = proj;
  } catch {}
  return headers;
}
function normalizeOpenAIBase(raw) {
  let b = (raw && String(raw).trim()) || '';
  if (!b) return 'https://api.openai.com/v1';
  if (!/^https?:\/\//i.test(b)) return 'https://api.openai.com/v1';
  try {
    const u = new URL(b);
    if (!u.pathname || u.pathname === '/' || u.pathname === '') { u.pathname = '/v1'; b = u.toString().replace(/\/$/, ''); }
  } catch { return 'https://api.openai.com/v1'; }
  return b.replace(/\/$/, '');
}

export function registerTmpMcpAdminRoutes(app, ctx = {}) {
  const pool = ctx.pool;
  const requireAdmin = ctx.requireAdmin || ((_req, res) => { res.status(401).json({ ok:false, error:'unauthorized' }); return null; });
  const extras = ctx.extras || {};
  const getOpenaiApiKey = extras.getOpenaiApiKey || (() => null);

  // Namespaced ping for smoke test
  app.get('/api/tmp_mcp_admin/ping', (_req, res) => res.json({ ok:true, module:'tmp_mcp_admin' }));

  // Minimal subset first: list/create/read/update/delete servers
  app.get('/api/mcp-servers', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const r = await pool.query(`SELECT id, name, kind, group_id, http_base, ws_url, stream_url, sse_url, token, enabled, notes, server_type, options, created_at, updated_at FROM mcp_server_config ORDER BY updated_at DESC`);
      return res.json({ ok:true, items: r.rows });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.post('/api/mcp-servers', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const b = req.body || {};
      const id = (function makeMcpServerId(){ try { return `mcp_${crypto.randomBytes(8).toString('hex')}`; } catch { return `mcp_${Date.now()}`; } })();
      const name = String(b.name || '').trim();
      if (!name) return res.status(400).json({ ok:false, error:'bad_request', message:'name required' });
      const kind = (typeof b.kind === 'string' && b.kind.trim()) || null;
      let group_id = (typeof b.group_id === 'string' && b.group_id.trim()) || null;
      const group_name = (typeof b.group_name === 'string' && b.group_name.trim()) || '';
      const http_base = (typeof b.http_base === 'string' && b.http_base.trim()) || null;
      const ws_url = (typeof b.ws_url === 'string' && b.ws_url.trim()) || null;
      const stream_url = (typeof b.stream_url === 'string' && b.stream_url.trim()) || null;
      const sse_url = (typeof b.sse_url === 'string' && b.sse_url.trim()) || null;
      let token = (typeof b.token === 'string' && b.token.trim()) || null;
      const enabled = !!b.enabled;
      const notes = (typeof b.notes === 'string' && b.notes) || null;
      const server_type = (typeof b.server_type === 'string' && b.server_type.trim()) || null;
      let options = null;
      try { if (b.options && typeof b.options === 'object' && !Array.isArray(b.options)) options = b.options; else if (typeof b.options === 'string' && b.options.trim()) options = JSON.parse(b.options); } catch {}
      if (!group_id && group_name) {
        const makeMcpGroupId = () => { try { return `mgp_${crypto.randomBytes(8).toString('hex')}`; } catch { return `mgp_${Date.now()}`; } };
        const gid = makeMcpGroupId();
        await pool.query(`INSERT INTO mcp_group (id, name, description, created_at, updated_at) VALUES ($1,$2,NULL,NOW(),NOW()) ON CONFLICT (name) DO NOTHING`, [gid, group_name]);
        const rG = await pool.query(`SELECT id FROM mcp_group WHERE name=$1 LIMIT 1`, [group_name]);
        group_id = rG.rowCount ? rG.rows[0].id : gid;
      }
      const name_base = String(name);
      let groupNameLabel = '';
      if (group_id && !group_name) { try { const g = await pool.query(`SELECT name FROM mcp_group WHERE id=$1 LIMIT 1`, [group_id]); if (g.rowCount) groupNameLabel = g.rows[0].name || ''; } catch {} }
      else if (group_name) { groupNameLabel = group_name; }
      const optionsWithBase = { ...(options || {}), name_base, ...(groupNameLabel ? { group_name: groupNameLabel } : {}) };
      const finalName = server_type ? (function buildName(){ try { const base = String(name_base||'').trim()||'MCP'; const t = String(server_type||'').toLowerCase(); const opts = optionsWithBase||{}; const typeMap = { database:'DB', files:'Files', apis:'API', ai:'AI', custom:'Custom' }; const tLabel = typeMap[t] || (t? t : ''); let info=''; if(t==='database'){ info=String(opts.db_kind||'').toLowerCase(); if(!info&&typeof opts.connection_url==='string'){ try{ const u=new URL(opts.connection_url); info=u.protocol.replace(':',''); }catch{}} if(!info) info=(opts.host? String(opts.host):'db'); } else if(t==='apis'){ if(typeof opts.base_url==='string'){ try{ info=new URL(opts.base_url).host; }catch{}} if(!info) info='api'; } else if(t==='files'){ let root=String(opts.root||'').trim(); if(root){ root=root.replace(/\\/g,'/'); const parts=root.split('/').filter(Boolean); info=parts[parts.length-1]||'files'; } if(!info) info='files'; } else if(t==='ai'){ if(typeof opts.api_base_url==='string'){ try{ info=new URL(opts.api_base_url).host; }catch{}} if(!info) info='ai'; } else if(t==='custom'){ info=String(opts.module||'custom'); } const segs=[]; segs.push(base); if(tLabel) segs.push(tLabel); if(info) segs.push(String(info)); return segs.join('_'); } catch { return String(name_base||'MCP'); } })() : name_base;
      if (!token) { try { token = crypto.randomBytes(24).toString('hex'); } catch {} }
      const r = await pool.query(`INSERT INTO mcp_server_config (id, name, kind, group_id, http_base, ws_url, stream_url, sse_url, token, enabled, notes, server_type, options, created_at, updated_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13::json,NOW(),NOW()) RETURNING id, name, kind, group_id, http_base, ws_url, stream_url, sse_url, token, enabled, notes, server_type, options, created_at, updated_at`, [id, finalName, kind, group_id, http_base, ws_url, stream_url, sse_url, token, enabled, notes, server_type, JSON.stringify(optionsWithBase)]);
      return res.status(201).json({ ok:true, item: r.rows[0] });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });
  app.get('/api/mcp-servers/:id', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try{ const id=String(req.params.id||'').trim(); const r=await pool.query(`SELECT id, name, kind, group_id, http_base, ws_url, stream_url, sse_url, token, enabled, notes, server_type, options, created_at, updated_at FROM mcp_server_config WHERE id=$1 LIMIT 1`,[id]); if(!r.rowCount) return res.status(404).json({ok:false,error:'not_found'}); return res.json({ ok:true, item:r.rows[0] }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:e?.message||String(e) }); } });
  app.patch('/api/mcp-servers/:id', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try{ const id=String(req.params.id||'').trim(); const b=req.body||{}; const entries=Object.entries(b).filter(([k])=>['name','kind','group_id','http_base','ws_url','stream_url','sse_url','token','enabled','notes','server_type','options'].includes(k)); if(!entries.length) return res.status(400).json({ ok:false, error:'bad_request' }); const eff=entries.map(([k,v])=> (k==='options' && v && typeof v==='object')?[k,JSON.stringify(v)]:[k,v]); const sets=eff.map(([k],i)=> (k==='options'?`${k} = $${i+1}::json`:`${k} = $${i+1}`)); const vals=eff.map(([,v])=>v); sets.push('updated_at = NOW()'); const r=await pool.query(`UPDATE mcp_server_config SET ${sets.join(', ')} WHERE id = $${vals.length+1} RETURNING id, name, kind, group_id, http_base, ws_url, stream_url, sse_url, token, enabled, notes, server_type, options, created_at, updated_at`,[...vals,id]); if(!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' }); return res.json({ ok:true, item:r.rows[0] }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:e?.message||String(e) }); } });
  app.delete('/api/mcp-servers/:id', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try{ const id=String(req.params.id||'').trim(); await pool.query(`DELETE FROM mcp_server_config WHERE id=$1`,[id]); return res.json({ ok:true }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:e?.message||String(e) }); } });
  app.get('/api/mcp-servers/:id/token', async (req,res)=>{ const u=requireAdmin(req,res); if(!u) return; try{ const id=String(req.params.id||'').trim(); const r=await pool.query(`SELECT token FROM mcp_server_config WHERE id=$1 LIMIT 1`,[id]); if(!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' }); return res.json({ ok:true, token:r.rows[0].token||'' }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:e?.message||String(e) }); } });
  app.post('/api/mcp-servers/:id/token/regenerate', async (req,res)=>{ const u=requireAdmin(req,res); if(!u) return; try{ const id=String(req.params.id||'').trim(); const tok=crypto.randomBytes(24).toString('hex'); await pool.query(`UPDATE mcp_server_config SET token=$1, updated_at=NOW() WHERE id=$2`,[tok,id]); return res.json({ ok:true, token:tok }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:e?.message||String(e) }); } });
  app.post('/api/mcp-servers/:id/token/disable', async (req,res)=>{ const u=requireAdmin(req,res); if(!u) return; try{ const id=String(req.params.id||'').trim(); await pool.query(`UPDATE mcp_server_config SET token=NULL, updated_at=NOW() WHERE id=$1`,[id]); return res.json({ ok:true }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:e?.message||String(e) }); } });

  // Minimal vector-files listing (placeholder)
  app.get('/api/mcp-servers/:id/vector-files', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try { return res.json({ ok:true, files: [] }); } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message||String(e) }); }
  });

  // Rebuild DB from existing upload folder entries for server
  app.post('/api/mcp-servers/:id/uploads/rebuild', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const id = String(req.params.id || '').trim(); if (!id) return res.status(400).json({ ok:false, error:'bad_request' });
      const r = await pool.query(`SELECT name FROM mcp_server_config WHERE id=$1 LIMIT 1`, [id]); if (!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' });
      const serverName = r.rows[0].name || '';
      const subdir = slugifyName(serverName);
      const dir = path.join(getMcpUploadDir(), subdir);
      try { fs.mkdirSync(dir, { recursive: true }); } catch {}
      const entries = fs.existsSync(dir) ? fs.readdirSync(dir, { withFileTypes: true }) : [];
      let added = 0;
      for (const ent of entries) {
        try {
          if (!ent.isFile()) continue;
          const rel = path.join(subdir, ent.name);
          const full = path.join(getMcpUploadDir(), rel);
          const st = fs.statSync(full);
          const fileNamePart = ent.name.replace(/^[^\-]+\-/, '');
          const q = await pool.query(`SELECT 1 FROM mcp_files WHERE file_path=$1 LIMIT 1`, [rel]);
          if (q.rowCount) continue;
          const idLocal = `${Date.now()}-${Math.random().toString(16).slice(2)}`;
          await pool.query(`INSERT INTO mcp_files (id, file_name, file_path, content_type, size_bytes, server_name, bot_id) VALUES ($1,$2,$3,$4,$5,$6,$7)`, [idLocal, fileNamePart || ent.name, rel, 'application/octet-stream', st.size, serverName, null]);
          added++;
        } catch {}
      }
      return res.json({ ok:true, added });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Basic DB echo (placeholder for connectivity tests)
  app.post('/api/mcp-servers/:id/test-db', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const id = String(req.params.id || '').trim(); if (!id) return res.status(400).json({ ok:false, error:'bad_request' });
      const rName = await pool.query(`SELECT name, options FROM mcp_server_config WHERE id=$1 LIMIT 1`, [id]); if (!rName.rowCount) return res.status(404).json({ ok:false, error:'not_found' });
      const opts = (() => { try { const o = rName.rows[0].options; return (o && typeof o === 'object') ? o : (o ? JSON.parse(String(o)) : {}); } catch { return {}; } })();
      return res.json({ ok:true, server: rName.rows[0].name || '', options: opts || {} });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Admin: list MCP uploads stored in DB for a given server (scoped by server_name)
  app.get('/api/mcp-servers/:id/uploads', async (req, res) => {
    const u = requireAdmin(req, res); if (!u) return;
    try {
      const id = String(req.params.id || '').trim(); if (!id) return res.status(400).json({ ok:false, error:'bad_request' });
      const limit = Math.max(1, Math.min(500, Number(req.query.limit || 100)));
      const verify = /^(1|true|yes)$/i.test(String(req.query.verify || '0'));
      const r = await pool.query(`SELECT name FROM mcp_server_config WHERE id=$1 LIMIT 1`, [id]);
      if (!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' });
      const name = r.rows[0].name || '';
      const q = await pool.query(`SELECT id, file_name, content_type, size_bytes, server_name, bot_id, file_path, is_remote, remote_provider, remote_file_id, created_at FROM mcp_files WHERE server_name = $1 ORDER BY created_at DESC LIMIT $2`, [name, limit]);
      let files = q.rows || [];
      if (verify) { files = files.filter((row) => { try { return !!row.file_path && fs.existsSync(path.join(getMcpUploadDir(), row.file_path)); } catch { return false; } }); }
      files = files.map((row) => { let exists = true; try { exists = !!row.file_path && fs.existsSync(path.join(getMcpUploadDir(), row.file_path)); } catch { exists = false; } const { file_path, ...rest } = row; return { ...rest, exists }; });
      return res.json({ ok:true, files });
    } catch (e) { return res.status(500).json({ ok:false, error:'server_error', message: e?.message || String(e) }); }
  });

  // Helpers to show underlying folder
  app.get('/api/mcp-servers/:id/uploads/path', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try{ const id=String(req.params.id||'').trim(); if(!id) return res.status(400).json({ ok:false, error:'bad_request' }); const r=await pool.query(`SELECT name FROM mcp_server_config WHERE id=$1 LIMIT 1`,[id]); if(!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' }); const name=r.rows[0].name||''; const dir=path.join(getMcpUploadDir(), slugifyName(name)); return res.json({ ok:true, path: dir }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:e?.message||String(e) }); } });
  app.get('/api/mcp-servers/:id/uploads/folder', async (req, res) => { const u=requireAdmin(req,res); if(!u) return; try{ const id=String(req.params.id||'').trim(); if(!id) return res.status(400).json({ ok:false, error:'bad_request' }); const r=await pool.query(`SELECT name FROM mcp_server_config WHERE id=$1 LIMIT 1`,[id]); if(!r.rowCount) return res.status(404).json({ ok:false, error:'not_found' }); const name=r.rows[0].name||''; const dir=path.join(getMcpUploadDir(), slugifyName(name)); let entries=[]; try{ const ents=fs.readdirSync(dir,{withFileTypes:true}); for(const e of ents){ if(!e.isFile()) continue; const full=path.join(dir,e.name); let st=null; try{ st=fs.statSync(full);}catch{} entries.push({ name:e.name, size_bytes: st?st.size:null, mtime: st?st.mtime:null }); } }catch{} return res.json({ ok:true, path:dir, entries }); } catch(e){ return res.status(500).json({ ok:false, error:'server_error', message:e?.message||String(e) }); } });
}
